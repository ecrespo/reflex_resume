import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Ft as r,Wt as i,nt as a,qt as o,rt as s}from"./createLucideIcon-Yao5kSEp.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-De8yxPG3.js";import{a as m,c as h,h as g,i as _,l as v,m as y,n as b,o as x,p as S,r as C,t as w,u as T}from"./one-dark-DCapkB6Q.js";import{n as E,t as D}from"./code-K8HYdwfc.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>r(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>r(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>r(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>r(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>r(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>r(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>r(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>r(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>r(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>r(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>r(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>r(D,{...n},t),pre:({node:t,...n})=>{let{node:i,className:a,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(a||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return r(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?b:w,wrapLongLines:!0,...s})}}}function A(){return r(O.Fragment,{},r(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`es`},r(O.Fragment,{},r(`div`,{className:`md:hidden`},r(g,{},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),r(`div`,{className:`w-full px-4`},r(y,{},`Descargar currículum`)),r(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(o,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/cifrareltraficodednsendebian9stretchactualizacion2017`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),r(`div`,{className:`w-full px-4`},r(y,{},`Descargar currículum`)),r(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(o,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/cifrareltraficodednsendebian9stretchactualizacion2017`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},r(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},r(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},r(`div`,{className:`md:hidden flex-shrink-0`},r(S,{},`Menú`)),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es`},`Inicio`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/resume`},`Currículum`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/portfolio`},`Portafolio`),r(o,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/es/blog`},`Blog`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/dev-dashboard-stats`},`Estadísticas de desarrollo`),r(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/archives`},`Archivo`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/categories`},`Categorías`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/tags`},`Etiquetas`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/es/feed.xml`},`Atom`))),r(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},r(`div`,{className:`container mx-auto max-w-4xl`},r(`div`,{className:`mb-6`},r(l,{href:`/es/blog`},`← Volver al blog`)),r(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},r(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`Cifrar el tráfico de DNS en Debian 9 Stretch (actualización 2017)`),r(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},r(`span`,{className:`text-[#3E6A5E]`},`3 de junio de 2017`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(d,{size:`sm`,tone:2},`Tutorial de Linux`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`Por`,r(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),r(`article`,{className:`post-content`,lang:`es`},r(`div`,{className:`prose prose-lg max-w-none`},r(T,{components:k(),rehypePlugins:[x,m,_],remarkPlugins:[v,h]},`En el año 2012 preocupado por la lentitud y seguridad en las comunicaciones de las consultas de DNS escribí un artículo sobre [DNSCrypt](/es/blog/cifrareltraficodednsenlinuxcondnscryptyopendns).

Este artículo se basa en el artículo [Comprobar que DNSCrypt funciona correctamente y cifra el tráfico](https://geekland.eu/comprobar-el-funcionamiento-de-dnscrypt/) .

Para esa época la instalación se hacía bajando un archivo \`.deb\`, pero en Debian Stretch ya viene incorporado en los repositorios, así que para instalar es con un simple \`apt-get\`.
\`\`\`
apt-get install dnscrypt-proxy dnscrypt-proxy-plugins
\`\`\`

Revisar que \`DNSCrypt\` esté activo:
\`\`\`
# systemctl status dnscrypt-proxy.socket
● dnscrypt-proxy.socket - dnscrypt-proxy listening socket
   Loaded: loaded (/lib/systemd/system/dnscrypt-proxy.socket; enabled; vendor preset: enabled)
   Active: active (running) since Sat 2017-06-03 00:26:02 -04; 18h ago
     Docs: man:dnscrypt-proxy(8)
   Listen: 127.0.2.1:53 (Stream)
           127.0.2.1:53 (Datagram)

jun 03 00:26:02 grievous systemd[1]: Listening on dnscrypt-proxy listening socket.
\`\`\`

Como se ve \`DNSCrypt\` está activo, para el caso de que no esté activo se ejecuta:
\`\`\`
# systemctl start dnscrypt-proxy.socket
\`\`\`
Para que \`DNSCrypt\` se ejecute automáticamente se ejecuta:
\`\`\`
# systemctl enable dnscrypt-proxy.socket
\`\`\`
La lista de servidores \`DNSCrypt\` lo pueden ver en \`/usr/share/dnscrypt-proxy/dnscrypt-resolvers.csv\` .  En la siguiente imagen se muestra algo del contenido del archivo: 

![](/blog/images/cifrareltraficodednsendebian9stretchactualización2017-1.png)

Ahora se consulta el puerto y la IP que está usando \`DNSCrypt\`:
\`\`\`
# cat /etc/systemd/system/sockets.target.wants/dnscrypt-proxy.socket
[Unit]
Description=dnscrypt-proxy listening socket
Documentation=man:dnscrypt-proxy(8)
Wants=dnscrypt-proxy-resolvconf.service

[Socket]
ListenStream=127.0.2.1:53
ListenDatagram=127.0.2.1:53

[Install]

WantedBy=sockets.target
\`\`\`
La dirección IP que está usando \`DNSCrypt\` es la 127.0.2.1 y el puerto 53.

Este archivo se modifica si se está usano \`SystemD\`, para el caso de usar \`init.d\` se modifica el archivo que se describe a continuación.

Se edita el archivo \`/etc/dnscrypt-proxy/dnscrypt-proxy.conf\` :
\`\`\` 
vim /etc/dnscrypt-proxy/dnscrypt-proxy.conf

# cat dnscrypt-proxy.conf 
# A more comprehensive example config can be found in
# /usr/share/doc/dnscrypt-proxy/examples/dnscrypt-proxy.conf

ResolverName random
Daemonize yes

# LocalAddress only applies to users of the init script. systemd users must
# change the dnscrypt-proxy.socket file.
LocalAddress 127.0.2.1:53
\`\`\`

Con la opción \`random\` garantiza que se use cualquier servidor de \`DNSCrypt\` de la lista ya mencionada.

Al levantar el servicio de \`DNSCrypt\` este cambia la configuración de \`/etc/resolv.conf\` para que use la IP 127.0.2.1, a continuación se muestra el contenido del archivo 
\`\`\`
# cat /etc/resolv.conf

# Generated by resolvconf
nameserver 127.0.2.1
\`\`\`
Al iniciar el servicio se puede revisar el log de \`syslog\` para ver si funciona el servicio:

![](/blog/images/cifrareltraficodednsendebian9stretchactualización2017-2.png)

Como se puede ver en el \`syslog\`, al inicio el servicio espera por un certificado digital y luego es que empieza a funcionar. 

Al consultar con el comando \`host\` se tiene:
\`\`\`
host www.google.com
www.google.com has address 216.58.209.68
www.google.com has IPv6 address 2a00:1450:401b:801::2004
\`\`\`

Ahora se instalarán unas herramientas de consultas:
\`\`\`
apt-get install dnsutils 
\`\`\`
Se realiza una consulta con el comando \`dig\`: 
\`\`\`
dig www.google.com

; <<>> DiG 9.10.3-P4-Debian <<>> www.google.com
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 6930
;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1

;; OPT PSEUDOSECTION:
; EDNS: version: 0, flags:; udp: 4096
;; QUESTION SECTION:
;www.google.com.   IN A

;; ANSWER SECTION:
www.google.com.  7 IN A 216.58.209.68

;; Query time: 266 msec
;; SERVER: 127.0.2.1#53(127.0.2.1)
;; WHEN: Sat Jun 03 20:26:08 -04 2017
;; MSG SIZE  rcvd: 59
\`\`\`
Para verificar el funcionamiento del cifrado en \`DNSCrypt\` se usará \`wireshark-gtk\`, primero se instala y luego se ejecuta:
\`\`\`
#apt-get install wireshark wireshark-gtk
\`\`\`
Para averiguar la IP del servidor \`DNSCrypt\` que se está usando se usa  \`dnsleaktest\`, al abrir la página muestra que la IP del equipo se encuentra en Barquisimeto, Venezuela y la IP es 186.185.180.136.

![](/blog/images/cifrareltraficodednsendebian9stretchactualización2017-3.png)

Se le da click a  \`standard test\`:

![](/blog/images/cifrareltraficodednsendebian9stretchactualización2017-4.png)

La IP del servidor es 81.2.237.32.

Se inicia \`wireshark\` capturando paquetes de la interface wlp1s0 que es ahora como se llama wlan0 en Debian Strech. Se inicia la captura de paquetes y se filtra ip.addr == 81.2.237.32. El resultado se muestra a continuación: 

![](/blog/images/cifrareltraficodednsendebian9stretchactualización2017-5.png)

El protocolo que se usa en la comunicación es [QUIC](https://es.wikipedia.org/wiki/QUIC) el cual es un experimental que cifra la comunicación. Se selecciona el primer paquete y con el botón derecho se le da clic a follow udp steam obteniendo lo que se muestra en la siguiente figura:

![](/blog/images/cifrareltraficodednsendebian9stretchactualización2017-6.png)

Al ejecutar esa acción se realiza la construcción de los diferentes paquetes en este caso de UDP en formato crudo, como se puede ver la comunicación no muestra información en texto plato. 


##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)
`))))),r(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},r(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},r(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),r(o,{"aria-label":`Enviar un correo a ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},r(u,{"aria-hidden":`true`,size:16}),r(`span`,{},`ecrespo@gmail.com`))),r(`p`,{className:`text-sm text-gray-700`},r(`span`,{},`Hecho con `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),r(`span`,{},` · alojado en `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),r(`nav`,{"aria-label":`Redes sociales`,className:`flex items-center gap-4`},r(o,{"aria-label":`Medium (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),r(o,{"aria-label":`LinkedIn (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),r(o,{"aria-label":`Twitter (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),r(o,{"aria-label":`GitHub (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),r(o,{"aria-label":`GitLab (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),r(o,{"aria-label":`Blog (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},r(p,{"aria-hidden":`true`,size:18})))),r(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},r(`span`,{},`© 2026 Ernesto Crespo. Todos los derechos reservados.`),r(`span`,{},`Código fuente bajo la `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`licencia Apache 2.0`),` · `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`Ver el código`)))))),r(`title`,{},`Blog | Cifrar el tráfico de DNS en Debian 9 Stretch (actualización 2017)`),r(`meta`,{content:`https://www.seraph.to/blog/images/cifrareltraficodednsendebian9stretchactualización2017-1.png`,property:`og:image`}),r(`meta`,{content:`article`,property:`og:type`}),r(`meta`,{content:`Ernesto Crespo`,property:`og:site_name`}),r(`meta`,{content:`Cifrar el tráfico de DNS en Debian 9 Stretch (actualización 2017)`,property:`og:title`}),r(`meta`,{content:`https://www.seraph.to/es/blog/cifrareltraficodednsendebian9stretchactualizacion2017`,property:`og:url`}),r(`meta`,{content:`summary_large_image`,name:`twitter:card`}),r(`meta`,{content:`Cifrar el tráfico de DNS en Debian 9 Stretch (actualización 2017)`,name:`twitter:title`}),r(`meta`,{content:`https://www.seraph.to/blog/images/cifrareltraficodednsendebian9stretchactualización2017-1.png`,name:`twitter:image`}))}A.displayName=`Component(es/blog/cifrareltraficodednsendebian9stretchactualizacion2017)`;var j=n(A);export{j as default};