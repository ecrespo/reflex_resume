import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{_t as r,bt as i,ct as a}from"./createLucideIcon-B1V7wG9E.js";import{n as o,t as s}from"./link-BrjTJgu3.js";import{n as c,t as l}from"./code-ClCpIeCG.js";import{a as u,i as d,n as f,r as p,t as m}from"./rss-Ce-bPYqM.js";import{a as h,i as g,o as _}from"./blog-BwedBF4N.js";import{t as v}from"./chunk-3UD7DUEM-lW1seuht.js";import{a as y,c as b,i as x,l as S,n as C,o as w,r as T,t as E,u as D}from"./one-dark-B8acPCS_.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(r);return{h1:({node:e,children:t,...n})=>a(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>a(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>a(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>a(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>a(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>a(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>a(o,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>a(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>a(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>a(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>a(s,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>a(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return a(T,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?C:E,wrapLongLines:!0,...s})}}}function A(){return a(O.Fragment,{},a(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`},a(O.Fragment,{},a(`div`,{className:`md:hidden`},a(_,{},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(u,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(d,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),a(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(d,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),a(`div`,{className:`w-full px-4`},a(h,{},`Download Resume`))))),a(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(u,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(d,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),a(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(d,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),a(`div`,{className:`w-full px-4`},a(h,{},`Download Resume`))))),a(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},a(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},a(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},a(`div`,{className:`md:hidden flex-shrink-0`},a(g,{},`Menu`)),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/`},`HOME`),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog`},`BLOG`),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/tags`},`TAGS`),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/feed.xml`},`ATOM`),a(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/dev-dashboard-stats`},`DEV DASHBOARD STATS`))),a(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},a(`div`,{className:`container mx-auto max-w-4xl`},a(`div`,{className:`mb-6`},a(p,{href:`/blog`},`← Volver al Blog`)),a(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},a(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Como correr Apache Spark desde una imagen Docker`),a(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},a(`span`,{className:`text-gray-500`},`July 02, 2018`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(v,{size:`sm`,tone:2},`Tutorial Python`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(`span`,{className:`text-gray-600`},`Por `),a(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),a(`article`,{className:`post-content`},a(`div`,{className:`prose prose-lg max-w-none`},a(D,{components:k(),rehypePlugins:[w,y,x],remarkPlugins:[S,b]},`
En este artículo se explicará la ejecución de Apache Spark usando un contenedor [Docker (enlace roto)](https://blog.crespo.org.ve/search/label/Docker), en vez de usar el procedimiento de [instalación de Spark](https://spark.apache.org/downloads.html) (instalar java, scala y spark).

Apache Spark proporciona una interfaz para la programación de clusters completos con paralelismos de Datos implicito y tolerancia a fallos. Tiene la base de su arquitectura en el llamado RDD (Resilient Distributed Dataset, set de sólo lectura de datos distribuídos a lo largo de un cluster de máquinas que se mantiene en un entorno tolerante a fallos).

Se puede considerar un sistema de computación en clúster de propósito general y orientado a la velocidad, proporciona APIs en Java, Scala, Python y R. También proporciona un motor optimizado que soporta la ejecución de grafos.

También soporta una serie de herramientas de alto nivel como lo son:

- Spark SQL (  para el procesamiento de datos estructurados basada en SQL).  
- MLlib para implementar machine learning.  
- GraphX para el procesamirnto de grafos.  
- Spark Streaming.  

Más información en [wikipedia](https://es.wikipedia.org/wiki/Apache_Spark).

La imagen docker que se va a usar es la de [gettyimages/spark](https://hub.docker.com/r/gettyimages/spark/) y de [github](https://github.com/gettyimages/docker-spark).

1. Bajar la imagen docker: 

\`\`\`
docker pull gettyimages/spark
\`\`\`
2. Bajar del repositorio github el repositorio de \`gettyimages/spark\` para usar \`docker-compose\`:
\`\`\`
git clone https://github.com/gettyimages/docker-spark.git
\`\`\`
3. Se cambia al directorio \`docker-sparck\`:
\`\`\`
cd docker-spark 
\`\`\`
4 Archivo \`Dockerfile\`:
\`\`\`python
FROM debian:stretch
MAINTAINER Getty Images "https://github.com/gettyimages"

RUN apt-get update \\
 && apt-get install -y locales \\
 && dpkg-reconfigure -f noninteractive locales \\
 && locale-gen C.UTF-8 \\
 && /usr/sbin/update-locale LANG=C.UTF-8 \\
 && echo "en_US.UTF-8 UTF-8" >> /etc/locale.gen \\
 && locale-gen \\
 && apt-get clean \\
 && rm -rf /var/lib/apt/lists/*

# Users with other locales should set this in their derivative image
ENV LANG en_US.UTF-8
ENV LANGUAGE en_US:en
ENV LC_ALL en_US.UTF-8

RUN apt-get update \\
 && apt-get install -y curl unzip \\
    python3 python3-setuptools \\
 && ln -s /usr/bin/python3 /usr/bin/python \\
 && easy_install3 pip py4j \\
 && apt-get clean \\
 && rm -rf /var/lib/apt/lists/*

# http://blog.stuart.axelbrooke.com/python-3-on-spark-return-of-the-pythonhashseed
ENV PYTHONHASHSEED 0
ENV PYTHONIOENCODING UTF-8
ENV PIP_DISABLE_PIP_VERSION_CHECK 1

# JAVA
ARG JAVA_MAJOR_VERSION=8
ARG JAVA_UPDATE_VERSION=131
ARG JAVA_BUILD_NUMBER=11
ENV JAVA_HOME /usr/jdk1.\${JAVA_MAJOR_VERSION}.0_\${JAVA_UPDATE_VERSION}

ENV PATH $PATH:$JAVA_HOME/bin
RUN curl -sL --retry 3 --insecure \\
  --header "Cookie: oraclelicense=accept-securebackup-cookie;" \\
  "http://download.oracle.com/otn-pub/java/jdk/\${JAVA_MAJOR_VERSION}u\${JAVA_UPDATE_VERSION}-b\${JAVA_BUILD_NUMBER}/d54c1d3a095b4ff2b6607d096fa80163/server-jre-\${JAVA_MAJOR_VERSION}u\${JAVA_UPDATE_VERSION}-linux-x64.tar.gz" \\
  | gunzip \\
  | tar x -C /usr/ \\
  && ln -s $JAVA_HOME /usr/java \\
  && rm -rf $JAVA_HOME/man

# HADOOP
ENV HADOOP_VERSION 3.0.0
ENV HADOOP_HOME /usr/hadoop-$HADOOP_VERSION
ENV HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
ENV PATH $PATH:$HADOOP_HOME/bin
RUN curl -sL --retry 3 \\
  "http://archive.apache.org/dist/hadoop/common/hadoop-$HADOOP_VERSION/hadoop-$HADOOP_VERSION.tar.gz" \\
  | gunzip \\
  | tar -x -C /usr/ \\
 && rm -rf $HADOOP_HOME/share/doc \\
 && chown -R root:root $HADOOP_HOME

# SPARK
ENV SPARK_VERSION 2.3.0
ENV SPARK_PACKAGE spark-\${SPARK_VERSION}-bin-without-hadoop
ENV SPARK_HOME /usr/spark-\${SPARK_VERSION}
ENV SPARK_DIST_CLASSPATH="$HADOOP_HOME/etc/hadoop/*:$HADOOP_HOME/share/hadoop/common/lib/*:$HADOOP_HOME/share/hadoop/common/*:$HADOOP_HOME/share/hadoop/hdfs/*:$HADOOP_HOME/share/hadoop/hdfs/lib/*:$HADOOP_HOME/share/hadoop/hdfs/*:$HADOOP_HOME/share/hadoop/yarn/lib/*:$HADOOP_HOME/share/hadoop/yarn/*:$HADOOP_HOME/share/hadoop/mapreduce/lib/*:$HADOOP_HOME/share/hadoop/mapreduce/*:$HADOOP_HOME/share/hadoop/tools/lib/*"
ENV PATH $PATH:\${SPARK_HOME}/bin
RUN curl -sL --retry 3 \\
  "https://www.apache.org/dyn/mirrors/mirrors.cgi?action=download&filename=spark/spark-\${SPARK_VERSION}/\${SPARK_PACKAGE}.tgz" \\
  | gunzip \\
  | tar x -C /usr/ \\
 && mv /usr/$SPARK_PACKAGE $SPARK_HOME \\
 && chown -R root:root $SPARK_HOME

WORKDIR $SPARK_HOME
CMD ["bin/spark-class", "org.apache.spark.deploy.master.Master"]
\`\`\`
5. El archivo [docker-compose.yml](https://github.com/gettyimages/docker-spark/blob/master/docker-compose.yml):
\`\`\`
master:
  image: gettyimages/spark
  command: bin/spark-class org.apache.spark.deploy.master.Master -h master
  hostname: master
  environment:
    MASTER: spark://master:7077
    SPARK_CONF_DIR: /conf
    SPARK_PUBLIC_DNS: localhost
  expose:
    - 7001
    - 7002
    - 7003
    - 7004
    - 7005
    - 7006
    - 7077
    - 6066
  ports:
    - 4040:4040
    - 6066:6066
    - 7077:7077
    - 9080:8080
  volumes:
    - ./conf/master:/conf
    - ./data:/tmp/data

worker:
  image: gettyimages/spark
  command: bin/spark-class org.apache.spark.deploy.worker.Worker spark://master:7077
  hostname: worker
  environment:
    SPARK_CONF_DIR: /conf
    SPARK_WORKER_CORES: 2
    SPARK_WORKER_MEMORY: 1g
    SPARK_WORKER_PORT: 8881
    SPARK_WORKER_WEBUI_PORT: 8081
    SPARK_PUBLIC_DNS: localhost
  links:
    - master
  expose:
    - 7012
    - 7013
    - 7014
    - 7015
    - 7016
    - 8881
  ports:
    - 8081:8081
  volumes:
    - ./conf/worker:/conf
    - ./data:/tmp/data

\`\`\`  

6. Se ejecuta \`docker-compose up\`:  

\`\`\`
docker-compose up
\`\`\`
7. A continuación se muestra la ejecución del contenedor:

![](/blog/images/comocorrerapachesparkdesdeunaimagendocker-1.png)

8.  Ver los procesos:
\`\`\`
docker-compose ps 
\`\`\`

9. A continuación el resultado:

![](/blog/images/comocorrerapachesparkdesdeunaimagendocker-2.png)


Se tiene dos contenedores ejecutandose, uno es el master, que tiene el puerto 4040 abierto, entre otros puertos, y el otro contenedor es el worker.

10. Se abre el navegador en http://localhost:9080, a continuación una captura del navegador:

![](/blog/images/comocorrerapachesparkdesdeunaimagendocker-3.png)

11. Ejecutar \`pyspark\` ejecuando dentro el contenedor master:
\`\`\`
docker exec -it dockerspark_master_1 /bin/bash
\`\`\`
11.1 Dentro del contenedor ejecutar \`pyspark\`:
\`\`\`
bin/pyspark
\`\`\`
A continuación se muestra la ejecución: 

![](/blog/images/comocorrerapachesparkdesdeunaimagendocker-4.png)

11.2 Al abrir el navegador se tiene una aplicación corriendo en el \`spark\`:

![](/blog/images/comocorrerapachesparkdesdeunaimagendocker-5.png)

12. Para terminar se ejecuta \`SparkPi\` desde el contenedor master:

12.1 Se ingresa al contenedor de master:
\`\`\`
docker exec -it dockerspark_master_1 /bin/bash
\`\`\`
12.2 Se ejecuta \`SparkPi\`
\`\`\`
bin/run-example SparkPi 10
\`\`\`
12.3 Se muestra la ejecución de la aplicación de \`SparkPi\`:

![](/blog/images/comocorrerapachesparkdesdeunaimagendocker-6.png)

En próximo artículo se usará el \`spark\` por medio de \`pyspark\`.

##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)
`))))),a(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},a(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},a(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),a(i,{"aria-label":`Send an e-mail to ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},a(f,{"aria-hidden":`true`,size:16}),a(`span`,{},`ecrespo@gmail.com`))),a(`p`,{className:`text-sm text-gray-700`},a(`span`,{},`Built with `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),a(`span`,{"aria-hidden":`true`},` · `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),a(`span`,{"aria-hidden":`true`},` · `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),a(`span`,{"aria-hidden":`true`},` · `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),a(`span`,{"aria-hidden":`true`},` · `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),a(`span`,{},` · hosted on `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),a(`span`,{"aria-hidden":`true`},` · `),a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),a(`nav`,{"aria-label":`Social networks`,className:`flex items-center gap-4`},a(i,{"aria-label":`Medium (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),a(i,{"aria-label":`LinkedIn (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),a(i,{"aria-label":`Twitter (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),a(i,{"aria-label":`GitHub (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),a(i,{"aria-label":`GitLab (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),a(i,{"aria-label":`Blog (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://blog.seraph.to`},a(m,{"aria-hidden":`true`,size:18})))),a(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},a(`span`,{},`© 2026 Ernesto Crespo. All rights reserved.`),a(`span`,{},`Source code under the `,a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`Apache 2.0 License`),` · `,a(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`View the source`)))))),a(`title`,{},`Blog | Como correr Apache Spark desde una imagen Docker`),a(`meta`,{content:`favicon.ico`,property:`og:image`}))}A.displayName=`Component(blog/comocorrerapachesparkdesdeunaimagendocker)`;var j=n(A);export{j as default};