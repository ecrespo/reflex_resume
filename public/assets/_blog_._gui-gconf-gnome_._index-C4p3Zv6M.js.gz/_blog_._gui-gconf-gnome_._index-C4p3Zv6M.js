import{r as e}from"./rolldown-runtime-hePW80VL.js";import{W as t,a as n}from"./components-DO_H3UDc.js";import{B as r,L as i,n as a,t as o}from"./link-DxqtXDAU.js";import{n as s}from"./emotion-react.browser.esm-D8ztlwVE.js";import{n as c,t as l}from"./code-BdqBTYPI.js";import{a as u,d,l as f,o as p,t as m}from"./blog-Df_uhXIx.js";import{a as h,c as g,i as _,l as v,n as y,o as b,r as x,t as S,u as C}from"./one-dark-B_jZNFYR.js";var w=e(t(),1);function T(){let{resolvedColorMode:e}=(0,w.useContext)(i);return{h1:({node:e,children:t,...n})=>s(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(a,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(x,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?y:S,wrapLongLines:!0,...o})}}}function E(){return s(w.Fragment,{},s(`div`,{className:`flex min-h-screen font-['Inter'] bg-[#f5f5dc]`},s(w.Fragment,{},s(w.Fragment,{},s(f,{},s(w.Fragment,{},s(d,{})),s(w.Fragment,{}))),s(m,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(r,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`))))),s(`aside`,{className:`hidden md:flex w-96 min-h-screen bg-[#7dd3c0] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-teal-600/10`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(r,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-96`},s(`nav`,{className:`w-full h-14 bg-[#4a9bba] flex items-center shadow-sm flex-shrink-0 z-20 sticky top-0`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(p,{},s(`div`,{className:`flex flex-col`},s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white`}))),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/`},`HOME`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog`},`BLOG`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/tags`},`TAGS`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/feed.xml`},`ATOM`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/dev-stats`},`DEV STATS`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(o,{asChild:!0,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{to:`/blog`},s(`span`,{className:`inline-flex items-center px-4 py-2 bg-[#4a9bba] text-white rounded-lg hover:bg-[#3a8baa] transition-colors font-medium mb-6`},`← Volver al Blog`))),s(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Desarrollo de interfaz gráfica para la configuración de accesos rápidos de teclado para gconf`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-gray-500`},`December 21, 2009`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-[#4a9bba] font-medium`},`Tutorial Python`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-gray-600`},`Por `),s(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),s(`article`,{className:`post-content`},s(`div`,{className:`prose prose-lg max-w-none`},s(C,{components:T(),rehypePlugins:[b,h,_],remarkPlugins:[v,g]},`En el [anterior artículo (enlace roto)](https://www.seraph.to/script-en-python-que-configura-los-accesos-rapidos-de-teclado-a-aplicaciones-en-gnome-con-gconf.html#script-en-python-que-configura-los-accesos-rapidos-de-teclado-a-aplicaciones-en-gnome-con-gconf) se mostró el desarrollo de una aplicación en python que configura vía línea de comandos los accesos rápidos de teclado para gnome por medio de gconf.

La interfáz gráfica de la aplicación la pueden bajar del siguiente [enlace (enlace roto)](http://python-config-accesskey-gnome.googlecode.com/hg/ui.glade) , el código python de la aplicación lo pueden bajar [acá (enlace roto)](http://python-config-accesskey-gnome.googlecode.com/hg/pyconfig-accessgnome-ui.py) y el módulo [configGconf.py (enlace roto)](http://python-config-accesskey-gnome.googlecode.com/hg/configGconf.py).

La interfaz gráfica fue creada con glade usando gtkbuilder en vez de libglade, esa es una de las diferencias principales con otros desarrollos gráficos mostrados en este blog. La interfaz tiene varios botones de verificación para seleccionar cuales opciones de teclas rápidas se quieren configurar.

La siguiente figura muestra la interfaz desarrollada con glade.


![GUI](/blog/images/gui-gconf-gnome.png)


A continuación el código fuente de la aplicación:



\`\`\`python

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Name: pyconfig-accessgnome-uy
Description: Aplicación gráfica que permite configurar los accesos rápidos de teclado a gconf
Version:0.1
License: GPLv3
Copyright: Copyright (C) 2009  Libre Accesibilidad
Author: Ernesto Nadir Crespo Avila
Email: ecrespo@gmail.com

"""




#Importar módulo gtk y el módulo de cambios de opciones de teclado
import gtk,configGconf


#Clse AccessGnomeCOnfig
class AccessGnomeConfig:
 def __init__(self):

                #Uso de la interfaz desarrollada con gtkbuilder y llamado del mismo.
  self.glade_file = "ui.glade"
  self.glade = gtk.Builder()
  self.glade.add_from_file(self.glade_file)
  # Asociación de todos los widgets
  self.window = self.glade.get_object('dialog1')
  self.button1 = self.glade.get_object('button1')
  self.button2 = self.glade.get_object('button2')
  self.checkbutton1 = self.glade.get_object('checkbutton1')
  self.checkbutton2 = self.glade.get_object('checkbutton2')
  self.checkbutton3 = self.glade.get_object('checkbutton3')
  self.checkbutton4 = self.glade.get_object('checkbutton4')
  self.checkbutton5 = self.glade.get_object('checkbutton5')
  self.checkbutton6 = self.glade.get_object('checkbutton6')
  self.checkbutton7 = self.glade.get_object('checkbutton7')
  self.checkbutton8 = self.glade.get_object('checkbutton8')
  self.checkbutton9 = self.glade.get_object('checkbutton9')
  self.checkbutton10 = self.glade.get_object('checkbutton10')
  self.checkbutton11 = self.glade.get_object('checkbutton11')
  self.checkbutton12 = self.glade.get_object('checkbutton12')
  self.checkbutton13 = self.glade.get_object('checkbutton13')
  self.aplicaciones = []



  # asociar las señales de los widgets con los métodos de la clase
  self.window.connect ("close",self.on_dialog1_close)
  self.window.connect("destroy",self.on_dialog1_destroy)
  self.button1.connect ("clicked",self.on_button1_clicked)
  self.button2.connect ("clicked",self.on_button2_clicked)
  self.checkbutton1.connect("toggled",self.on_checkbutton1_toggled)
  self.checkbutton2.connect("toggled",self.on_checkbutton2_toggled)
  self.checkbutton3.connect("toggled",self.on_checkbutton3_toggled)
  self.checkbutton4.connect("toggled",self.on_checkbutton4_toggled)
  self.checkbutton5.connect("toggled",self.on_checkbutton5_toggled)
  self.checkbutton6.connect("toggled",self.on_checkbutton6_toggled)
  self.checkbutton7.connect("toggled",self.on_checkbutton7_toggled)
  self.checkbutton8.connect("toggled",self.on_checkbutton8_toggled)
  self.checkbutton9.connect("toggled",self.on_checkbutton9_toggled)
  self.checkbutton10.connect("toggled",self.on_checkbutton10_toggled)
  self.checkbutton11.connect("toggled",self.on_checkbutton11_toggled)
  self.checkbutton12.connect("toggled",self.on_checkbutton12_toggled)
  self.checkbutton13.connect("toggled",self.on_checkbutton13_toggled)
  #Configuración del  widget ventana, agregandole un título.
  self.window.set_title("Configuración de accesos rapidos de Aplicaciones en Gnome")
  self.window.show_all()
 #Métodos de utilización de los botones de verificación cuando se selecciona o no.
        #Cuando se selecciona se agrega el elemento a una lista
        #Cuando se deselecciona se elimina el elemento de la lista.
 def on_checkbutton1_toggled(self,*args):
  variable = self.checkbutton1.get_active()
  if variable == True:
   self.aplicaciones.append("orca")
  else:
   self.__eliminacion("orca")

 def on_checkbutton2_toggled(self,*args):
  variable = self.checkbutton2.get_active()
  if variable == True:
   self.aplicaciones.append("nautilus")
  else:
   self.__eliminacion("nautilus")

 def on_checkbutton3_toggled(self,*args):
  variable = self.checkbutton3.get_active()
  if  variable == True:
   self.aplicaciones.append("oowriter")
  else:
   self.__eliminacion("oowriter")

 def on_checkbutton4_toggled(self,*args):
  variable = self.checkbutton4.get_active()
  if  variable == True:
   self.aplicaciones.append("iceweasel")
  else:
   self.__eliminacion("iceweasel")

 def on_checkbutton5_toggled(self,*args):
  variable = self.checkbutton5.get_active()
  if  variable == True:
   self.aplicaciones.append("pidgin")
  else:
   self.__eliminacion("pidgin")

 def on_checkbutton6_toggled(self,*args):
  variable = self.checkbutton6.get_active()
  if  variable == True:
   self.aplicaciones.append("gedit")
  else:
   self.__eliminacion("gedit")

 def on_checkbutton7_toggled(self,*args):
  variable = self.checkbutton7.get_active()
  if  variable == True:
   self.aplicaciones.append("ooimpress")
  else:
   self.__eliminacion("ooimpress")

 def on_checkbutton8_toggled(self,*args):
  variable = self.checkbutton8.get_active()
  if  variable == True:
   self.aplicaciones.append("gnome-calculator")
  else:
   self.__eliminacion("gnome-calculator")

 def on_checkbutton9_toggled(self,*args):
  variable = self.checkbutton9.get_active()
  if  variable == True:
   self.aplicaciones.append("oocalc")
  else:
   self.__eliminacion("oocalc")

 def on_checkbutton10_toggled(self,*args):
  variable = self.checkbutton10.get_active()
  if  variable == True:
   self.aplicaciones.append("rhythmbox")
  else:
   self.__eliminacion("rhythmbox")

 def on_checkbutton11_toggled(self,*args):
  variable = self.checkbutton11.get_active()
  if  variable == True:
   self.aplicaciones.append("gnome-terminal")
  else:
   self.__eliminacion("gnome-terminal")

 def on_checkbutton12_toggled(self,*args):
  pass
  """
  variable = self.checkbutton12.get_active()
  if  variable == True:
   print "daltonicos"
  else:
   print "nada de daltonicos"
  """
 def __eliminacion(self,aplicacion):
                #Elimina un elemento de la lista
  if len(self.aplicaciones) >= 2:
   for i in range(len(self.aplicaciones)):
    if self.aplicaciones[i] == aplicacion:
     self.aplicaciones[i:i+1] = []
     break
    else:
     continue
  elif len(self.aplicaciones) == 1:
   if self.aplicaciones[0] == aplicacion:
    self.aplicaciones = []
   else:
    pass
  else:
   pass


 def on_checkbutton13_toggled(self,*args):
                #Selecciona todos los botones de verificación o los deselecciona a todos.
  variable = self.checkbutton13.get_active()
  if  variable == True:
   self.checkbutton1.set_active(1)
   self.checkbutton2.set_active(1)
   self.checkbutton3.set_active(1)
   self.checkbutton4.set_active(1)
   self.checkbutton5.set_active(1)
   self.checkbutton6.set_active(1)
   self.checkbutton7.set_active(1)
   self.checkbutton8.set_active(1)
   self.checkbutton9.set_active(1)
   self.checkbutton10.set_active(1)
   self.checkbutton11.set_active(1)
   #self.checkbutton12.set_active(1)
  else:
   self.checkbutton1.set_active(0)
   self.checkbutton2.set_active(0)
   self.checkbutton3.set_active(0)
   self.checkbutton4.set_active(0)
   self.checkbutton5.set_active(0)
   self.checkbutton6.set_active(0)
   self.checkbutton7.set_active(0)
   self.checkbutton8.set_active(0)
   self.checkbutton9.set_active(0)
   self.checkbutton10.set_active(0)
   self.checkbutton11.set_active(0)
   #self.checkbutton12.set_active(0)


 def on_dialog1_close(self,*args):
                #Cierra la ventana de dialogo
  gtk.main_quit()

 def on_dialog1_destroy(self,*args):
                #Cierra la ventana de dialogo
  gtk.main_quit()

 def on_button1_clicked(self,*args):
                #Cierra la ventana de dialogo
  gtk.main_quit()

 def on_button2_clicked(self,*args):

                #Llama al módulo configGconf para aplicar los cambios con gconf

                Config = configGconf.Conf()
  Config.modificar_opcion(self.aplicaciones)

 def main(self): #Método que ejecuta el programa
  gtk.main()




if __name__ == "__main__":
       Instancia del objeto AccessGnomeConfig y ejecución del programa
 app = AccessGnomeConfig()
 app.main()

\`\`\`


La opción de applet para daltónicos no está habilitada en este momento ya que se está trabajando en agregar el applet automaticamente a la barra superior de gnome por medio de gconf. La próxima mejora será eliminar configuraciones del gconf.

En próximo artículo se creará el paquete .tar.gz de python para subirlo al repositorio oficial de python y luego crear un paquete para debian.


===

¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))))),s(`title`,{},`Blog | Desarrollo de interfaz gráfica para la configuración de accesos rápidos de teclado para gconf`),s(`meta`,{content:`favicon.ico`,property:`og:image`}))}E.displayName=`Component(blog/gui-gconf-gnome)`;var D=n(E);export{D as default};