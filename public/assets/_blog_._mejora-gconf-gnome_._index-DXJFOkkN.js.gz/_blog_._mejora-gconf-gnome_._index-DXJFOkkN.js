import{r as e}from"./rolldown-runtime-hePW80VL.js";import{W as t,a as n}from"./components-DO_H3UDc.js";import{R as r,V as i,n as a,t as o}from"./link-vstu2bOu.js";import{n as s}from"./emotion-react.browser.esm-D8ztlwVE.js";import{n as c,t as l}from"./code-LbbYdDpU.js";import{a as u,d,l as f,o as p,t as m}from"./blog-DvIX7I_t.js";import{a as h,c as g,i as _,l as v,n as y,o as b,r as x,t as S,u as C}from"./one-dark-tuQvF_Ko.js";var w=e(t(),1);function T(){let{resolvedColorMode:e}=(0,w.useContext)(r);return{h1:({node:e,children:t,...n})=>s(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(a,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(x,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?y:S,wrapLongLines:!0,...o})}}}function E(){return s(w.Fragment,{},s(`div`,{className:`flex min-h-screen font-['Inter'] bg-[#f5f5dc]`},s(w.Fragment,{},s(w.Fragment,{},s(f,{},s(w.Fragment,{},s(d,{})),s(w.Fragment,{}))),s(m,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(i,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`))))),s(`aside`,{className:`hidden md:flex w-96 min-h-screen bg-[#7dd3c0] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-teal-600/10`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(i,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-96`},s(`nav`,{className:`w-full h-14 bg-[#4a9bba] flex items-center shadow-sm flex-shrink-0 z-20 sticky top-0`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(p,{},s(`div`,{className:`flex flex-col`},s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white`}))),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/`},`HOME`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog`},`BLOG`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/tags`},`TAGS`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/feed.xml`},`ATOM`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(o,{asChild:!0,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`span`,{className:`inline-flex items-center px-4 py-2 bg-[#4a9bba] text-white rounded-lg hover:bg-[#3a8baa] transition-colors font-medium mb-6`},`← Volver al Blog`))),s(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Mejorado el script en python que configura los accesos rápidos de teclado a aplicaciones en Gnome con gconf.`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-gray-500`},`August 07, 2010`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-[#4a9bba] font-medium`},`Tutorial de Python y Linux`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-gray-600`},`Por `),s(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),s(`article`,{className:`post-content`},s(`div`,{className:`prose prose-lg max-w-none`},s(C,{components:T(),rehypePlugins:[b,h,_],remarkPlugins:[v,g]},`
Para cambiar un poco la temática sobre Android volveré a tocar un programa que explique en el [siguiente artículo (enlace roto)](https://www.seraph.to/script-en-python-que-configura-los-accesos-rapidos-de-teclado-a-aplicaciones-en-gnome-con-gconf.html).


El programa lo pueden bajar desde google code y tiene el nombre de [configGconf.py (enlace roto)](http://python-config-accesskey-gnome.googlecode.com/hg/configGconf.py).

Las mejoras que tiene el programa son las siguientes:

* Se puede seleccionar entre las distribuciones Debian, Ubuntu y Canaima ya que dependiendo del caso se usa iceweasel como navegador o firefox.
* Se despliega más información a la hora de ejecutar el programa.
* Se usa el módulo python-argparse para capturar los argumentos del programa.
* Se pueden modificar todas las opciones de los accesos rápidos del teclado o una sola opción.


Se tiene que tener instalado la librería para python argparse; en el caso de Debian, Ubuntu y Canaima se ejecuta:

\`\`\`
aptitude install python-argparse
\`\`\`

Bajar el programa del enlace ya publicado.

Es necesario darle permisos de ejecución:

\`\`\`
chmod a+x configGconf.py
\`\`\`

A continuación se explica el uso del programa con la mejora de la captura de los argumentos:

1. Si se ejecuta configGconf.py sin argumentos o con la opción -h devuelve la ayuda.
2. Si se ejecuta con -v devuelve el número de versión del programa.
3. Para listar la configuración que maneja las teclas rápidas con agregar la opción de acción (-a o --accion) y se pasa como argumento listar.
4. Para cambiar todas las configuraciones de los accesos rápidos de teclado se agrega la acción cambiar, la opción (-d o --distribucion) con argumentos debian, ubuntu o canaima.
5. Para cambiar una sola opción se agrega en la acción el argumento modificarOpción, la distribución que se está usando (explicado en 4) y que opción se quiere cambiar (orca,gnome-terminal,oowriter,iceweasel,nautilus,ooimpress,pidgin,oocalc,gedit,gnome-calculator,rhythmbox).


A continuación se muestra los resultados de cada procedimiento anterior:

\`\`\`
./configGconf.py 
usage: configGconf [-h] [-a {cambiar,listar,modificarOpcion}]
                   [-d {debian,canaima,ubuntu}]
                   [-o {orca,gnome-terminal,oowriter,iceweasel,nautilus,ooimpress,pidgin,oocalc,gedit,gnome-calculator,rhythmbox}]
                   [-v]

\`\`\`

Cambiar accesos rapidos en teclado a Gnome
\`\`\`
optional arguments:

 -h, --help            show this help message and exit
  -a {cambiar,listar,modificarOpcion}, --accion {cambiar,listar,modificarOpcion}
                        lista gconf
  -d {debian,canaima,ubuntu}, --distribucion {debian,canaima,ubuntu}
                        seleccione entre Canaima,Debian y ubuntu
  -o {orca,gnome-terminal,oowriter,iceweasel,nautilus,ooimpress,pidgin,oocalc,gedit,gnome-calculator,rhythmbox}, --opcion {orca,gnome-terminal,oowriter,iceweasel,nautilus,ooimpress,pidgin,oocalc,gedit,gnome-calculator,rhythmbox}
                        Cambia la configuración de una opción
  -v, --version
\`\`\`

\`\`\`
./configGconf.py -v
configGconf 0.4

./configGconf.py -a listar
Listar accesos rapidos del teclado a gconf
________________________________________________
Aplicación:  orca o
Aplicación:  gnome-terminal t
Aplicación:  oowriter w
Aplicación:  iceweasel n
Aplicación:  nautilus h
Aplicación:  ooimpress i
Aplicación:  pidgin p
Aplicación:  oocalc x
Aplicación:  gedit e
Aplicación:  gnome-calculator c
Aplicación:  rhythmbox m

./configGconf.py  -a cambiar -d debian
Listar accesos rapidos del teclado de gconf
________________________________________________
Configurando aplicacion: orca, acceso teclado: o
Configurando aplicacion: gnome-terminal, acceso teclado: t
Configurando aplicacion: oowriter, acceso teclado: w
Configurando aplicacion: iceweasel, acceso teclado: n
Configurando aplicacion: nautilus, acceso teclado: h
Configurando aplicacion: ooimpress, acceso teclado: i
Configurando aplicacion: pidgin, acceso teclado: p
Configurando aplicacion: oocalc, acceso teclado: x
Configurando aplicacion: gedit, acceso teclado: e
Configurando aplicacion: gnome-calculator, acceso teclado: c
Configurando aplicacion: rhythmbox, acceso teclado: m


./configGconf.py  -a modificarOpcion -d debian -o oowriter
Listar accesos rapidos del teclado de gconf
________________________________________________
Configurando aplicacion: oowriter, acceso teclado: w

\`\`\`

Para finalizar el artículo se colocará el código del programa:


\`\`\`python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Name: configGconf
Description: Aplicación y módulo que permite modificar los accesos rápido de teclas a programas
Version:0.4
License: GPLv3
Copyright: Copyright (C) 2009  Distrito Socialista Tecnologico AIT PDVSA Mérida
Author: Ernesto Nadir Crespo Avila
Email: ecrespo@gmail.com
Changelog:
 0.1: * Agregada multiples opciones de configuración.
 0.2: * Agregada opción de selección de distribución debian, ubuntu o canaima.
      * Agregada información adicional a la hora de desplegar en pantalla.
 0.3: * Agregado el uso del módulo argparse para simplificar la captura de argumentos del comando.
 0.4: * Agregada la posibilidad de modificar una sóla opción de las teclas rápidas de gconf.
"""
version = "0.4"
autor = "Ernesto Nadir Crespo Avila"
email = "ecrespo@gmail.com"
copyright = "GPLv3"


#Importar módulo gconf
import gconf




class Conf:
    def __init__(self):
        #Se crea la instancia de la clase de gconf
        self.__gconfClient = gconf.client_get_default()
        #Se crea la tupĺa aplicaciones        
        self.__aplicaciones = ("orca", "gnome-terminal","oowriter","iceweasel","nautilus","ooimpress","pidgin","oocalc","gedit","gnome-calculator","rhythmbox")
        #Se crea la ruta del comando del teclado y la ruta del modificador de teclado
        self.__comando = "/apps/metacity/keybinding_commands/command_"
        self.__asignacion_teclado = "/apps/metacity/global_keybindings/run_command_"
        #Se crea un diccionario teclas con la asociación entre la aplicación y su acceso rápido de teclado
        self.__teclas = {"orca":"o","gnome-terminal":"t","oowriter":"w","iceweasel":"n","nautilus":"h","ooimpress":"i","pidgin":"p","oocalc":"x","gedit":"e","gnome-calculator":"c","rhythmbox":"m"}


    def modificar_opcion(self,opciones,distribucion,interfaz=0):
        if distribucion <> "debian":
            self.__aplicaciones = ("orca", "gnome-terminal","oowriter","firefox","nautilus","ooimpress","pidgin","oocalc","gedit","gnome-calculator","rhythmbox")
            self.__teclas = {"orca":"o","gnome-terminal":"t","oowriter":"w","firefox":"n","nautilus":"h","ooimpress":"i","pidgin":"p","oocalc":"x","gedit":"e","gnome-calculator":"c","rhythmbox":"m"}
            if opciones == "iceweasel":
                opcion = "firefox"
            elif opciones == "firefox":
                opcion = opciones
            else:
                opcion = opciones
        else:
            if opciones == "firefox":
                opcion = "iceweasel"
            else:
                opcion = opciones

        if interfaz == 0:
            print "Listar accesos rapidos del teclado de gconf"
            print "________________________________________________"
        cont = 1
        #se genera un ciclo con las aplicaciones existentes
        for aplicacion in self.__aplicaciones:
            #Si la opción existe como aplicación se modifica el gconf, si no se sale sin resultado
            if aplicacion == opcion:
                ruta1 = "%s%s" %(self.__comando,cont)
                ruta2 = "%s%s" %(self.__asignacion_teclado,cont)
                self.__gconfClient.set_string(ruta1, "%s" %aplicacion)
                self.__gconfClient.set_string(ruta2, "%s" %self.__teclas[aplicacion])
                if interfaz == 0:
                    #Se imprime en pantalla los cambios logrados.
                    print "Configurando aplicacion: %s, acceso teclado: %s" %(aplicacion,self.__teclas[aplicacion])
                break
            cont = cont+1

    def modificar(self,distribucion):
        """
        modificar: Permite modificar los accesos rápidos del teclado
        Argumentos:
         * distribucion: se le pasa una distribución a utilizar entre debian,ubuntu y canaima.
        """
        cont = 1
        print "Listar accesos rapidos del teclado de gconf"
        print "________________________________________________"
        #Se la distribución no es debian se cambia iceweasel por firefox en las variables aplicaciones y teclas.
        if distribucion <> "debian":
            self.__aplicaciones = ("orca", "gnome-terminal","oowriter","firefox","nautilus","ooimpress","pidgin","oocalc","gedit","gnome-calculator","rhythmbox")
            self.__teclas = {"orca":"o","gnome-terminal":"t","oowriter":"w","firefox":"n","nautilus":"h","ooimpress":"i","pidgin":"p","oocalc":"x","gedit":"e","gnome-calculator":"c","rhythmbox":"m"}
        #Se genera un ciclo según las aplicaciones
        for aplicacion in self.__aplicaciones:
            #Definición de las rutas del gconf del comando y del modificador del teclado
            ruta1 =  "%s%s" %(self.__comando,cont)
            ruta2 = "%s%s"  %(self.__asignacion_teclado,cont)
            #Se modifica gconf
            self.__gconfClient.set_string(ruta1, "%s" %aplicacion)
            self.__gconfClient.set_string(ruta2, "%s" %self.__teclas[aplicacion])
            #Se imprime en pantalla los cambios logrados.
            print "Configurando aplicacion: %s, acceso teclado: %s" %(aplicacion,self.__teclas[aplicacion])
            cont = cont +1


    def listar(self):
        """
        listar: Permite listar los accesos rápidos de teclado de gconf
        """
        cont = 1
        print "Listar accesos rapidos del teclado a gconf"
        print "________________________________________________"
        #Se crea un ciclo según la lista de aplicaciones
        for aplicacion in self.__aplicaciones:
            #Se define la ruta del comando del teclado según gconf
            ruta1 =  "%s%s" %(self.__comando,cont)
            #Se define la ruta del modificador del teclado
            ruta2 = "%s%s"  %(self.__asignacion_teclado,cont)
            #Se desplega en pantalla 
            print "Aplicación: " ,self.__gconfClient.get_string(ruta1),self.__gconfClient.get_string(ruta2)
            cont = cont +1




if __name__ == "__main__":
    #Importar módulo argparse para capturar los argumentos del comando    
    import argparse
    #Se instancia la clase Conf en el objeto config
    config = Conf()
    #Creación del parse 
    parser = argparse.ArgumentParser(prog='configGconf',description="Cambiar accesos rapidos en teclado a Gnome")
    acciones = ["cambiar","listar","modificarOpcion"]
    distribuciones = ["debian","canaima","ubuntu"]
    aplicaciones = ["orca", "gnome-terminal","oowriter","iceweasel","nautilus","ooimpress","pidgin","oocalc","gedit","gnome-calculator","rhythmbox"]
    #Se agrega las opciones accion, distribucion y version.    
    parser.add_argument('-a','--accion',type=str,choices=acciones,default=acciones,help='lista gconf')
    parser.add_argument('-d','--distribucion',choices=distribuciones,type=str,default=distribuciones,help='seleccione entre Canaima,Debian y ubuntu')
    parser.add_argument('-o','--opcion',choices=aplicaciones,type=str,default=aplicaciones,help='Cambia la configuración de una opción')
    parser.add_argument('-v', '--version', action='version', version='%(prog)s 0.4') 
    #Se captura los argumentos del comando ejecutado.
    args = parser.parse_args()
    # ejecución de las opciones según la acción y la distribución
    if args.accion == "listar":
        #Se lista las configuraciones de los accesos del teclado
        config.listar()
    elif args.distribucion in ('debian','ubuntu','canaima') and args.accion == "cambiar":
        #Se modifican las opciones de los accesos del teclado
        config.modificar(args.distribucion)
    elif args.accion == "modificarOpcion":
        #Permite modificar una opcion
        config.modificar_opcion(args.opcion,args.distribucion)
    else:
        #Si no se pasa ningún argumento se despliega la ayuda
        parser.print_help()
\`\`\`


En el siguiente artículo se explicará los cambios que se hicieron en la interfaz gráfica del artículo [Desarrollo de interfaz gráfica para la configuración de accesos rápidos del teclado (enlace roto)](https://www.seraph.to/desarrollo-de-interfaz-grafica-para-la-configuracion-de-accesos-rapidos-de-teclado-para-gconf.html).
Luego se explicará como se crea un paquete python y como se crea un paquete para Debian a partir del paquete python.


===

¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))))),s(`title`,{},`Blog | Mejorado el script en python que configura los accesos rápidos de teclado a aplicaciones en Gnome con gconf.`),s(`meta`,{content:`favicon.ico`,property:`og:image`}))}E.displayName=`Component(blog/mejora-gconf-gnome)`;var D=n(E);export{D as default};