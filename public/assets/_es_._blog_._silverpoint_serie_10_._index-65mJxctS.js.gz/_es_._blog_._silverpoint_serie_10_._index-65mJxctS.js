import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{J as r,Z as i,o as a,s as o,z as s}from"./createLucideIcon-BKyn4FuD.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-Bi-t7m2Z.js";import{a as m,c as h,f as g,g as _,i as v,l as y,m as b,n as x,o as S,r as C,t as w,u as T}from"./one-dark-CtQwBnrQ.js";import{n as E,t as D}from"./code-CYC7Gv0B.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(r);return{h1:({node:e,children:t,...n})=>s(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(o,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(D,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?x:w,wrapLongLines:!0,...o})}}}function A(){return s(O.Fragment,{},s(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`es`},s(O.Fragment,{},s(`div`,{className:`md:hidden`},s(_,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),s(`div`,{className:`mb-4`},s(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),s(l,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),s(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(l,{size:`sm`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),s(`div`,{className:`w-full px-4`},s(b,{},`Descargar currículum`)),s(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},s(i,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/silverpoint_serie_10`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`EN`)),s(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`ES`)))))),s(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),s(`div`,{className:`mb-4`},s(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),s(l,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),s(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(l,{size:`sm`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),s(`div`,{className:`w-full px-4`},s(b,{},`Descargar currículum`)),s(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},s(i,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/silverpoint_serie_10`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`EN`)),s(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`ES`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},s(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(`div`,{className:`md:hidden flex-shrink-0`},s(g,{},`Menú`)),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es`},`Inicio`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/resume`},`Currículum`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/portfolio`},`Portafolio`),s(i,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/es/blog`},`Blog`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/dev-dashboard-stats`},`Estadísticas de desarrollo`),s(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/archives`},`Archivo`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/categories`},`Categorías`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/tags`},`Etiquetas`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/es/feed.xml`},`Atom`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(`div`,{className:`mb-6`},s(c,{href:`/es/blog`},`← Volver al blog`)),s(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`Silverpoint, artículo 10: modo precision y accesibilidad`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-[#3E6A5E]`},`11 de noviembre de 2026`),s(`span`,{className:`text-[#5C7B71] mx-2`},` • `),s(d,{size:`sm`,tone:2},`Tutorial Silverpoint`),s(`span`,{className:`text-[#5C7B71] mx-2`},` • `),s(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`Por`,s(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),s(`article`,{className:`post-content`,lang:`es`},s(`div`,{className:`prose prose-lg max-w-none`},s(T,{components:k(),rehypePlugins:[S,m,v],remarkPlugins:[y,h]},`El [artículo 01](/es/blog/silverpoint_serie_1) contaba que en silverpoint la irregularidad del dibujo a mano vive solo en el ornamento, y que cada gráfico tiene un modo \`precision\` que la apaga. Este artículo de la serie sobre [silverpoint](https://github.com/ecrespo/silverpoint) lo pone a prueba y recorre lo que hace accesible a un gráfico: su nombre, su descripción, la tabla de datos, el teclado y lo que oye quien usa un lector de pantalla.

## Lo que vas a construir

Dos gráficos del panel de operaciones, las ventas por canal y los errores por día y franja horaria, dibujados dos veces: con el entintado a mano, a la izquierda, y en modo \`precision\`, a la derecha.

![Las ventas por canal y los errores por día, con entintado a la izquierda y en modo precision a la derecha](/blog/images/silverpoint-serie-10.png)

Después, el gráfico de visitas por hora con su nombre, su descripción y la tabla de datos a la vista, y el mismo trabajo en Reflex.

## Lo que necesitas

El proyecto de React del [artículo 03](/es/blog/silverpoint_serie_3) o el de Reflex del [artículo 06](/es/blog/silverpoint_serie_6), con las visitas por hora de su paso 5 (\`src/traffic.ts\`) o de su paso 3 (\`ops_panel/traffic.py\`). En Vue y Angular las props de este artículo se escriben igual: \`mode="precision"\` y \`data-table="visible"\` en Vue, \`mode="precision"\` y \`dataTable="visible"\` en Angular.

## 1. Los datos

Crea \`src/sales.ts\` con las ventas por canal, en miles de euros:

\`\`\`ts
export type ChannelSales = {
  channel: string;
  sales: number;
};

export const sales: ChannelSales[] = [
  { channel: 'Web', sales: 46 },
  { channel: 'App', sales: 31 },
  { channel: 'Partners', sales: 15 },
  { channel: 'Phone', sales: 8 },
];
\`\`\`

Y \`src/errors.ts\` con los errores de cada día de la semana en seis franjas de cuatro horas:

\`\`\`ts
export type DayErrors = {
  day: string;
  values: number[];
};

export const blocks = ['00-04', '04-08', '08-12', '12-16', '16-20', '20-24'];

export const errors: DayErrors[] = [
  { day: 'Mon', values: [3, 5, 31, 38, 22, 8] },
  { day: 'Tue', values: [2, 6, 28, 35, 20, 7] },
  { day: 'Wed', values: [4, 7, 34, 40, 25, 9] },
  { day: 'Thu', values: [3, 5, 29, 36, 21, 8] },
  { day: 'Fri', values: [2, 6, 26, 30, 18, 10] },
  { day: 'Sat', values: [1, 2, 9, 12, 10, 6] },
  { day: 'Sun', values: [1, 1, 7, 10, 8, 5] },
];
\`\`\`

## 2. Entintado y precisión, lado a lado

Sustituye \`src/App.tsx\`:

\`\`\`tsx
import { BarChart } from '@silverpoint/react/bar-chart';
import { HeatmapChart } from '@silverpoint/react/heatmap-chart';
import { blocks, errors } from './errors';
import { sales } from './sales';

const modes = ['ink', 'precision'] as const;

export default function App() {
  return (
    <main style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, maxWidth: 1100 }}>
      {modes.map((mode) => (
        <section key={mode} style={{ display: 'grid', gap: 24 }}>
          <BarChart
            id={\`sales-\${mode}\`}
            data={sales}
            xKey="channel"
            valueKey="sales"
            title="Sales by channel"
            badge={mode}
            mode={mode}
          />
          <HeatmapChart
            id={\`errors-\${mode}\`}
            data={errors}
            labelKey="day"
            valuesKey="values"
            columnLabels={blocks}
            scaleMax={40}
            title="Errors by day and hour"
            badge={mode}
            mode={mode}
            height={220}
          />
        </section>
      ))}
    </main>
  );
}
\`\`\`

Cada gráfico lleva su propio \`id\`. De él sale la semilla del trazo a mano y los identificadores de su SVG, así que dos gráficos con las mismas props no comparten nada.

Compara las dos columnas. El modo \`precision\` quita dos cosas:

* **El temblor de la mano.** En modo \`ink\`, el marco de la tarjeta, las reglas y la cuadrícula se dibujan con un trazo irregular. En \`precision\` son líneas exactas.
* **El tramado.** Las barras y las celdas del mapa de calor pierden su trama, y el tono desaparece con ella.

Y deja igual todo lo que representa un dato. Los trazos que codifican los valores, el contorno de cada barra y la línea de un gráfico de línea, tienen exactamente las mismas coordenadas en los dos modos: en el SVG son los \`path\` con \`data-role="encoding"\`, y su atributo \`d\` es idéntico. También se mantienen los textos, los números, el realce del valor vivo, la tabla de datos y la interacción.

El modo se elige en cada gráfico con la prop \`mode\`, o para toda una sección con el proveedor (artículo 09) o con un panel (artículo 13).

## 3. Cuando el sistema pide más contraste

Hay dos preferencias del sistema que imponen el modo \`precision\`: \`prefers-contrast: more\`, cuando el usuario pide más contraste, y \`forced-colors: active\`, el modo de alto contraste de Windows. Con cualquiera de las dos, todos los gráficos se dibujan sin entintado y sin tramado, aunque lleven \`mode="ink"\`. Ninguna prop lo deshace.

El cambio se aplica en vivo: si el usuario activa la preferencia con la página abierta, los gráficos se redibujan sin recargar. Puedes probarlo en Chrome, en las herramientas de desarrollo, panel Rendering, con «Emulate CSS media feature prefers-contrast».

La tercera preferencia es \`prefers-reduced-motion: reduce\`. Cada gráfico entra con una animación corta, de 280 ms, que lo descubre de izquierda a derecha. Con esa preferencia, la animación no se ejecuta y el gráfico aparece ya dibujado.

## 4. Nombre, descripción y tabla

Sustituye \`src/App.tsx\` por el gráfico de visitas con su información accesible:

\`\`\`tsx
import { LineChart } from '@silverpoint/react/line-chart';
import { traffic } from './traffic';

export default function App() {
  return (
    <main style={{ maxWidth: 640 }}>
      <LineChart
        id="hits"
        data={traffic}
        xKey="hour"
        valueKey="hits"
        title="Hits per hour"
        label="Hits per hour over the last 24 hours"
        description="Hits fall to 9 thousand at 03:00, peak at 64 thousand at 12:00 and close the day at 20 thousand."
        dataTable="visible"
        height={200}
      />
    </main>
  );
}
\`\`\`

Así queda la estructura que lee un lector de pantalla:

| Elemento | Qué lleva |
|---|---|
| El contenedor | \`role="group"\`, \`tabindex="0"\` y \`aria-label\` con el nombre del gráfico |
| El SVG | \`role="img"\`, con un \`<title>\` y un \`<desc>\` |
| La tabla | Una fila por dato, con el nombre del gráfico como \`<caption>\` |

\`label\` es el nombre accesible. Va en el \`aria-label\`, en el \`<title>\` del SVG y en el título de la tabla. El título visible de la tarjeta sigue siendo \`title\`. Sin \`label\`, el nombre accesible es el propio \`title\`.

\`description\` sustituye a la descripción que el gráfico genera. Sin ella, el gráfico escribe una a partir de sus datos. Para este gráfico sería «Hits per hour. Line chart of 24 hour values; hits ranges from 9 to 64.». Es correcta, pero no dice lo que importa: cuándo está el pico. Una descripción propia lo cuenta.

\`dataTable="visible"\` muestra la tabla debajo del gráfico. Por defecto existe pero está oculta a la vista, disponible para los lectores de pantalla. Las cabeceras de sus columnas son los nombres de los campos (\`hour\`, \`hits\`), así que conviene que esos nombres se entiendan.

## 5. El teclado

Cada gráfico es una parada del tabulador. Al llegar con \`Tab\`, se activa el primer elemento, se dibuja su marcador y aparece la lectura emergente, igual que al pasar el puntero.

| Tecla | Qué hace |
|---|---|
| Flecha derecha o abajo | El elemento siguiente |
| Flecha izquierda o arriba | El elemento anterior |
| \`Home\` y \`End\` | El primer y el último elemento |
| \`Escape\` | Desactiva el elemento |
| \`Enter\` o espacio | Selecciona el elemento activo |

En los gráficos de rejilla, como el mapa de calor, las flechas se mueven en dos dimensiones: izquierda y derecha dentro de la fila, arriba y abajo entre filas, y \`Home\` y \`End\` van al principio y al final de la fila. Los gráficos jerárquicos, como el treemap o el sunburst, siguen el patrón de árbol de WAI-ARIA: abajo y arriba recorren los nodos en profundidad, derecha baja al primer hijo e izquierda sube al padre.

El contenedor enfocado muestra un contorno con el color de la tinta. La selección con \`Enter\` o espacio llega al mismo evento que un clic; el artículo 11 la usa.

## 6. Lo que se anuncia

Cada gráfico tiene una región \`aria-live="polite"\`. Cuando cambia el elemento activo, con el puntero o con el teclado, el lector de pantalla anuncia su valor: en el gráfico de visitas, «hour 12, hits 64». En el mapa de calor anuncia la fila, la columna y el valor: «day Wed, 08-12 34». En un treemap anuncia el camino desde la raíz, el valor y la parte de su padre: «node City budget › Public works, amount 19,197, 27.7% of City budget».

La lectura emergente que se ve está marcada con \`aria-hidden\`, así que no se lee dos veces. El texto del anuncio y el de la tabla salen del mismo cálculo, de modo que siempre dicen lo mismo.

## 7. Contraste y tramado

Cada estilo base garantiza un contraste mínimo contra su sustrato: 4,5:1 para el texto y 3:1 para los objetos gráficos. Es una comprobación de la integración continua del proyecto: un estilo base que no la cumple no se publica. Las seis paletas incluidas también la superan. Una paleta propia puede no hacerlo; en desarrollo, la librería avisa con \`SP023\`, y el artículo 12 explica cómo comprobarla antes.

La otra garantía es que ningún gráfico comunica algo solo con el tramado. En la captura se ve: en modo \`precision\` el mapa de calor ya no tiene tono, pero cada celda sigue escribiendo su valor. El gráfico de anillo nombra cada sector con su porcentaje en la leyenda, y las barras se leen contra el eje. El tono repite lo que ya dice un número, una etiqueta o una posición, y por eso el modo \`precision\` no pierde información.

## 8. En Reflex

En Reflex las props son las mismas, en \`snake_case\`. Crea \`ops_panel/ops_data.py\`:

\`\`\`python
SALES = [
    {"channel": "Web", "sales": 46},
    {"channel": "App", "sales": 31},
    {"channel": "Partners", "sales": 15},
    {"channel": "Phone", "sales": 8},
]

BLOCKS = ["00-04", "04-08", "08-12", "12-16", "16-20", "20-24"]

ERRORS = [
    {"day": "Mon", "values": [3, 5, 31, 38, 22, 8]},
    {"day": "Tue", "values": [2, 6, 28, 35, 20, 7]},
    {"day": "Wed", "values": [4, 7, 34, 40, 25, 9]},
    {"day": "Thu", "values": [3, 5, 29, 36, 21, 8]},
    {"day": "Fri", "values": [2, 6, 26, 30, 18, 10]},
    {"day": "Sat", "values": [1, 2, 9, 12, 10, 6]},
    {"day": "Sun", "values": [1, 1, 7, 10, 8, 5]},
]
\`\`\`

Y sustituye \`ops_panel/ops_panel.py\`:

\`\`\`python
import reflex as rx
from reflex_silverpoint_react import bar_chart, heatmap_chart, line_chart

from .ops_data import BLOCKS, ERRORS, SALES
from .traffic import TRAFFIC


def mode_column(mode: str) -> rx.Component:
    return rx.box(
        bar_chart(
            id=f"sales-{mode}",
            data=SALES,
            x_key="channel",
            value_key="sales",
            title="Sales by channel",
            badge=mode,
            mode=mode,
        ),
        heatmap_chart(
            id=f"errors-{mode}",
            data=ERRORS,
            label_key="day",
            values_key="values",
            column_labels=BLOCKS,
            scale_max=40,
            title="Errors by day and hour",
            badge=mode,
            mode=mode,
            height=220,
        ),
        display="grid",
        gap="24px",
    )


def index() -> rx.Component:
    return rx.box(
        rx.box(
            mode_column("ink"),
            mode_column("precision"),
            display="grid",
            grid_template_columns="1fr 1fr",
            gap="24px",
        ),
        rx.box(
            line_chart(
                id="hits",
                data=TRAFFIC,
                x_key="hour",
                value_key="hits",
                title="Hits per hour",
                label="Hits per hour over the last 24 hours",
                description=(
                    "Hits fall to 9 thousand at 03:00, peak at 64 thousand at 12:00 "
                    "and close the day at 20 thousand."
                ),
                data_table="visible",
                height=200,
            ),
            max_width="640px",
        ),
        display="grid",
        gap="32px",
        max_width="1100px",
        padding="32px",
    )


app = rx.App()
app.add_page(index)
\`\`\`

\`mode_column\` es una función normal de Python que devuelve un componente; se llama dos veces, una por modo. Lo demás funciona igual que en React: la misma estructura accesible, el mismo teclado, los mismos anuncios y el mismo modo impuesto por el sistema, porque Reflex dibuja con el componente de React.

## Comprobarlo tú mismo

* **Con el teclado.** Pulsa \`Tab\` hasta llegar al gráfico y recórrelo con las flechas. El marcador y la lectura deben seguir al foco.
* **Con un lector de pantalla.** NVDA o JAWS en Windows, VoiceOver en macOS y Orca en Linux anuncian el nombre al entrar y el valor de cada elemento al moverte.
* **Con más contraste.** Activa «Aumentar contraste» en tu sistema, o emula \`prefers-contrast: more\` en las herramientas de desarrollo. Los gráficos deben pasar a \`precision\` sin recargar.
* **Sin estilos.** Si ves la tabla de datos sin haber pedido \`dataTable="visible"\`, falta \`@silverpoint/grounds/styles.css\`: es la hoja que la oculta a la vista.

## Lo que viene

El artículo 11 usa el elemento activo y la selección desde tu propio código: una lectura junto al gráfico, una lista de horas seleccionadas y una descripción emergente a medida, en los cuatro frameworks.
`))))),s(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},s(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},s(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},s(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),s(i,{"aria-label":`Enviar un correo a ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},s(u,{"aria-hidden":`true`,size:16}),s(`span`,{},`ecrespo@gmail.com`))),s(`p`,{className:`text-sm text-gray-700`},s(`span`,{},`Hecho con `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),s(`span`,{},` · alojado en `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),s(`nav`,{"aria-label":`Redes sociales`,className:`flex items-center gap-4`},s(i,{"aria-label":`Medium (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),s(i,{"aria-label":`LinkedIn (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),s(i,{"aria-label":`Twitter (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),s(i,{"aria-label":`GitHub (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),s(i,{"aria-label":`GitLab (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),s(i,{"aria-label":`Blog (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},s(p,{"aria-hidden":`true`,size:18})))),s(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},s(`span`,{},`© 2026 Ernesto Crespo. Todos los derechos reservados.`),s(`span`,{},`Código fuente bajo la `,s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`licencia Apache 2.0`),` · `,s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`Ver el código`)))))),s(`title`,{},`Blog | Silverpoint, artículo 10: modo precision y accesibilidad`),s(`meta`,{content:`Qué quita el modo precision y qué deja igual, cuándo lo impone el sistema, y cómo se leen los gráficos de silverpoint sin verlos: nombre, descripción, tabla de datos, teclado y anuncios.`,name:`description`}),s(`meta`,{content:`https://www.seraph.to/blog/images/silverpoint-serie-10.png`,property:`og:image`}),s(`meta`,{content:`article`,property:`og:type`}),s(`meta`,{content:`Ernesto Crespo`,property:`og:site_name`}),s(`meta`,{content:`Silverpoint, artículo 10: modo precision y accesibilidad`,property:`og:title`}),s(`meta`,{content:`https://www.seraph.to/es/blog/silverpoint_serie_10`,property:`og:url`}),s(`meta`,{content:`summary_large_image`,name:`twitter:card`}),s(`meta`,{content:`Silverpoint, artículo 10: modo precision y accesibilidad`,name:`twitter:title`}),s(`meta`,{content:`https://www.seraph.to/blog/images/silverpoint-serie-10.png`,name:`twitter:image`}),s(`meta`,{content:`Qué quita el modo precision y qué deja igual, cuándo lo impone el sistema, y cómo se leen los gráficos de silverpoint sin verlos: nombre, descripción, tabla de datos, teclado y anuncios.`,property:`og:description`}),s(`meta`,{content:`Qué quita el modo precision y qué deja igual, cuándo lo impone el sistema, y cómo se leen los gráficos de silverpoint sin verlos: nombre, descripción, tabla de datos, teclado y anuncios.`,name:`twitter:description`}))}A.displayName=`Component(es/blog/silverpoint_serie_10)`;var j=n(A);export{j as default};