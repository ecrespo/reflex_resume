import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Ft as r,Wt as i,nt as a,qt as o,rt as s}from"./createLucideIcon-b25sFGBl.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-C7JOVRFB.js";import{a as m,c as h,f as g,g as _,i as v,l as y,m as b,n as x,o as S,r as C,t as w,u as T}from"./one-dark-DBSD_jcZ.js";import{n as E,t as D}from"./code-Ddn1zX93.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>r(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>r(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>r(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>r(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>r(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>r(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>r(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>r(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>r(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>r(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>r(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>r(D,{...n},t),pre:({node:t,...n})=>{let{node:i,className:a,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(a||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return r(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?x:w,wrapLongLines:!0,...s})}}}function A(){return r(O.Fragment,{},r(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`en`},r(O.Fragment,{},r(`div`,{className:`md:hidden`},r(_,{},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),r(`div`,{className:`w-full px-4`},r(b,{},`Download Resume`)),r(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(o,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/comocrearunmetapaquete-2`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),r(`div`,{className:`w-full px-4`},r(b,{},`Download Resume`)),r(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(o,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/comocrearunmetapaquete-2`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},r(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},r(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},r(`div`,{className:`md:hidden flex-shrink-0`},r(g,{},`Menu`)),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/`},`Home`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/resume`},`Resume`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/portfolio`},`Portfolio`),r(o,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/blog`},`Blog`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/dev-dashboard-stats`},`Dev Dashboard Stats`),r(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/archives`},`Archives`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/categories`},`Categories`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/tags`},`Tags`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/feed.xml`},`Atom`))),r(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},r(`div`,{className:`container mx-auto max-w-4xl`},r(`div`,{className:`mb-6`},r(l,{href:`/blog`},`← Back to the blog`)),r(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},r(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`How to create a metapackage (version 2)`),r(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},r(`span`,{className:`text-[#3E6A5E]`},`September 21, 2011`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(d,{size:`sm`,tone:2},`Linux, Packaging`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`By`,r(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),r(`article`,{className:`post-content`,lang:`en`},r(`div`,{className:`prose prose-lg max-w-none`},r(T,{components:k(),rehypePlugins:[S,m,v],remarkPlugins:[y,h]},`This article is an update of the article about **how to create a metapackage**, which you can read [here](/blog/comocrearmetapaquete).

This article adds the \`changelog\` and \`copyright\` files for the \`canaima-caribay-radio\` metapackage.

Create a working directory:  

\`\`\`
mkdir canaima-caribay-radio
\`\`\`

Now create the \`control\` file with the \`equivs-control\` command:

\`\`\`
equivs-control canaima-caribay-radio
\`\`\`

Now the file will be modified so that it has the dependencies for \`jackd2, icecast2, audacity, easytag\` and \`idjc\`. The package maintainer, its \`homepage\`, and a short and long description of the metapackage are added.

The modified file:

\`\`\`
Section: misc
Priority: optional
Homepage: http://canaima.softwarelibre.gob.ve
Standards-Version: 3.6.2


Package: canaima-caribay-radio
Version: 1.0
Maintainer: Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
Depends: jackd2, libjack-jackd2-0, libjack-jackd2-dev, pulseaudio-module-jack, qjackctl, libjack-jackd2-0,  
libjack-jackd2-dev, vorbis-tools, libvorbis-dev, libogg-dev, libmad0-dev, libsamplerate0-dev, libflac-dev,   
libsndfile1-dev, libavcodec-dev, libavformat-dev, libspeex-dev, python-gtk2-dev, python-mutagen, libdbus-1-dev, ffmpeg,  
libshout3-dev, libtwolame-dev, twolame, idjc, audacity, audacity-data, audacity-dbg, icecast2, easytag
Architecture: all
Copyright: copyright
Changelog: changelog 
Description: Metapaquete para la instalacion de radio streaming
Metapaquete para la instalacion de radio streaming con icecast2 e idjc.
\`\`\`

Compared with the previous article, the \`Copyright\` and \`Changelog\` fields were added.

These files contain the following:

Copyright:

\`\`\`
Authors:

Copyright (C) 2011 Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
Copyright (C) 2011 David Hernández <david.vzla@gmail.com>


License:


This package is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 dated June, 1991.


This package is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.


You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA


On Debian GNU/Linux systems, the complete text of the GNU General
Public License can be found in \`/usr/share/common-licenses/GPL-2'.

\`\`\`

Changelog:

\`\`\`
canaima-caribay-radio (1:1.0) unstable; urgency=low


* First release.


-- Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>  Tue, 20 Sep 2011 16:12:45 -0430
\`\`\`

Now, to create and sign the metapackage, use the \`equivs-build\` command with the \`-f\` option, which runs a full \`debuild\` and signs the metapackage.

It is important to note that the \`gpg\` key must contain the maintainer name that appears in the control and changelog files in order to sign the metapackage.

The gpg key is shown below:
\`gpg --list-keys | less\`

\`\`\`
--------------------------------
pub   1024D/C97E7015 2005-08-15
uid  Ernesto Nadir Crespo Avila (seraph1) <ecrespo@debian.org.ve>
uid  Ernesto Nadir Crespo Avila (seraph1) <ecrespo@debianvenezuela.org>
uid  Ernesto Nadir Crespo Avila (seraph1) <ecrespo@uc.edu.ve>
uid  Ernesto Nadir Crespo Avila (seraph1) <ecrespo@cantv.net>
uid  Ernesto Nadir Crespo Avila (seraph1) <ecrespo@gmail.com>
uid  Ernesto Crespo (seraph1) <ecrespoa@yahoo.es>
uid  Ernesto Nadir Crespo Avila (seraph) <ernesto@crespo.info.ve>
uid  [jpeg image of size 11184]
uid  Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
uid  Ernesto Nadir Crespo Avila <ernesto@crespo.org.ve>
\`\`\`

Now the metapackage (\`metapaquete\`) will be created: the procedure will ask twice for the \`gpg\` key passphrase.

\`\`\`
equivs-build -f canaima-caribay-radio
\`\`\`

\`\`\`
dpkg-buildpackage: exportar «CFLAGS» de dpkg-buildflags (origen: «vendor»): «-g -O2»
dpkg-buildpackage: exportar «CPPFLAGS» de dpkg-buildflags (origen: «vendor»): «»
dpkg-buildpackage: exportar «CXXFLAGS» de dpkg-buildflags (origen: «vendor»): «-g -O2»
dpkg-buildpackage: exportar «FFLAGS» de dpkg-buildflags (origen: «vendor»): «-g -O2»
dpkg-buildpackage: exportar «LDFLAGS» de dpkg-buildflags (origen: «vendor»): «»
dpkg-buildpackage: paquete fuente canaima-caribay-radio
dpkg-buildpackage: versión de las fuentes 1:1.0
dpkg-buildpackage: fuentes modificadas por Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
dpkg-buildpackage: arquitectura del sistema amd64
dpkg-source --before-build equivs.nAXaSZ
fakeroot debian/rules clean
dh_testdir
dh_testroot
dh_clean
dh_clean: Compatibility levels before 5 are deprecated.
dpkg-source -b equivs.nAXaSZ
dpkg-source: aviso: no se ha definido un formato de fuentes en «debian/source/format», consulte dpkg-source(1)
dpkg-source: información: usando el formato de fuente «1.0»
dpkg-source: aviso: el directorio de fuentes «equivs.nAXaSZ» no es <paquete-fuente>-<versión-desarrollador-original> «canaima-caribay-radio-1.0»
dpkg-source: información: construyendo canaima-caribay-radio en canaima-caribay-radio_1.0.tar.gz
dpkg-source: información: construyendo canaima-caribay-radio en canaima-caribay-radio_1.0.dsc
debian/rules build
make: No se hace nada para \`build'.
fakeroot debian/rules binary
dh_testdir
dh_testroot
dh_clean -k
dh_clean: dh_clean -k is deprecated; use dh_prep instead
dh_clean: Compatibility levels before 5 are deprecated.
dh_testdir
dh_testroot
dh_install
dh_install: Compatibility levels before 5 are deprecated.
dh_installdocs
dh_installdocs: Compatibility levels before 5 are deprecated.
dh_installchangelogs
dh_installchangelogs: Compatibility levels before 5 are deprecated.
dh_compress
dh_compress: Compatibility levels before 5 are deprecated.
dh_fixperms
dh_fixperms: Compatibility levels before 5 are deprecated.
dh_installdeb
dh_installdeb: Compatibility levels before 5 are deprecated.
dh_gencontrol
dh_gencontrol: Compatibility levels before 5 are deprecated.
dh_md5sums
dh_md5sums: Compatibility levels before 5 are deprecated.
dh_builddeb
dh_builddeb: Compatibility levels before 5 are deprecated.
dpkg-deb: construyendo el paquete \`canaima-caribay-radio' en \`../canaima-caribay-radio_1.0_all.deb'.
signfile canaima-caribay-radio_1.0.dsc

Necesita una frase contraseña para desbloquear la clave secreta
del usuario: "Ernesto Nadir Crespo Avila (seraph1) <ecrespo@debian.org.ve>"
clave DSA de 1024 bits, ID C97E7015, creada el 2005-08-15


dpkg-genchanges  >../canaima-caribay-radio_1.0_amd64.changes
dpkg-genchanges: incluyendo el código fuente completo en la subida
signfile canaima-caribay-radio_1.0_amd64.changes

Necesita una frase contraseña para desbloquear la clave secreta
del usuario: "Ernesto Nadir Crespo Avila (seraph1) <ecrespo@debian.org.ve>"
clave DSA de 1024 bits, ID C97E7015, creada el 2005-08-15


dpkg-source --after-build equivs.nAXaSZ
dpkg-buildpackage: subida completa; paquete nativo de Debian (se incluye la fuente completa)

The package has been created.
Attention, the package has been created in the current directory,
not in ".." as indicated by the message above!
\`\`\`

Now run \`ls -l\` and you get the following:
\`\`\`
ernesto@zeath:~/canaima/canaima-caribay-radio$ ls -l
total 28
-rw-r--r-- 1 ernesto ernesto  849 sep 20 17:03 canaima-caribay-radio
-rw-r--r-- 1 ernesto ernesto 2528 sep 21 08:48 canaima-caribay-radio_1.0_all.deb
-rw-r--r-- 1 ernesto ernesto 1583 sep 21 08:49 canaima-caribay-radio_1.0_amd64.changes
-rw-r--r-- 1 ernesto ernesto  819 sep 21 08:49 canaima-caribay-radio_1.0.dsc
-rw-r--r-- 1 ernesto ernesto 2170 sep 21 08:48 canaima-caribay-radio_1.0.tar.gz
-rw-r--r-- 1 ernesto ernesto  164 sep 20 17:03 changelog
-rw-r--r-- 1 ernesto ernesto  957 sep 20 17:03 copyright
\`\`\`

The file \`canaima-caribay-radio_1.0_amd64.changes\` contains the following:  

\`\`\`
-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA1

Format: 1.8
Date: Tue, 20 Sep 2011 16:12:45 -0430
Source: canaima-caribay-radio
Binary: canaima-caribay-radio
Architecture: source all
Version: 1:1.0
Distribution: unstable
Urgency: low
Maintainer: Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
Changed-By: Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
Description: 
 canaima-caribay-radio - Metapaquete para la instalacion de radio streaming
Changes: 
 canaima-caribay-radio (1:1.0) unstable; urgency=low
 .
   * First release.
Checksums-Sha1: 
 2234f6f5d8808e0ae425eb3164632b01bc94251a 819 canaima-caribay-radio_1.0.dsc
 8851015c0174d5126127328776e35174e361cc21 2170 canaima-caribay-radio_1.0.tar.gz
 104312d9eb56eb623ad1f901a2801e096f4021be 2528 canaima-caribay-radio_1.0_all.deb
Checksums-Sha256: 
 3be03f102f6ef9dab2525ac384a265e9761ca2f5f4fb7d48fdbd0b38fee4e22f 819 canaima-caribay-radio_1.0.dsc
 75cb5c5b95d14d995776a035925c2cfe5ee77873d091ef9e238b000fb4b1375b 2170 canaima-caribay-radio_1.0.tar.gz
 74540c21659c774a12d5162886f59b974b155c47d5471fac40ff7fece11cd282 2528 canaima-caribay-radio_1.0_all.deb
Files: 
 3f563e110433652011cf0d32fe96a0f6 819 misc optional canaima-caribay-radio_1.0.dsc
 e53b6a60fd0961a6b161a61b5a107e77 2170 misc optional canaima-caribay-radio_1.0.tar.gz
 4ac58a93d2e4160f378093909d687967 2528 misc optional canaima-caribay-radio_1.0_all.deb

 -----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.10 (GNU/Linux)

iEYEARECAAYFAk555EYACgkQh+iQYcl+cBW/kQCeOZzpeHCAYomqczO7kkR6+nvT
fWIAniK+uWLpndvqEJmz2IUA7JNe8Nng
=qVVe
 -----END PGP SIGNATURE-----
\`\`\`

The file \`canaima-caribay-radio_1.0.dsc\` contains the following:

\`\`\`
-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA1

Format: 1.0
Source: canaima-caribay-radio
Binary: canaima-caribay-radio
Architecture: all
Version: 1:1.0
Maintainer: Ernesto Nadir Crespo Avila <ecrespo@cenditel.gob.ve>
Homepage: http://canaima.softwarelibre.gob.ve
Standards-Version: 3.6.2
Build-Depends: debhelper (>= 4)
Checksums-Sha1: 
 8851015c0174d5126127328776e35174e361cc21 2170 canaima-caribay-radio_1.0.tar.gz
Checksums-Sha256: 
 75cb5c5b95d14d995776a035925c2cfe5ee77873d091ef9e238b000fb4b1375b 2170 canaima-caribay-radio_1.0.tar.gz
Files: 
 e53b6a60fd0961a6b161a61b5a107e77 2170 canaima-caribay-radio_1.0.tar.gz

 -----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.10 (GNU/Linux)

iEYEARECAAYFAk555EIACgkQh+iQYcl+cBVLqgCdGA+DXaVjyDrcGNfxcITL9sCP
oY0An1hC/e7UIQiiTZ4DQUysYHs8sTS9
=6NcI
-----END PGP SIGNATURE-----
\`\`\`

##  ##
Make a donation!
If you liked the article you can make a donation with Bitcoin (BTC)
using the digital wallet of your choice to the following
address: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

Or by scanning the QR code from the wallet:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))),r(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},r(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},r(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),r(o,{"aria-label":`Send an e-mail to ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},r(u,{"aria-hidden":`true`,size:16}),r(`span`,{},`ecrespo@gmail.com`))),r(`p`,{className:`text-sm text-gray-700`},r(`span`,{},`Built with `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),r(`span`,{},` · hosted on `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),r(`nav`,{"aria-label":`Social networks`,className:`flex items-center gap-4`},r(o,{"aria-label":`Medium (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),r(o,{"aria-label":`LinkedIn (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),r(o,{"aria-label":`Twitter (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),r(o,{"aria-label":`GitHub (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),r(o,{"aria-label":`GitLab (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),r(o,{"aria-label":`Blog (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},r(p,{"aria-hidden":`true`,size:18})))),r(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},r(`span`,{},`© 2026 Ernesto Crespo. All rights reserved.`),r(`span`,{},`Source code under the `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`Apache 2.0 License`),` · `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`View the source`)))))),r(`title`,{},`Blog | How to create a metapackage (version 2)`),r(`meta`,{content:`https://www.seraph.to/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png`,property:`og:image`}),r(`meta`,{content:`article`,property:`og:type`}),r(`meta`,{content:`Ernesto Crespo`,property:`og:site_name`}),r(`meta`,{content:`How to create a metapackage (version 2)`,property:`og:title`}),r(`meta`,{content:`https://www.seraph.to/blog/comocrearunmetapaquete-2`,property:`og:url`}),r(`meta`,{content:`summary_large_image`,name:`twitter:card`}),r(`meta`,{content:`How to create a metapackage (version 2)`,name:`twitter:title`}),r(`meta`,{content:`https://www.seraph.to/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png`,name:`twitter:image`}))}A.displayName=`Component(blog/comocrearunmetapaquete-2)`;var j=n(A);export{j as default};