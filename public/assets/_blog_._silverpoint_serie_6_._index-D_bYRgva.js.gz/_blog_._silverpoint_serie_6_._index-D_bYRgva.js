import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Ft as r,Wt as i,nt as a,qt as o,rt as s}from"./createLucideIcon-D_wAYqau.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-p44Mj3iQ.js";import{a as m,c as h,f as g,g as _,i as v,l as y,m as b,n as x,o as S,r as C,t as w,u as T}from"./one-dark-B4TnxH60.js";import{n as E,t as D}from"./code-BtA91MnZ.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>r(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>r(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>r(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>r(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>r(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>r(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>r(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>r(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>r(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>r(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>r(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>r(D,{...n},t),pre:({node:t,...n})=>{let{node:i,className:a,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(a||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return r(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?x:w,wrapLongLines:!0,...s})}}}function A(){return r(O.Fragment,{},r(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`en`},r(O.Fragment,{},r(`div`,{className:`md:hidden`},r(_,{},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),r(`div`,{className:`w-full px-4`},r(b,{},`Download Resume`)),r(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(o,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/silverpoint_serie_6`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),r(`div`,{className:`w-full px-4`},r(b,{},`Download Resume`)),r(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(o,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/silverpoint_serie_6`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},r(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},r(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},r(`div`,{className:`md:hidden flex-shrink-0`},r(g,{},`Menu`)),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/`},`Home`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/resume`},`Resume`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/portfolio`},`Portfolio`),r(o,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/blog`},`Blog`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/dev-dashboard-stats`},`Dev Dashboard Stats`),r(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/archives`},`Archives`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/categories`},`Categories`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/tags`},`Tags`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/feed.xml`},`Atom`))),r(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},r(`div`,{className:`container mx-auto max-w-4xl`},r(`div`,{className:`mb-6`},r(l,{href:`/blog`},`← Back to the blog`)),r(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},r(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`Silverpoint, article 06: your first chart in Reflex, with Python only`),r(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},r(`span`,{className:`text-[#3E6A5E]`},`November 11, 2026`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(d,{size:`sm`,tone:2},`Silverpoint tutorial`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`By`,r(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),r(`article`,{className:`post-content`,lang:`en`},r(`div`,{className:`prose prose-lg max-w-none`},r(T,{components:k(),rehypePlugins:[S,m,v],remarkPlugins:[y,h]},`This is the Reflex article of level 1 of the series on [silverpoint](https://github.com/ecrespo/silverpoint). It builds the same chart that [article 03](/blog/silverpoint_serie_3) builds in React, [04](/blog/silverpoint_serie_4) in Vue and [05](/blog/silverpoint_serie_5) in Angular, but here everything is written in Python. You can read this one alone: everything is installed from scratch.

## What you will build

The first piece of the series' operations panel: a line chart with the hits per hour to a web service over the last 24 hours, in thousands.

![The hits-per-hour chart, drawn with Reflex](/blog/images/silverpoint-serie-6.png)

By the end you will have the chart with your own data, the card text and the data loaded into the Reflex state from a JSON file, as you would with an API or a database.

## What you need

* Python 3.11 or later. This article uses 3.13.
* [uv](https://docs.astral.sh/uv/), for the project and its dependencies.
* Knowing the basics of Reflex: components, state and events.

There is no need to write JavaScript. Reflex downloads Bun, the JavaScript runtime it builds the page with, the first time it needs it.

## 1. Create the project

\`\`\`sh
mkdir ops_panel && cd ops_panel
uv init --python 3.13
uv add reflex-silverpoint-react
uv run reflex init --template blank
rm main.py
\`\`\`

\`uv add reflex-silverpoint-react\` installs the package and, as a dependency, Reflex. \`reflex init\` creates \`rxconfig.py\` and the application module, \`ops_panel/ops_panel.py\`. The \`main.py\` that \`uv init\` generates is not used.

There is nothing to install on the JavaScript side. When it compiles, Reflex installs \`@silverpoint/react\` and the other npm packages at the versions the package pins, and each component imports the stylesheets it needs.

## 2. The first chart

Replace \`ops_panel/ops_panel.py\`:

\`\`\`python
import reflex as rx
from reflex_silverpoint_react import line_chart


def index() -> rx.Component:
    return rx.box(
        line_chart(title="Hits per hour"),
        max_width="640px",
        padding="32px",
    )


app = rx.App()
app.add_page(index)
\`\`\`

Start the application:

\`\`\`sh
uv run reflex run
\`\`\`

And open \`http://localhost:3000\`. You will see a line chart with twelve hours and two series: the solid line and a dotted baseline.

It is the chart's demo data: when it does not receive \`data\`, it draws its own. It is there to check that the installation works.

Every component comes from the same module, \`reflex_silverpoint_react\`, with \`snake_case\` names: the charts with no prefix (\`line_chart\`, \`bar_chart\`) and the UI components with \`sp_\` (\`sp_button\`).

## 3. Your own data

Create \`ops_panel/traffic.py\` with one day of hits, one row per hour:

\`\`\`python
TRAFFIC = [
    {"hour": "00", "hits": 18},
    {"hour": "01", "hits": 14},
    {"hour": "02", "hits": 11},
    {"hour": "03", "hits": 9},
    {"hour": "04", "hits": 11},
    {"hour": "05", "hits": 16},
    {"hour": "06", "hits": 24},
    {"hour": "07", "hits": 33},
    {"hour": "08", "hits": 42},
    {"hour": "09", "hits": 51},
    {"hour": "10", "hits": 58},
    {"hour": "11", "hits": 62},
    {"hour": "12", "hits": 64},
    {"hour": "13", "hits": 61},
    {"hour": "14", "hits": 59},
    {"hour": "15", "hits": 58},
    {"hour": "16", "hits": 57},
    {"hour": "17", "hits": 52},
    {"hour": "18", "hits": 47},
    {"hour": "19", "hits": 41},
    {"hour": "20", "hits": 30},
    {"hour": "21", "hits": 26},
    {"hour": "22", "hits": 22},
    {"hour": "23", "hits": 20},
]

PEAK = max(TRAFFIC, key=lambda row: row["hits"])
\`\`\`

Pass the data to the chart and complete the card. Replace \`ops_panel/ops_panel.py\`:

\`\`\`python
import reflex as rx
from reflex_silverpoint_react import line_chart

from .traffic import PEAK, TRAFFIC


def index() -> rx.Component:
    return rx.box(
        line_chart(
            data=TRAFFIC,
            x_key="hour",
            value_key="hits",
            title="Hits per hour",
            badge="Today",
            value=PEAK["hits"],
            unit="k hits at the peak",
            footer_left="Last 24 hours",
            footer_right=f"Peak at {PEAK['hour']}:00",
            height=200,
        ),
        max_width="640px",
        padding="32px",
    )


app = rx.App()
app.add_page(index)
\`\`\`

The props are the same as in React, written in \`snake_case\`:

| Prop | What it does |
|---|---|
| \`data\` | The rows that are drawn |
| \`x_key\` | The field of each row that goes on the horizontal axis |
| \`value_key\` | The field with the value the line draws |
| \`title\` | The card title |
| \`badge\` | A short label, top right |
| \`value\` and \`unit\` | The highlighted value and its unit, below the title |
| \`footer_left\` and \`footer_right\` | The card footer |
| \`height\` | The height of the drawing area in pixels; 160 by default |

The width is not set: the chart takes its container's, the 640-pixel \`rx.box\`.

Here the data are Python constants. Reflex writes them into the page when it compiles, so this version does not need the backend to show the chart.

The white heightened point is at the end of the line, not at the peak. It is the single heightening rule from article 01: in a line chart, the live value is heightened, the last one of the series. The peak is told by the highlighted value and the footer.

## 4. Load the data into the state

In a real panel the data comes from an API or a database, and it changes. In Reflex, that is the state's job: the backend reads the data and the page updates.

To simulate it, create \`data/traffic.json\` at the project root, next to \`rxconfig.py\`, with a timestamp and the number of requests per hour:

\`\`\`json
[
  {"time": "2026-11-11T00:00:00Z", "requests": 17800},
  {"time": "2026-11-11T01:00:00Z", "requests": 13937},
  {"time": "2026-11-11T02:00:00Z", "requests": 11074},
  {"time": "2026-11-11T03:00:00Z", "requests": 8811},
  {"time": "2026-11-11T04:00:00Z", "requests": 10948},
  {"time": "2026-11-11T05:00:00Z", "requests": 16085},
  {"time": "2026-11-11T06:00:00Z", "requests": 23822},
  {"time": "2026-11-11T07:00:00Z", "requests": 32959},
  {"time": "2026-11-11T08:00:00Z", "requests": 42096},
  {"time": "2026-11-11T09:00:00Z", "requests": 50833},
  {"time": "2026-11-11T10:00:00Z", "requests": 57970},
  {"time": "2026-11-11T11:00:00Z", "requests": 62107},
  {"time": "2026-11-11T12:00:00Z", "requests": 63844},
  {"time": "2026-11-11T13:00:00Z", "requests": 60981},
  {"time": "2026-11-11T14:00:00Z", "requests": 59118},
  {"time": "2026-11-11T15:00:00Z", "requests": 57855},
  {"time": "2026-11-11T16:00:00Z", "requests": 56992},
  {"time": "2026-11-11T17:00:00Z", "requests": 52129},
  {"time": "2026-11-11T18:00:00Z", "requests": 46866},
  {"time": "2026-11-11T19:00:00Z", "requests": 41003},
  {"time": "2026-11-11T20:00:00Z", "requests": 30140},
  {"time": "2026-11-11T21:00:00Z", "requests": 25877},
  {"time": "2026-11-11T22:00:00Z", "requests": 22014},
  {"time": "2026-11-11T23:00:00Z", "requests": 20151}
]
\`\`\`

And replace \`ops_panel/ops_panel.py\` with the version with state:

\`\`\`python
import json
from pathlib import Path

import reflex as rx
from reflex_silverpoint_react import line_chart

DATA_FILE = Path("data/traffic.json")


class TrafficState(rx.State):
    traffic: list[dict[str, str | int]] = []

    @rx.event
    def load(self):
        rows = json.loads(DATA_FILE.read_text())
        self.traffic = [
            {"hour": row["time"][11:13], "hits": round(row["requests"] / 1000)}
            for row in rows
        ]

    @rx.var
    def peak(self) -> dict[str, str | int]:
        return max(self.traffic, key=lambda row: row["hits"], default={"hour": "", "hits": 0})


def index() -> rx.Component:
    return rx.box(
        rx.cond(
            TrafficState.traffic,
            line_chart(
                data=TrafficState.traffic,
                x_key="hour",
                value_key="hits",
                title="Hits per hour",
                badge="Today",
                value=TrafficState.peak["hits"],
                unit="k hits at the peak",
                footer_left="Last 24 hours",
                footer_right=f"Peak at {TrafficState.peak['hour']}:00",
                height=200,
            ),
            rx.text("Loading…"),
        ),
        max_width="640px",
        padding="32px",
    )


app = rx.App()
app.add_page(index, on_load=TrafficState.load)
\`\`\`

\`ops_panel/traffic.py\` is no longer used; you can delete it. Four decisions in this version:

* **The data is adapted in the backend.** The \`load\` event turns each JSON row into a chart row: the hour comes from the timestamp and the requests become thousands. Only the rows the chart draws reach the browser.
* **The data is loaded when the page opens.** \`on_load=TrafficState.load\` runs the event every time the route opens. To read from an API or a database, only the body of \`load\` changes.
* **While there is no data, there is no chart.** \`rx.cond\` shows "Loading…" while \`traffic\` is empty. Do not pass an empty list to the chart: with empty data it draws its empty state, "No data", not the demo data.
* **The peak is a computed var.** \`peak\` is recomputed every time \`traffic\` changes. In the page it is used like any state var, inside an f-string too: \`f"Peak at {TrafficState.peak['hour']}:00"\` is not fixed text, Reflex turns it into an expression the browser evaluates with the current value.

The \`DATA_FILE\` path is relative to the directory you start Reflex from, the project root.

## 5. Run in production mode

\`\`\`sh
uv run reflex run --env prod
\`\`\`

Reflex builds the optimized frontend and serves the page and the backend on the same port, \`http://localhost:3000\`. To deploy it, the [Reflex deployment guide](https://reflex.dev/docs/hosting/self-hosting/) explains the options.

## Common problems

* **The chart does not appear.** Its container has no width. It happens with an \`rx.hstack\` or an \`rx.flex\` that shrinks to its content: the chart waits until it can measure it and, in development, the browser console shows the \`SP003\` diagnostic. Give the container or the chart a width.
* **The card says "No data".** The name in \`x_key\` or \`value_key\` does not match the fields of the rows. In development, the browser console shows \`SP002\` with the name of the field.
* **"FileNotFoundError: [Errno 2] No such file or directory: 'data/traffic.json'".** You started Reflex from another directory. Run it from the project root, where \`rxconfig.py\` is.
* **The chart stays at "Loading…".** The backend does not respond. Look at the terminal where \`reflex run\` is running: an error in \`load\` shows up there.

The \`SP0xx\` diagnostics only appear in development.

## What comes next

You now have a silverpoint chart in Reflex with your own data, without a line of JavaScript. The next one is 07: the properties the 60 charts share, with their names in the four syntaxes.

The [Reflex guide](https://silverpointweb.vercel.app/docs/reflex) in the documentation has more examples.
`))))),r(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},r(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},r(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),r(o,{"aria-label":`Send an e-mail to ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},r(u,{"aria-hidden":`true`,size:16}),r(`span`,{},`ecrespo@gmail.com`))),r(`p`,{className:`text-sm text-gray-700`},r(`span`,{},`Built with `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),r(`span`,{},` · hosted on `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),r(`nav`,{"aria-label":`Social networks`,className:`flex items-center gap-4`},r(o,{"aria-label":`Medium (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),r(o,{"aria-label":`LinkedIn (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),r(o,{"aria-label":`Twitter (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),r(o,{"aria-label":`GitHub (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),r(o,{"aria-label":`GitLab (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),r(o,{"aria-label":`Blog (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},r(p,{"aria-hidden":`true`,size:18})))),r(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},r(`span`,{},`© 2026 Ernesto Crespo. All rights reserved.`),r(`span`,{},`Source code under the `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`Apache 2.0 License`),` · `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`View the source`)))))),r(`title`,{},`Blog | Silverpoint, article 06: your first chart in Reflex, with Python only`),r(`meta`,{content:`Step by step, from a new Reflex project to the first silverpoint chart without writing JavaScript: installation with uv, your own data, the card text and loading the data into the state with on_load.`,name:`description`}),r(`meta`,{content:`https://www.seraph.to/blog/images/silverpoint-serie-6.png`,property:`og:image`}),r(`meta`,{content:`article`,property:`og:type`}),r(`meta`,{content:`Ernesto Crespo`,property:`og:site_name`}),r(`meta`,{content:`Silverpoint, article 06: your first chart in Reflex, with Python only`,property:`og:title`}),r(`meta`,{content:`https://www.seraph.to/blog/silverpoint_serie_6`,property:`og:url`}),r(`meta`,{content:`summary_large_image`,name:`twitter:card`}),r(`meta`,{content:`Silverpoint, article 06: your first chart in Reflex, with Python only`,name:`twitter:title`}),r(`meta`,{content:`https://www.seraph.to/blog/images/silverpoint-serie-6.png`,name:`twitter:image`}),r(`meta`,{content:`Step by step, from a new Reflex project to the first silverpoint chart without writing JavaScript: installation with uv, your own data, the card text and loading the data into the state with on_load.`,property:`og:description`}),r(`meta`,{content:`Step by step, from a new Reflex project to the first silverpoint chart without writing JavaScript: installation with uv, your own data, the card text and loading the data into the state with on_load.`,name:`twitter:description`}))}A.displayName=`Component(blog/silverpoint_serie_6)`;var j=n(A);export{j as default};