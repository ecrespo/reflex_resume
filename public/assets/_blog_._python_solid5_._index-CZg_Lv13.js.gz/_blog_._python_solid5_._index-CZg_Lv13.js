import{r as e}from"./rolldown-runtime-hePW80VL.js";import{W as t,a as n}from"./components-DO_H3UDc.js";import{B as r,L as i,n as a,t as o}from"./link-COHQ-ppo.js";import{n as s}from"./emotion-react.browser.esm-D8ztlwVE.js";import{n as c,t as l}from"./code-BOOhlaUK.js";import{a as u,d,l as f,o as p,t as m}from"./blog-56V6I352.js";import{a as h,c as g,i as _,l as v,n as y,o as b,r as x,t as S,u as C}from"./one-dark-BaPqULrx.js";var w=e(t(),1);function T(){let{resolvedColorMode:e}=(0,w.useContext)(i);return{h1:({node:e,children:t,...n})=>s(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(a,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(x,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?y:S,wrapLongLines:!0,...o})}}}function E(){return s(w.Fragment,{},s(`div`,{className:`flex min-h-screen font-['Inter'] bg-[#f5f5dc]`},s(w.Fragment,{},s(w.Fragment,{},s(f,{},s(w.Fragment,{},s(d,{})),s(w.Fragment,{}))),s(m,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(r,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`))))),s(`aside`,{className:`hidden md:flex w-96 min-h-screen bg-[#7dd3c0] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-teal-600/10`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(r,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-96`},s(`nav`,{className:`w-full h-14 bg-[#4a9bba] flex items-center shadow-sm flex-shrink-0 z-20 sticky top-0`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(p,{},s(`div`,{className:`flex flex-col`},s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white`}))),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/`},`HOME`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog`},`BLOG`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/tags`},`TAGS`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/feed.xml`},`ATOM`),s(r,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/dev-stats`},`DEV STATS`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(o,{asChild:!0,css:{"&:hover":{color:`var(--accent-8)`}}},s(r,{to:`/blog`},s(`span`,{className:`inline-flex items-center px-4 py-2 bg-[#4a9bba] text-white rounded-lg hover:bg-[#3a8baa] transition-colors font-medium mb-6`},`← Volver al Blog`))),s(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Principios S.O.L.I.D. - 5. Principio de inversión de la dependencia. (DIP - Dependency inversion principle)`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-gray-500`},`May 14, 2022`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-[#4a9bba] font-medium`},`Tutorial Python`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-gray-600`},`Por `),s(`span`,{className:`text-gray-800 font-medium`},`Ernesto Crespo`))),s(`article`,{className:`post-content`},s(`div`,{className:`prose prose-lg max-w-none`},s(C,{components:T(),rehypePlugins:[b,h,_],remarkPlugins:[v,g]},`En ingeniería de software existe el principio [S.O.L.I.D](https://es.wikipedia.org/wiki/SOLID). Los principios SOLID son guías que pueden ser aplicadas en el desarrollo de software para eliminar malos diseños provocando que el programador tenga que refactorizar hasta que sea legible y extensible. 

Sus principios son:

* Single responsability principle - Principio de responsabilidad única.
* Open/closed principle - Principio abierto/cerrado.
* Liskov substitution principle - Principio de sustitución Liskov.
* Interface segregation principle - Principio de segregación de la interfaz.
* Dependency inversion principle - Principio de inversión de la dependencia.


A continuación dejo un vídeo de [ArjanCodes](https://www.youtube.com/watch?v=pTB30aXS77U&t=1s) que explica con código python los principios S.O.L.I.D:

<iframe width="560" height="315" src="https://www.youtube.com/embed/pTB30aXS77U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

Los artículos anteriores:
* [Principio de responsabilidad única (enlace roto)](https://www.seraph.to/python_solid1.html#python_solid1).
* [Principio abierto/cerrado (enlace roto)](https://www.seraph.to/python_solid2.html#python_solid2).
* [Principio de sustitución Liskov (enlace roto)](https://www.seraph.to/python_solid3.html#python_solid3).
* [Principio de segregación de la interfaz (enlace roto)](https://www.seraph.to/python_solid4.html#python_solid4.

El [Principio de inversión de la dependencia](https://es.wikipedia.org/wiki/Principio_de_inversi%C3%B3n_de_la_dependencia) es una forma específica de desacoplar módulos de software. Al seguir el principio, las relaciones de dependencia convencionales establecidas desde los módulos de alto nivel de establecimiento de políticas a los módulos de depencia de bajo nivel se invierten, lo que hace que los módulos de alto nivel sean independientes de los detalles de implementación del módulo de bajo nivel, el principio establece: 

1. Los módulos de alto nivel no deberían depender de los módulos de bajo nivel. Ambos deberían depender de abstracciones (p.ej., interfaces).
2. Las abstracciones no deberían depender de los detalles. Los detalles (implementaciones concretas) deben depender de abstracciones.

La dependencia debe estar en abstracciones, no en concreciones. Los módulos de alto nivel no deben depender de módulos de bajo nivel. Tanto las clases de nivel bajo como las de alto nivel deberían depender de las mismas abstracciones. Las abstracciones no deberían depender de los detalles. Los detalles deben depender de abstracciones.



1. Se tiene el código del artículo anterior sobre el Principio de segregación de interfaz. Con solución usando composición.

En este caso, al pasar como argumento de un método un objeto, ya viola este principio.

\`\`\`python 

class SMSAuth:
    authorized = False

    def verify_code(self,code):
        print(f"Verifying code {code}")
        self.authorized = True

    def is_authorized(self) -> bool:
        return self.authorized 

# Clase abstracta procesamiento de pago con método pay.
class PaymentProcessor(ABC):
    @abstractmethod
    def pay(self,order):
        pass 

# Clase procesamiento pago por tarjeta de debito que hereda de la clase abstracta.
# el método init recibe como argumentos el código de seguridad y la clase SMSAuth para autorizar el pago.
class DebitPaymentProcessor(PaymentProcessor):

    def __init__(self,security_code, authorizer: SMSAuth):

        self.authorizer = authorizer
        self.security_code = security_code

    def pay(self,order):
        # Se consulta si no está autorizado el pago
        # al no tener autorización devuelve una excepción.
        if not self.authorizer.is_authorized():
            raise Exception("Not authorized")
        print("Processing debit payment type")
        print(f"Verifying security code: {self.security_code}")
        order.status = "paid"

# Clase de procesamiento de pago con TC, que hereda de la clase abstracta.
# En este caso no se necesita la clase SMSAuth, sólo el código de seguridad.
class CreditPaymentProcessor(PaymentProcessor):

    def __init__(self,security_code):
        self.security_code = security_code


    def pay(self,order):
        print("Processing credit payment type")
        print(f"Verifying security code: {self.security_code}")
        order.status = "paid"

# Clase de procesamiento de pago vía paypal, hereda de la misma clase abstracta.
# El init recibe de argumentos dirección de correo y el objecto SMSAuth.
class PaypalPaymentProcessor(PaymentProcessor):

    def __init__(self,email_address,authorizer:SMSAuth):
        self.authorizer = authorizer
        self.email_address = email_address
        self.verified = False


    def pay(self,order):
        # Se valida si se tiene autorización para realizar el pago.
        if not self.authorizer.is_authorized():
            raise Exception("Not authorized")
        print("Processing paypal payment type")
        print(f"Verifying email address: {self.email_address}")
        order.status = "paid"

# Ahora se instancia la clase Order, y se agrega los items a comprar en la orden.

order = Order()
order.add_item("Teclado", 1, 50)
order.add_item("Memoria", 1, 150)
order.add_item("Cable USB", 2, 5)

# Imprime el precio total de la orden
print(order.total_price())

# Se define el autorizador.
authorizer = SMSAuth()

# Se define el método de pago debito
# ahora se le pasa el código y el autorizador.

processor = DebitPaymentProcessor("0372846",authorizer)
# Se verifica el pago
authorizer.verify_code(454545)

# Realiza el pago de la orden.
processor.pay(order)

# Se define el método de pago TC
# Para este caso se mantiene igual.
processor = CreditPaymentProcessor("0372846")
processor.pay(order)



# Se define el método de pago paypal
# Se le pasa el correo y el autorizador.
processor = PaypalPaymentProcessor("h@h.com",authorizer)
# Se realiza el pago de la orden.
processor.pay(order)
\`\`\`

La salida de está ejecución es la siguiente:
\`\`\`bash

210
Verifying code 454545
Processing debit payment type
Verifying security code: 0372846

Processing debit payment type
Verifying security code: 0372846

Processing credit payment type
Verifying security code: 0372846

Processing paypal payment type
Verifying email address: h@h.com

\`\`\`

### Solución
Para cumplir el principio de la inversión de la dependencia se crea una clase  abstracta que maneje si se verifica la autenticación junto con la clase AuthSMS, en las respectivas clases del procesamiento de pago que se necesite verificar por SMS, en vez de pasar como argumento el objeto, se pasa la clase abstracta. 

A continuación el código: 

\`\`\`python

from abc import ABC, abstractmethod

# La clase Order 
class Order:

    def __init__(self):
        self.items = []
        self.quantities = []
        self.prices = []
        self.status = "open"

    def add_item(self, name, quantity, price):
        self.items.append(name)
        self.quantities.append(quantity)
        self.prices.append(price)

    def total_price(self):
        total = 0
        for i in range(len(self.prices)):
            total += self.quantities[i] * self.prices[i]
        return total

# Clase abstracta authorizer con método que devuelve si está autorizado o no. 
class Authorizer(ABC):
    @abstractmethod
    def is_authorized(self) ->bool:
        pass


# Clase abstracta de procesamiento de pago
class PaymentProcessor(ABC):
    @abstractmethod
    def pay(self,order):
        pass 

# Clase SMSAutho que hereda de la clase abstracta authorizer
class SMSAuth(Authorizer):
    authorized = False

    def verify_code(self,code):
        print(f"Verifying code {code}")
        self.authorized = True

    def is_authorized(self) -> bool:
        return self.authorized

# clase pago por tarjeta de debito que recibe en el init authorizer que es la clase abstracta.
class DebitPaymentProcessor(PaymentProcessor):

    def __init__(self,security_code, authorizer: Authorizer):

        self.authorizer = authorizer
        self.security_code = security_code

    def pay(self,order):
        # Se consulta si no está autorizado el pago
        # al no tener autorización devuelve una excepción.
        if not self.authorizer.is_authorized():
            raise Exception("Not authorized")
        print("Processing debit payment type")
        print(f"Verifying security code: {self.security_code}")
        order.status = "paid"

# La clase de procesamiento de TC se mantiene igual.
class CreditPaymentProcessor(PaymentProcessor):

    def __init__(self,security_code):
        self.security_code = security_code


    def pay(self,order):
        print("Processing credit payment type")
        print(f"Verifying security code: {self.security_code}")
        order.status = "paid"


# clase dde procesamiento de pago por paypal
# Se le pasa como argumento la clase abstracta.
class PaypalPaymentProcessor(PaymentProcessor):

    def __init__(self,email_address,authorizer:Authorizer):
        self.authorizer = authorizer
        self.email_address = email_address
        self.verified = False


    def pay(self,order):
        # Se valida si se tiene autorización para realizar el pago.
        if not self.authorizer.is_authorized():
            raise Exception("Not authorized")
        print("Processing paypal payment type")
        print(f"Verifying email address: {self.email_address}")
        order.status = "paid"

# Ahora se instancia la clase Order, y se agrega los items a comprar en la orden.

order = Order()
order.add_item("Teclado", 1, 50)
order.add_item("Memoria", 1, 150)
order.add_item("Cable USB", 2, 5)

# Imprime el precio total de la orden
print(order.total_price())

# Se define el autorizador.
authorizer = SMSAuth()

# Se define el método de pago debito
# ahora se le pasa el código y el autorizador.

processor = DebitPaymentProcessor("0372846",authorizer)
# Se verifica el pago
authorizer.verify_code(454545)

# Realiza el pago de la orden.
processor.pay(order)

# Se define el método de pago TC
# Para este caso se mantiene igual.
processor = CreditPaymentProcessor("0372846")
processor.pay(order)



# Se define el método de pago paypal
# Se le pasa el correo y el autorizador.
processor = PaypalPaymentProcessor("h@h.com",authorizer)
# Se realiza el pago de la orden.
processor.pay(order)
\`\`\`

La salida es la siguiente: 

\`\`\`bash 

210
Verifying code 454545
Processing debit payment type
Verifying security code: 0372846

Processing debit payment type
Verifying security code: 0372846

Processing credit payment type
Verifying security code: 0372846

Processing paypal payment type
Verifying email address: h@h.com



\`\`\`

Lo que se logro es ocultar la implementación de la composición que se pasa como argumento en los procesadores de pago que tiene que validar vía SMS.

En próximo artículo 


Referencias: 

* [Principios SOLID en Python](https://softwarecrafters.io/python/principios-solid-python)
* [Los principios SOLID ilustrados en ejemplos sencillos de Python](https://blog.damavis.com/los-principios-solid-ilustrados-en-ejemplos-sencillos-de-python/)
* [Principios SOLID explicados en Python con ejemplos.](https://ichi.pro/es/principios-solid-explicados-en-python-con-ejemplos-56291217871103)
* [The S.O.L.I.D Principles in Python (enlace roto)](https://medium.com/geekculture/the-s-o-l-i-d-principles-in-python-a041c5aa9969#id_token=eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ2M2RiZTczYWFkODhjODU0ZGUwZDhkNmMwMTRjMzZkYzI1YzQyOTIiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2NDY5NjE2MDYsImF1ZCI6IjIxNjI5NjAzNTgzNC1rMWs2cWUwNjBzMnRwMmEyamFtNGxqZGNtczAwc3R0Zy5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwMzA0ODgwMTUxNTE4Mzk4NTA5MyIsImVtYWlsIjoiZWNyZXNwb0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXpwIjoiMjE2Mjk2MDM1ODM0LWsxazZxZTA2MHMydHAyYTJqYW00bGpkY21zMDBzdHRnLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwibmFtZSI6IkVybmVzdG8gQ3Jlc3BvIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hLS9BT2gxNEdpNzZJNGhTTXQ3U1hYbzZjdHdaNDloeDlKbTF3cU93UXZiTU0zbWtHMD1zOTYtYyIsImdpdmVuX25hbWUiOiJFcm5lc3RvIiwiZmFtaWx5X25hbWUiOiJDcmVzcG8iLCJpYXQiOjE2NDY5NjE5MDYsImV4cCI6MTY0Njk2NTUwNiwianRpIjoiNWM2ZWFkNjRjNjcyOGYxY2VhNmJhNjhkNGYzYTYyZTI3MzUxZTFhZCJ9.jMgz-2c2M8jmF-pepfaLohkEc75VeswUa7S1N6h6VgS7DOHw4rUVBjza_7VYEa_3gPpFHKiX_8OYI9_CjPJa4x1VU2encPP_FEHDU6m0lILEVVYkSV4LS7jfkJRe93GE51E8rQPUdR2IxcPc_P8mlE3Co-plLIktqAmW4_fyyMyLquDj-CjXfTpZ6RZs85rf3XH1qM-LOF8jhydDMKAhY8Iej4PCsT56C-kr26En3SqaA5BNgEftLIxhjQoFuZNCj8c7g5PuUztdmQ6UhjFA1-G392HnMx7rMYsfjeXxs2zaTeSjPh-z4JwyqkBTxZm6_rp37RpeQJFcGKzxWZNx8g)
* [Principios SOLID](https://enmilocalfunciona.io/principios-solid/)

* [ArjanCodes](https://www.youtube.com/watch?v=pTB30aXS77U&t=1s)

* [solid principles with python (enlace roto)](https://medium.com/@didemyaniktepe/solid-principles-with-python-97b5e7250ed7#id_token=eyJhbGciOiJSUzI1NiIsImtpZCI6ImZjYmQ3ZjQ4MWE4MjVkMTEzZTBkMDNkZDk0ZTYwYjY5ZmYxNjY1YTIiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2NTE5NjI5NzgsImF1ZCI6IjIxNjI5NjAzNTgzNC1rMWs2cWUwNjBzMnRwMmEyamFtNGxqZGNtczAwc3R0Zy5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwMzA0ODgwMTUxNTE4Mzk4NTA5MyIsImVtYWlsIjoiZWNyZXNwb0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXpwIjoiMjE2Mjk2MDM1ODM0LWsxazZxZTA2MHMydHAyYTJqYW00bGpkY21zMDBzdHRnLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwibmFtZSI6IkVybmVzdG8gQ3Jlc3BvIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hLS9BT2gxNEdpT19yRlhDM0VVWWRocmFLWjBHUmJNVlpRenhwSHRWQnl0MmI0MmU4WT1zOTYtYyIsImdpdmVuX25hbWUiOiJFcm5lc3RvIiwiZmFtaWx5X25hbWUiOiJDcmVzcG8iLCJpYXQiOjE2NTE5NjMyNzgsImV4cCI6MTY1MTk2Njg3OCwianRpIjoiNThhMzllZDhiMDNhZDM0ZDY1NDlhZDc2YzBmN2RkODY3NDNlZTgzMiJ9.db8I06It2VvYgbS6UswUsVGpbL3-OY8fFmQ367BXgF9p21W--y6OcTsKRTQp1yKVUZXbaUUoQYtIfoC00pnn9J7NHM1Fzixx1FIf8qeUm_4Yj4iPGzLwE4QapPbwJYdB1xXOLNGfQkfHb63U6ZwObrzJZrqHatNc7dwNNzpy0757d3BXvgrSNWbLXuNcxBVrdFwHqqtjJZfsyixaTAqYi4mzjg3ljpoxlYP-USeCIASUU6OJkMyCs__XjhC0ez2lWNDuPZwC3WML130U9GsHikAWR_Ue1iOIuQfC7_N2PE-GU0pYWCfIzzTvrhBoRFMhaN5i1koEOQ9w6c9ziCvH9A)

* [SOLID Coding in Python](https://towardsdatascience.com/solid-coding-in-python-1281392a6a94)

* [5 Principles to write SOLID Code](https://towardsdatascience.com/5-principles-to-write-solid-code-examples-in-python-9062272e6bdc)

* [The 5 (SOLID) Principles of Pyhon Readable Code (enlace roto)](https://towardsdev.com/the-5-solid-principles-of-pyhon-readable-code-67c5a3fe5693)

* [Designing to Patterns: A Pythonic Example](https://levelup.gitconnected.com/designing-to-patterns-a-pythonic-example-14bc8ce34e81)

* [Python Interface Segregation Principle](https://www.pythontutorial.net/python-oop/python-interface-segregation-principle/)

* [How to Write Clean Code (in Python) With SOLID Principles | Principle #4 (enlace roto)](https://medium.com/the-brainwave/how-to-write-clean-code-in-python-with-solid-principles-principle-4-2297c45d37e2)

* [The Interface Segregation Principle (ISP) Explained in Python (enlace roto)](https://medium.com/better-programming/the-interface-segregation-principle-isp-explained-in-python-46e173241642)

---
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)
`))))))),s(`title`,{},`Blog | Principios S.O.L.I.D. - 5. Principio de inversión de la dependencia. (DIP - Dependency inversion principle)`),s(`meta`,{content:`favicon.ico`,property:`og:image`}))}E.displayName=`Component(blog/python_solid5)`;var D=n(E);export{D as default};