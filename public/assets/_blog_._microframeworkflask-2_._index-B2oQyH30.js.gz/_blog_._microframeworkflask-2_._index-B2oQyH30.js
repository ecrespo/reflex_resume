import{r as e}from"./rolldown-runtime-hePW80VL.js";import{W as t,a as n}from"./components-DO_H3UDc.js";import{R as r,V as i,n as a,t as o}from"./link-D9U8cMgj.js";import{n as s}from"./emotion-react.browser.esm-D8ztlwVE.js";import{n as c,t as l}from"./code-zr1gvGUO.js";import{a as u,d,l as f,o as p,t as m}from"./blog-CXuGC-pa.js";import{a as h,c as g,i as _,l as v,n as y,o as b,r as x,t as S,u as C}from"./one-dark-rXXMda_G.js";var w=e(t(),1);function T(){let{resolvedColorMode:e}=(0,w.useContext)(r);return{h1:({node:e,children:t,...n})=>s(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(a,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(x,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?y:S,wrapLongLines:!0,...o})}}}function E(){return s(w.Fragment,{},s(`div`,{className:`flex min-h-screen font-['Inter'] bg-[#f5f5dc]`},s(w.Fragment,{},s(w.Fragment,{},s(f,{},s(w.Fragment,{},s(d,{})),s(w.Fragment,{}))),s(m,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(i,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`))))),s(`aside`,{className:`hidden md:flex w-96 min-h-screen bg-[#7dd3c0] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-teal-600/10`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(i,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-96`},s(`nav`,{className:`w-full h-14 bg-[#4a9bba] flex items-center shadow-sm flex-shrink-0 z-20 sticky top-0`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(p,{},s(`div`,{className:`flex flex-col`},s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white`}))),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/`},`HOME`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog`},`BLOG`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/tags`},`TAGS`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/feed.xml`},`ATOM`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(o,{asChild:!0,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`span`,{className:`inline-flex items-center px-4 py-2 bg-[#4a9bba] text-white rounded-lg hover:bg-[#3a8baa] transition-colors font-medium mb-6`},`← Volver al Blog`))),s(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Micro framework flask (parte 2)`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-gray-500`},`June 07, 2014`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-[#4a9bba] font-medium`},`Tutorial Python`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-gray-600`},`Por `),s(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),s(`article`,{className:`post-content`},s(`div`,{className:`prose prose-lg max-w-none`},s(C,{components:T(),rehypePlugins:[b,h,_],remarkPlugins:[v,g]},`Continuando con el artículo [inicial](/blog/microframeworkdedesarrollowebflask) sobre el microframework flask, ahora se muestra el manejo de distintas rutas de urls, se muestra también como obtener información sobre el navegador que se está utilizando para ver la página y por último como redireccionar una ruta a otro url.

A continuación se muestra el código de \`app.py\`:
\`\`\`python
#de flask se importa Flask, request y redirect.

from flask import Flask,request,redirect



#Se crea la instancia del objeto Flask.

app = Flask(__name__)



#Se define el decorador ruta en este caso será la raíz del url, donde

#se muestra hola mundo desde flask

@app.route('/')

def hola_mundo():

    return "Hola Mundo <strong>desde Flask</strong>"



#En este caso el decorador ruta maneja un directorio ususuario y se coloca el nombre del 

#usuario en el url 

@app.route('/usuario/<nombre>')

#Se define la función usuario donde se le pasa el nombre

#devuelve un texto que dice hola y el nombre del usuario.

def usuario(nombre):

    return "<h1> Hola, %s </h1>" % nombre



#Se define la ruta navegador

@app.route('/navegador')

#Se crea la función navegador

#donde se obtiene el headers de User-Agent el cual maneja el nombre

#del navegador que se está usando, la función navegador retorna un string con

#el nombre del navegador.

def navegador():

    user_agent= request.headers.get('User-Agent')

    return "<h1>Su navegador es: %s </h1> " % user_agent



#Se define la ruta redirect

@app.route('/redirect')

#se crea la función redir el cual retorna el nuevo url que será este blog.

def redir():

    return redirect('https://www.seraph.to')



#Se define la ejecución del servidor.

if __name__ == '__main__':

    app.run(debug=True)

\`\`\`

A continuación se ejecuta \`app.py\`:
\`\`\`
python app.py 
 * Running on http://127.0.0.1:5000/
 * Restarting with reloader
\`\`\`
Se abre el navegador colocando en el url el nombre que se desea mostrar en este caso ernesto:
http://127.0.0.1:5000/usuario/ernesto

La imagen muestra el resultado:

![](/blog/images/microframeworkflask2-1.png)


Ahora se colocará el url que permite mostrar la información del navegador:
http://127.0.0.1:5000/navegador

La siguiente figura muestra el resultado:

![](/blog/images/microframeworkflask2-2.png)

Para terminar se colocará el url que permite redireccionar un url a otro url, en este caso se grabará un screencast para mostrar la acción.
El url es: http://127.0.0.1:5000/redirect

El vídeo se muestra a continuación: 

[https://youtu.be/F0TOM6Ztak8 (enlace roto)](https://youtu.be/F0TOM6Ztak8 "https://youtu.be/F0TOM6Ztak8")


##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))))),s(`title`,{},`Blog | Micro framework flask (parte 2)`),s(`meta`,{content:`favicon.ico`,property:`og:image`}))}E.displayName=`Component(blog/microframeworkflask-2)`;var D=n(E);export{D as default};