import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Gt as r,Ht as i,Nt as a,et as o,tt as s}from"./createLucideIcon-B1BUtjEZ.js";import{n as c,t as l}from"./code-Bfm7iQ52.js";import{a as u,i as d,n as f,o as p,s as m,t as h}from"./rss-rOPIheM1.js";import{a as g,c as _,h as v,i as y,l as b,m as x,n as S,o as C,p as w,r as T,t as E,u as D}from"./one-dark-mSSrGAeQ.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>a(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>a(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>a(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>a(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>a(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>a(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>a(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>a(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>a(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>a(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>a(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>a(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return a(T,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?S:E,wrapLongLines:!0,...s})}}}function A(){return a(O.Fragment,{},a(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`es`},a(O.Fragment,{},a(`div`,{className:`md:hidden`},a(v,{},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(m,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(u,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),a(r,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(u,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),a(`div`,{className:`w-full px-4`},a(x,{},`Descargar currículum`)),a(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},a(r,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/iniciandodjangocondockerusandodockercomposeconpostgresqlcomomicroservicio`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`EN`)),a(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`ES`)))))),a(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(m,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(u,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),a(r,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(u,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),a(`div`,{className:`w-full px-4`},a(x,{},`Descargar currículum`)),a(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},a(r,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/iniciandodjangocondockerusandodockercomposeconpostgresqlcomomicroservicio`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`EN`)),a(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`ES`)))))),a(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},a(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},a(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},a(`div`,{className:`md:hidden flex-shrink-0`},a(w,{},`Menú`)),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es`},`INICIO`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog`},`BLOG`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/archives`},`ARCHIVO`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/categories`},`CATEGORÍAS`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/tags`},`ETIQUETAS`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/feed.xml`},`ATOM`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/dev-dashboard-stats`},`ESTADÍSTICAS DE DESARROLLO`))),a(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},a(`div`,{className:`container mx-auto max-w-4xl`},a(`div`,{className:`mb-6`},a(d,{href:`/es/blog`},`← Volver al blog`)),a(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},a(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Iniciando Django con docker usando docker-compose con postgresql como microservicio.`),a(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},a(`span`,{className:`text-gray-500`},`11 de febrero de 2016`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(p,{size:`sm`,tone:2},`Tutorial Python`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(`span`,{className:`text-gray-600`},`Por `),a(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),a(`article`,{className:`post-content`,lang:`es`},a(`div`,{className:`prose prose-lg max-w-none`},a(D,{components:k(),rehypePlugins:[C,g,y],remarkPlugins:[b,_]},`En este artículo se tomará lo visto en el artículo de microservicios con docker donde se uso flask y redis, en este caso será con postgresql y Django.

Dejo a continuación la lista de artículos sobre docker que se ha tocado en el blog:

1. [Instalar Docker en Debian Jessie (enlace roto)](/blog/instalardockerendebianjessie)  
2. [Uso de Docker en Debian Jessie (parte 1) (enlace roto)](https://www.seraph.to/uso-de-docker-en-debian-jessie-parte-1.html#uso-de-docker-en-debian-jessie-parte-1)  
3. [Uso de Docker en Debian Jessie (parte 2) (enlace roto)](https://www.seraph.to/uso-de-docker-en-debian-jessie-parte-2.html#uso-de-docker-en-debian-jessie-parte-2)  
4. [Crear una imagen Docker a partir de un archivo Dockerfile (enlace roto)](/blog/crearunaimagendockerapartirdeunarchivodockerfile)  
5. [Iniciando Django usando Docker (enlace roto)](/blog/iniciandodjangousandodocker)  
6. [Instalar Gitlab por medio de Docker (enlace roto)](/blog/instalargitlabpormediodedocker)  
7. [Ejecutando microservicios con docker usando docker-compose (enlace roto)](/blog/ejecutandomicrosservicioscondockerusandodockercompose)  
8. [Docker en Docker (DinD) (enlace roto)](/blog/dockerendockerdind)


El artículo se basa en un artículo en inglés sobre [docker-compose y django](https://docs.docker.com/compose/django/).

La idea es tener dos contenedores uno ejecutando \`postgresql\` y en otro \`Django\`.

En un directorio se crea el archivo \`Dockerfile\` con el siguiente contenido:
\`\`\`
FROM python:2.7
ENV PYTHONUNBUFFERED 1
RUN mkdir /codigo
WORKDIR /codigo
ADD requerimientos.txt /codigo/
RUN pip install --upgrade pip
RUN pip install -r requermientos.txt
ADD . /codigo/
\`\`\`
El archivo requerimientos.txt contendrá la instalación de Django y de la librería \`psycopg2\` para conectarse a \`postgresql\` desde \`django\`:
\`\`\`
Django
psycopg2
\`\`\`
El último archivo a crear es el que usará \`docker-compose\` con el nombre de \`docker-compose.yml\` y su contenido iniciará la base de datos \`postgresql\` y luego a \`Django\`:
\`\`\`
bd:
  image: postgres
web:
  build: .
  command: python manage.py runserver 0.0.0.0:8000
  volumes:
    - .:/codigo
  ports:
    - "8000:8000"
  links:
    - bd
\`\`\`

Se tendrán dos contenedores uno llamado bd y otro web. El comando a iniciar DJango es el que se conoce y usa el puerto 8000 que será visto de manera pública.


A continuación se crea el proyecto Django con el siguiente comando:
\`\`\`
docker-compose run web django-admin.py startproject djangoapp .
Building web
Step 1 : FROM python:2.7
 ---> 19ab33b86bc6
Step 2 : ENV PYTHONUNBUFFERED 1
 ---> Running in eb54e8bab43f
 ---> a4206823aac3
Removing intermediate container eb54e8bab43f
Step 3 : RUN mkdir /app
 ---> Running in bf221dbca163
 ---> 44eb31969545
Removing intermediate container bf221dbca163
Step 4 : WORKDIR /app
 ---> Running in 6209e18e7e87
 ---> 6f7d50fc9b12
Removing intermediate container 6209e18e7e87
Step 5 : ADD requerimientos.txt /app/
 ---> 293c5424f664
Removing intermediate container c072ad8ca2ae
Step 6 : RUN pip install --upgrade pip
 ---> Running in 48f862804290
Collecting pip
  Downloading pip-8.0.2-py2.py3-none-any.whl (1.2MB)
Installing collected packages: pip
  Found existing installation: pip 7.1.2
    Uninstalling pip-7.1.2:
      Successfully uninstalled pip-7.1.2
Successfully installed pip-8.0.2
 ---> 6126a41cd55b
Removing intermediate container 48f862804290
Step 7 : RUN pip install -r requerimientos.txt
 ---> Running in 7e6c9ff9fefa
Collecting Django (from -r requerimientos.txt (line 1))
  Downloading Django-1.9.2-py2.py3-none-any.whl (6.6MB)
Collecting psycopg2 (from -r requerimientos.txt (line 2))
  Downloading psycopg2-2.6.1.tar.gz (371kB)
Building wheels for collected packages: psycopg2
  Running setup.py bdist_wheel for psycopg2: started
  Running setup.py bdist_wheel for psycopg2: finished with status 'done'
  Stored in directory: /root/.cache/pip/wheels/e2/9a/5e/7b620848bbc7cfb9084aafea077be11618c2b5067bd532f329
Successfully built psycopg2
Installing collected packages: Django, psycopg2
Successfully installed Django-1.9.2 psycopg2-2.6.1
 ---> 971bcfbe34ec
Removing intermediate container 7e6c9ff9fefa
Step 8 : ADD . /app/
 ---> 7a7faf87cf21
Removing intermediate container 6c246df080b3
Successfully built 7a7faf87cf21
\`\`\`

Esto generará un directorio y unos archivos como se muestra a continuación:
\`\`\`
ls -l
total 20
drwxr-xr-x 2 root    root    4096 feb 10 21:35 djangoapp
-rw-r--r-- 1 ernesto ernesto  174 feb 10 21:14 docker-compose.yml
-rw-r--r-- 1 ernesto ernesto  177 feb 10 21:14 Dockerfile
-rwxr-xr-x 1 root    root     252 feb 10 21:35 manage.py
-rw-r--r-- 1 ernesto ernesto   17 feb 10 20:10 requerimientos.txt
\`\`\`

Es necesario cambiar de usuario al directorio djangoapp y a manage.py.
\`\`\`
sudo chown -R $USER:$USER .
\`\`\`
Se revisan las imagenes creadas:
\`\`\`
docker images
REPOSITORY                  TAG                 IMAGE ID            CREATED             VIRTUAL SIZE
docker5_web              latest              7a7faf87cf21        4 minutes ago       715.2 MB
postgres                    latest              54fa18d9f3b6        2 weeks ago         263.8 MB
\`\`\`

Modificar el archivo \`djangoapp/settings.py\` para dar soporte a la conexión al contenedor de \`postgresql\`:

Modificar la sección database con el siguiente contenido:

\`\`\`
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'postgres',
        'USER': 'postgres',
        'HOST': 'db',
        'PORT': 5432,
    }
}
\`\`\`
El usuario y clave son los que tiene predefinido la imagen de docker para postgresql.

Se ejecuta \`migrate\` del \`manage.py\` para crear las tablas:
\`\`\`
docker-compose run web python manage.py migrate

Operations to perform:
  Apply all migrations: admin, contenttypes, auth, sessions
Running migrations:
  Rendering model states... DONE
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
  Applying admin.0002_logentry_remove_auto_add... OK
  Applying contenttypes.0002_remove_content_type_name... OK
  Applying auth.0002_alter_permission_name_max_length... OK
  Applying auth.0003_alter_user_email_max_length... OK
  Applying auth.0004_alter_user_username_opts... OK
  Applying auth.0005_alter_user_last_login_null... OK
  Applying auth.0006_require_contenttypes_0002... OK
  Applying auth.0007_alter_validators_add_error_messages... OK
  Applying sessions.0001_initial... OK
\`\`\`

Se crea la cuenta de administrador de django:
\`\`\`
docker-compose run web python manage.py createsuperuser
Username (leave blank to use 'root'): admin
Email address: 
Password: 
Password (again): 
Superuser created successfully.
\`\`\`

Para levantar el servidor web de django se inicia \`docker-compose\`:
\`\`\`
$docker-compose up
docker5_db_1 is up-to-date
Creating docker5_web_1
Attaching to docker5_db_1, docker5_web_1
db_1  | The files belonging to this database system will be owned by user "postgres".
db_1  | This user must also own the server process.
db_1  | 
db_1  | The database cluster will be initialized with locale "en_US.utf8".
db_1  | The default database encoding has accordingly been set to "UTF8".
db_1  | The default text search configuration will be set to "english".
db_1  | 
db_1  | Data page checksums are disabled.
db_1  | 
db_1  | fixing permissions on existing directory /var/lib/postgresql/data ... ok
db_1  | creating subdirectories ... ok
db_1  | selecting default max_connections ... 100
db_1  | selecting default shared_buffers ... 128MB
db_1  | selecting dynamic shared memory implementation ... posix
db_1  | creating configuration files ... ok
db_1  | creating template1 database in /var/lib/postgresql/data/base/1 ... ok
db_1  | initializing pg_authid ... ok
db_1  | initializing dependencies ... ok
db_1  | creating system views ... ok
db_1  | loading system objects' descriptions ... ok
db_1  | creating collations ... ok
db_1  | creating conversions ... ok
db_1  | creating dictionaries ... ok
db_1  | setting privileges on built-in objects ... ok
db_1  | creating information schema ... ok
db_1  | loading PL/pgSQL server-side language ... ok
db_1  | vacuuming database template1 ... ok
db_1  | copying template1 to template0 ... ok
db_1  | copying template1 to postgres ... ok
db_1  | syncing data to disk ... ok
db_1  | 
db_1  | WARNING: enabling "trust" authentication for local connections
db_1  | You can change this by editing pg_hba.conf or using the option -A, or
db_1  | --auth-local and --auth-host, the next time you run initdb.
db_1  | 
db_1  | Success. You can now start the database server using:
db_1  | 
db_1  |     pg_ctl -D /var/lib/postgresql/data -l logfile start
db_1  | 
db_1  | ****************************************************
db_1  | WARNING: No password has been set for the database.
db_1  |          This will allow anyone with access to the
db_1  |          Postgres port to access your database. In
db_1  |          Docker's default configuration, this is
db_1  |          effectively any other container on the same
db_1  |          system.
db_1  | 
db_1  |          Use "-e POSTGRES_PASSWORD=password" to set
db_1  |          it in "docker run".
db_1  | ****************************************************
db_1  | waiting for server to start....LOG:  database system was shut down at 2016-02-11 04:34:33 UTC
db_1  | LOG:  MultiXact member wraparound protections are now enabled
db_1  | LOG:  database system is ready to accept connections
db_1  | LOG:  autovacuum launcher started
db_1  |  done
db_1  | server started
db_1  | ALTER ROLE
db_1  | 
db_1  | 
db_1  | /docker-entrypoint.sh: ignoring /docker-entrypoint-initdb.d/*
db_1  | 
db_1  | LOG:  received fast shutdown request
db_1  | LOG:  aborting any active transactions
db_1  | waiting for server to shut down...LOG:  autovacuum launcher shutting down
db_1  | .LOG:  shutting down
db_1  | LOG:  database system is shut down
db_1  |  done
db_1  | server stopped
db_1  | 
db_1  | PostgreSQL init process complete; ready for start up.
db_1  | 
db_1  | LOG:  database system was shut down at 2016-02-11 04:34:38 UTC
db_1  | LOG:  MultiXact member wraparound protections are now enabled
db_1  | LOG:  database system is ready to accept connections
db_1  | LOG:  autovacuum launcher started
db_1  | LOG:  database system was interrupted; last known up at 2016-02-11 04:34:39 UTC
db_1  | LOG:  database system was not properly shut down; automatic recovery in progress
db_1  | LOG:  invalid record length at 0/1707848
db_1  | LOG:  redo is not required
db_1  | LOG:  MultiXact member wraparound protections are now enabled
db_1  | LOG:  database system is ready to accept connections
db_1  | LOG:  autovacuum launcher started
db_1  | ERROR:  relation "auth_user" does not exist at character 280
db_1  | STATEMENT:  SELECT "auth_user"."id", "auth_user"."password", "auth_user"."last_login", "auth_user"."is_superuser", "auth_user"."username", "auth_user"."first_name", "auth_user"."last_name", "auth_user"."email", "auth_user"."is_staff", "auth_user"."is_active", "auth_user"."date_joined" FROM "auth_user" WHERE "auth_user"."username" = 'root'
web_1 | Performing system checks...
web_1 | 
web_1 | System check identified no issues (0 silenced).
web_1 | February 11, 2016 - 12:38:56
web_1 | Django version 1.9.2, using settings 'djangoapp.settings'
web_1 | Starting development server at http://0.0.0.0:8000/
web_1 | Quit the server with CONTROL-C.
\`\`\`

Sólo queda abrir el navegador en la siguiente URL http://127.0.0.1:8000/admin.

A continuación la imagen de la sesión de admin de Django:

![](/blog/images/iniciandodjangocondockerusandodockercomposeconpostgresqlcomomicroservicio-1.png)


Y la figura de los logs de la ejecución de Django:

![](/blog/images/iniciandodjangocondockerusandodockercomposeconpostgresqlcomomicroservicio-2.png)


Como se vió en el artículo se puede ejecutar los comandos del manage.py desde fuera del contenedor que estos comandos se ejecutarán en el contenedor.

Ya con esto se pueden realizar configuraciones más complejas como incorporar redis o rabbitMQ (con Django Celery, explicado en un [artículo anterior (enlace roto)](https://blog.crespo.org.ve/search/label/Django-celery)) y lo mejor es que la configuración es simplemente adaptar lo que existe a las necesidades puntuales del proyecto.

Referencias:

1. [Quickstart: Compose and Django.](https://docs.docker.com/compose/django/)  
2. [Packaging Django applications into Docker container images.](http://michal.karzynski.pl/blog/2015/04/19/packaging-django-applications-as-docker-container-images/) 
3. [Deploy de Django sobre Docker.](http://www.cristalab.com/tutoriales/deploy-de-django-sobre-docker-c114082l/)
4. [Docker Explicado: Cómo crear Contenedores de Docker corriendo en Memcached.](https://www.digitalocean.com/community/tutorials/docker-explicado-como-crear-contenedores-de-docker-corriendo-en-memcached-es)
5. [Docker en la ejecución de test de integración en NodeJS.](http://abirtone.com/docker/2015/07/28/uso-de-docker-en-aplicacion-de-nodejs/)
##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)
`))))),a(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},a(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},a(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),a(r,{"aria-label":`Enviar un correo a ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},a(f,{"aria-hidden":`true`,size:16}),a(`span`,{},`ecrespo@gmail.com`))),a(`p`,{className:`text-sm text-gray-700`},a(`span`,{},`Hecho con `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),a(`span`,{},` · alojado en `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),a(`nav`,{"aria-label":`Redes sociales`,className:`flex items-center gap-4`},a(r,{"aria-label":`Medium (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),a(r,{"aria-label":`LinkedIn (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),a(r,{"aria-label":`Twitter (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),a(r,{"aria-label":`GitHub (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),a(r,{"aria-label":`GitLab (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),a(r,{"aria-label":`Blog (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://blog.seraph.to`},a(h,{"aria-hidden":`true`,size:18})))),a(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},a(`span`,{},`© 2026 Ernesto Crespo. Todos los derechos reservados.`),a(`span`,{},`Código fuente bajo la `,a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`licencia Apache 2.0`),` · `,a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`Ver el código`)))))),a(`title`,{},`Blog | Iniciando Django con docker usando docker-compose con postgresql como microservicio.`),a(`meta`,{content:`favicon.ico`,property:`og:image`}))}A.displayName=`Component(es/blog/iniciandodjangocondockerusandodockercomposeconpostgresqlcomomicroservicio)`;var j=n(A);export{j as default};