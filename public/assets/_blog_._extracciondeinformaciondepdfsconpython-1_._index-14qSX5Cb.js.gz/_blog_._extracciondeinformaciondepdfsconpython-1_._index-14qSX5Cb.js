import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Gt as r,Ht as i,Nt as a,et as o,tt as s}from"./createLucideIcon-NfsGDwHt.js";import{n as c,t as l}from"./code-JPwtydJL.js";import{a as u,i as d,n as f,o as p,s as m,t as h}from"./rss-IpKb49A8.js";import{a as g,c as _,f as v,g as y,i as b,l as x,m as S,n as C,o as w,r as T,t as E,u as D}from"./one-dark-sr8yDwfx.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>a(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>a(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>a(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>a(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>a(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>a(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>a(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>a(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>a(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>a(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>a(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>a(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return a(T,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?C:E,wrapLongLines:!0,...s})}}}function A(){return a(O.Fragment,{},a(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`en`},a(O.Fragment,{},a(`div`,{className:`md:hidden`},a(y,{},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(m,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(u,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),a(r,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(u,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),a(`div`,{className:`w-full px-4`},a(S,{},`Download Resume`)),a(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},a(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`EN`)),a(r,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/extracciondeinformaciondepdfsconpython-1`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`ES`)))))),a(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(m,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(u,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),a(r,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(u,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),a(`div`,{className:`w-full px-4`},a(S,{},`Download Resume`)),a(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},a(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`EN`)),a(r,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/extracciondeinformaciondepdfsconpython-1`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`ES`)))))),a(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},a(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},a(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},a(`div`,{className:`md:hidden flex-shrink-0`},a(v,{},`Menu`)),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/`},`HOME`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog`},`BLOG`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/tags`},`TAGS`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/feed.xml`},`ATOM`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/dev-dashboard-stats`},`DEV DASHBOARD STATS`))),a(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},a(`div`,{className:`container mx-auto max-w-4xl`},a(`div`,{className:`mb-6`},a(d,{href:`/blog`},`← Back to the blog`)),a(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},a(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Extracción de información de PDFs con python (parte 1).`),a(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},a(`span`,{className:`text-gray-500`},`August 29, 2015`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(p,{size:`sm`,tone:2},`Tutorial Python`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(`span`,{className:`text-gray-600`},`By `),a(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),a(`article`,{className:`post-content`,lang:`es`},a(`div`,{className:`prose prose-lg max-w-none`},a(D,{components:k(),rehypePlugins:[w,g,b],remarkPlugins:[x,_]},`Existen varias herramientas en python para obtener información de PDF.
En este caso visite la página de [Cencoex](www.cencoex.gob.ve), en la sección de Cencoex en cifras hay un enlace a un pdf a [Liquidaciones a Empresas Agremiadas del Sector Salud (Ordinarias + ALADI + SUCRE) (enlace roto)](http://www.cencoex.gob.ve/images/stories/pdfs/estadisticas/Salud.pdf).

Para este primer artículo se usará [pycurl](http://pycurl.io/) para bajar el pdf y [peepdf (enlace roto)](http://eternal-todo.com/tools/peepdf-pdf-analysis-tool) para analizarlo. Para descargar peepdf se puede hacer desde el repositorio del proyecto en [github](https://github.com/jesparza/peepdf).

En el caso de \`pycurl\` se instala por \`pip\` o por \`apt-get\` en Debian.

Se baja \`peepdf\`:
\`\`\`
git clone https://github.com/jesparza/peepdf.git
\`\`\`
Para bajar el archivo se ejecuta el código a continuación, el cual baja el archivo pdf y lo salva como \`salud.pdf\`:
\`\`\`python
import pycurl

with open('salud.pdf', 'wb') as f:
    c = pycurl.Curl()
    c.setopt(c.URL, 'http://www.cencoex.gob.ve/images/stories/pdfs/estadisticas/Salud.pdf')
    c.setopt(c.WRITEDATA, f)
    c.perform()
    c.close()
\`\`\`

En el directorio de la aplicación se ejecuta (opción \`-f\` para el archivo y \`-i\` en modo interactivo:
\`\`\`python
./peepdf.py  -f ../salud.pdf -i
\`\`\`
Y devuelve:
\`\`\`python
File: salud.pdf
MD5: e639fca504182dc5cb383cc455d30c21
SHA1: 2c29f4a20e4e0b6a3c10decbfacced991e59ad79
SHA256: 9a4d3d48f060d1fa29fe9cb5e7a435643586e9871e62254839daf3fd87e45506
Size: 57611 bytes
Version: 1.3
Binary: True
Linearized: False
Encrypted: False
Updates: 0
Objects: 34
Streams: 7
Comments: 0
Errors: 0

Version 0:
 Catalog: 1
 Info: 2
 Objects (34): [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34]
 Streams (7): [10, 33, 32, 5, 15, 21, 27]
  Encoded (7): [10, 33, 32, 5, 15, 21, 27]
\`\`\`
El comando tree devuelve la estructura lógica del archivo:
\`\`\`python
PPDF> tree

/Catalog (1)
 /Pages (3)
  /Page (4)
   /Pages (3)
   stream (5)
    integer (6)
    Unknown (0)
    /Catalog (1)
   /R10 (12)
    stream (10)
   /R7 (11)
    /ExtGState (7)
   /R8 (13)
    /Font (8)
     /Encoding (34)
     /FontDescriptor (9)
      stream (32)
     stream (33)
  /Page (14)
   /Pages (3)
   stream (15)
    integer (16)
    Unknown (0)
    /Catalog (1)
   /R10 (18)
    stream (10)
   /R7 (17)
    /ExtGState (7)
   /R8 (19)
    /Font (8)
  /Page (20)
   /Pages (3)
   stream (21)
    integer (22)
    Unknown (0)
    /Catalog (1)
   /R10 (24)
    stream (10)
   /R7 (23)
    /ExtGState (7)
   /R8 (25)
    /Font (8)
  /Page (26)
   /Pages (3)
   stream (27)
    integer (28)
    Unknown (0)
    /Catalog (1)
   /R10 (30)
    stream (10)
   /R7 (29)
    /ExtGState (7)
   /R8 (31)
    /Font (8)
/Info (2)
\`\`\`

Para ver la estructura física se usa el comando \`offsets\`:
\`\`\`python
PPDF> offsets

       0 Header
      15
        Object  5 (8865)
    8879
    8881
        Object  6 (19)
    8899
    8901
        Object  15 (9005)
   17905
   17907
        Object  16 (20)
   17926
   17928
        Object  21 (8618)
   26545
   26547
        Object  22 (20)
   26566
   26568
        Object  27 (6554)
   33121
   33123
        Object  28 (20)
   33142
   33144
        Object  4 (189)
   33332
   33334
        Object  14 (191)
   33524
   33526
        Object  20 (191)
   33716
   33718
        Object  26 (191)
   33908
   33910
        Object  3 (88)
   33997
   33999
        Object  1 (47)
   34045
   34047
        Object  7 (40)
   34086
   34088
        Object  11 (29)
   34116
   34118
        Object  12 (31)
   34148
   34150
        Object  10 (4140)
   38289
   38291
        Object  13 (29)
   38319
   38321
        Object  17 (29)
   38349
   38351
        Object  18 (31)
   38381
   38383
        Object  19 (29)
   38411
   38413
        Object  23 (29)
   38441
   38443
        Object  24 (31)
   38473
   38475
        Object  25 (29)
   38503
   38505
        Object  29 (29)
   38533
   38535
        Object  30 (31)
   38565
   38567
        Object  31 (29)
   38595
   38597
        Object  33 (614)
   39210
   39212
        Object  8 (436)
   39647
   39649
        Object  34 (408)
   40056
   40058
        Object  9 (204)
   40261
   40263
        Object  32 (16249)
   56511
   56513
        Object  2 (243)
   56755
   56757
        Xref Section (709)
   57465
   57467
        Trailer (138)
   57604
   57605 EOF
\`\`\`
Para ver el metadato del pdf se ejecuta metadata:
\`\`\`python
PPDF> metadata

Info Object in version 0:

<< /ModDate D:20140908210848+04'-30'
/CreationDate D:20140908210848+04'-30'
/Producer Nitro PDF PrimoPDF
/Title LIQUIDACIONES DEL 1 ENERO AL 5 DE SEPTIEMBRE 2014.xls
/Creator PrimoPDF http://www.primopdf.com
/Author lrojas >>
\`\`\`
La fecha de creación del archivo es 09-08-2014 y la hora es 21:08:48  hora de Venezuela. El título del archivo Liquidaciones del 1 enero al 5 de septiembre de 2014, ah, es un archivo xls de excel. Y usaron primopdf para generar el pdf, por último el autor del pdf es lrojas.

Si se quiere revisar el objeto 2:
\`\`\`python
PPDF> object 2

<< /ModDate D:20140908210848+04'-30'
/CreationDate D:20140908210848+04'-30'
/Producer Nitro PDF PrimoPDF
/Title LIQUIDACIONES DEL 1 ENERO AL 5 DE SEPTIEMBRE 2014.xls
/Creator PrimoPDF http://www.primopdf.com
/Author lrojas >>
\`\`\`
Es el que contiene la información de los metadatos.

Revisando el objeto 15 se obtiene:
\`\`\`
432 1739.33 3991 6 re
f
432 1642.33 3991 6 re
f
432 1545.33 3991 6 re
f
432 1448.33 3991 6 re
f
432 1351.33 3991 6 re
f
432 1254.33 3991 6 re
f
432 1157.33 3991 6 re
f
432 1060.33 3991 6 re
f
432 963.332 3991 6 re
f
432 866.332 3991 6 re
f
432 769.332 3991 6 re
f
432 672.332 3991 6 re
\`\`\`
O usando \`rawstream\`:
\`\`\`
rawstream 15
50 9f fa 71 0f 29 76 8a bc 44 3e dd c6 15 84 9e   öP..q.)v..D>.....ö
4c 89 76 f6 75 8c 3d 23 65 11 fb 65 48 d1 0e a1   öL.v.u.=#e..eH...ö
37 f6 08 d3 b6 f8 d2 17 15 4a 76 29 b0 04 86 e1   ö7........Jv)....ö
b4 9e 9b 3a 34 e7 d1 ce 91 9a c9 c0 91 9e cc 6c   ö...:4..........lö
4a 5d 24 67 c7 aa 21 fe 2c ea e6 ea 9e 8d 95 33   öJÅ$g..!.,......3ö
61 e5 55 2c 13 3c cd 61 21 d1 26 03 47 ba 32 b3   öa.U,.<.a!.&.G.2.ö
09 da cc ce 8e da e4 61 a1 85 34 d6 ba 00 63 5c   ö.......a..4...cÖö
08 f1 63 34 7a 90 44 cb 79 4d 95 50 58 6c e7 55   ö..c4z.D.yM.PXl.Uö
74 d4 da fb 44 4c 8a 48 a8 ae 41 42 b1 e5 44 a8   öt...DL.H..AB..D.ö
e9 bb 42 bb 47 28 3b cd 5e 22 0f 5d 3b 42 e8 d9   ö..B.G(;.Ü".Å;B..ö
e4 68 93 af 5f ec 99 50 8b d8 7f 03 08 05 8b 04   ö.h.._..P......ö
f5 a3 48 d5 bc 7b 7d 97 33 80 d8 c6 f6 85 57 90   ö..H..äå.3.....W.ö
4b 6a 8c 50 15 17 e4 e2 3a ca ce 7e 55 46 e4 5a   öKj.P....:..üUF.Zö
d4 d9 d5 eb 7d 70 a0 fb d6 a0 98 7d 3e 8f d9 72   ö....åp.....å>..rö
12 6d 08 55 71 41 2e 79 12 93 b3 9f 36 d4 72 5a   ö.m.UqA.y....6.rZö
68 a3 40 78 6b 9a 72 79 8c e9 6e 67 6c b9 cb ce   öh.@xk.ry..ngl...ö
9a 4b 4d ec f8 02 e7 f3 3e fa f8 f8 cd 2f 6e 7e   ö.KM.....>..../nüö
79 d3 c5 a0 96 4f 37 9d f1 46 3b 8e ea 1b 4d 13   öy....O7..F;...M.ö
7a fd 8d c9 ae fb 3e 4d 16 4c 7d e1 e9 63 a1 bc   öz.....>M.Lå..c..ö
eb 47 b5 bc 1d a2 5a de 0c ad 5a 5e 0f 83 5a 1e   ö.G....Z...ZÜ..Z.ö
c7 a0 96 d3 21 d8 ab 72 3a 16 77 5d 9e 4f a7 3c   ö....!..r:.wÅ.O.<ö
2f 2f 07 c1 ad ca e9 64 a7 55 39 9d eb b2 2a a7   ö//.....d.U9...*.ö
d3 1c 56 e5 b4 01 fb aa 9c 36 37 5e 95 d3 fe 9c   ö..V......67Ü....ö
ab 72 da b9 6e 55 4e fb 48 ad ca 69 57 96 f3 f2   ö.r..nUN.H..iW...ö
b2 af c0 aa 9c d6 e9 ae ca 69 85 dd aa 9c 96 b5   ö.........i......ö
ac ca 29 b9 7c 55 4e f9 9b ab 72 ca c2 5a 95 53   ö..).öUN...r..Z.Sö
8e c2 aa 9c a6 b4 56 e5 34 5a 7b 5e 5e 06 75 ce   ö......V.4ZäÜÜ.u.ö
cb 4b 1f ec bc bc b4 8d ce cb 0b 79 b0 fc 47 37   ö.K.........y..G7ö
ff 07 29 f1 43 c1                                 ö..).C.ö
\`\`\`

Uno de los problemas de analizar pdf generados en la APN en Venezuela es que no lo generan a partir de la información que manejan directamente de las bases de datos, si no que usan una hoja de cálculo en este caso en windows y la de Microsoft Office, y generan el pdf con herramientas para windows.

¿Será autentica la información que tiene el pdf luego de manipulación con varias herramientas?

En siguientes post seguiré probando distintas herramientas en Python para ver si logro hacer un pdfscraping decente del pdf de Cencoex.


##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)
`))))),a(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},a(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},a(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),a(r,{"aria-label":`Send an e-mail to ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},a(f,{"aria-hidden":`true`,size:16}),a(`span`,{},`ecrespo@gmail.com`))),a(`p`,{className:`text-sm text-gray-700`},a(`span`,{},`Built with `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),a(`span`,{},` · hosted on `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),a(`nav`,{"aria-label":`Social networks`,className:`flex items-center gap-4`},a(r,{"aria-label":`Medium (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),a(r,{"aria-label":`LinkedIn (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),a(r,{"aria-label":`Twitter (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),a(r,{"aria-label":`GitHub (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),a(r,{"aria-label":`GitLab (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),a(r,{"aria-label":`Blog (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://blog.seraph.to`},a(h,{"aria-hidden":`true`,size:18})))),a(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},a(`span`,{},`© 2026 Ernesto Crespo. All rights reserved.`),a(`span`,{},`Source code under the `,a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`Apache 2.0 License`),` · `,a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`View the source`)))))),a(`title`,{},`Blog | Extracción de información de PDFs con python (parte 1).`),a(`meta`,{content:`favicon.ico`,property:`og:image`}))}A.displayName=`Component(blog/extracciondeinformaciondepdfsconpython-1)`;var j=n(A);export{j as default};