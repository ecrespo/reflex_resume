import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Ft as r,Wt as i,nt as a,qt as o,rt as s}from"./createLucideIcon-D3XRMr6y.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-D57LksLy.js";import{a as m,c as h,h as g,i as _,l as v,m as y,n as b,o as x,p as S,r as C,t as w,u as T}from"./one-dark-0cv5s-i1.js";import{n as E,t as D}from"./code-CsSs3ThR.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>r(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>r(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>r(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>r(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>r(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>r(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>r(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>r(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>r(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>r(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>r(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>r(D,{...n},t),pre:({node:t,...n})=>{let{node:i,className:a,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(a||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return r(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?b:w,wrapLongLines:!0,...s})}}}function A(){return r(O.Fragment,{},r(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`es`},r(O.Fragment,{},r(`div`,{className:`md:hidden`},r(g,{},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),r(`div`,{className:`w-full px-4`},r(y,{},`Descargar currículum`)),r(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(o,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/tutorialdepyqtdesarrolloconqtdesigner-11`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},r(`div`,{className:`mb-4 text-center`},r(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),r(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),r(`div`,{className:`mb-4`},r(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),r(c,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},r(`ul`,{className:`list-none m-0 p-0`},r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),r(`li`,{className:`flex items-start mb-1.5 last:mb-0`},r(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),r(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),r(o,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(c,{size:`sm`},r(`div`,{className:`flex items-center gap-2`},r(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),r(`div`,{className:`flex-1`},r(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),r(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),r(`div`,{className:`w-full px-4`},r(y,{},`Descargar currículum`)),r(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},r(o,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/tutorialdepyqtdesarrolloconqtdesigner-11`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`EN`)),r(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},r(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),r(`span`,{className:`font-semibold`},`ES`)))))),r(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},r(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},r(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},r(`div`,{className:`md:hidden flex-shrink-0`},r(S,{},`Menú`)),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es`},`Inicio`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/resume`},`Currículum`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/portfolio`},`Portafolio`),r(o,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/es/blog`},`Blog`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/dev-dashboard-stats`},`Estadísticas de desarrollo`),r(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/archives`},`Archivo`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/categories`},`Categorías`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/tags`},`Etiquetas`),r(o,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/es/feed.xml`},`Atom`))),r(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},r(`div`,{className:`container mx-auto max-w-4xl`},r(`div`,{className:`mb-6`},r(l,{href:`/es/blog`},`← Volver al blog`)),r(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},r(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`Tutorial de PyQt. Desarrollo con QtDesigner. Parte 11.`),r(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},r(`span`,{className:`text-[#3E6A5E]`},`29 de julio de 2012`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(d,{size:`sm`,tone:2},`Tutorial Python`),r(`span`,{className:`text-[#5C7B71] mx-2`},` • `),r(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`Por`,r(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),r(`article`,{className:`post-content`,lang:`es`},r(`div`,{className:`prose prose-lg max-w-none`},r(T,{components:k(),rehypePlugins:[x,m,_],remarkPlugins:[v,h]},`Para repasar los artículos sobre \`pyQt\` pueden revisar el siguiente [enlace](/blog/tags).

En este caso en vez de escribir todo el código de la intefaz gráfica se usará la herramienta \`QtDesigner\`.

Se pedirá el nombre de la persona y al darle click al botón Aplicar se mostrará el nombre colocado en la entrada de datos en la etiqueta, se tiene un segundo botón el cual termina la ejecución de la aplicación al darle click.

La siguiente figura muestra el diseño de la interfaz:

![](/blog/images/tutorialdepyqtdesarrolloconqtdesigner-1.png) 

La siguiente figura muestra la relación entre los botones y señales:

![](/blog/images/tutorialdepyqtdesarrolloconqtdesigner-2.png) 

A cada botón se le asocia una función como lo muestra las siguientes dos figuras:
Botón Salir:

![](/blog/images/tutorialdepyqtdesarrolloconqtdesigner-3.png) 

Botón Aplicar:

![](/blog/images/tutorialdepyqtdesarrolloconqtdesigner-4.png) 

Al salvar la interfaz gráfica con nombre \`prueba3.ui\` lo que se hará a continuación es generar el código python por medio del comando:
\`pyuic4 -x prueba3.ui -o prueba3.py\`

El código generado se muestra a continuación:
\`\`\`python
# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'prueba3.ui'

#

# Created: Sun Jul 29 22:49:50 2012

#      by: PyQt4 UI code generator 4.9.1

#

# WARNING! All changes made in this file will be lost!




from PyQt4 import QtCore, QtGui




try:

    _fromUtf8 = QtCore.QString.fromUtf8

except AttributeError:

    _fromUtf8 = lambda s: s




class Ui_Form(object):

    def setupUi(self, Form):

        Form.setObjectName(_fromUtf8("Form"))

        Form.resize(400, 300)

        self.pushButton = QtGui.QPushButton(Form)

        self.pushButton.setGeometry(QtCore.QRect(280, 260, 102, 28))

        self.pushButton.setObjectName(_fromUtf8("pushButton"))

        self.pushButton_2 = QtGui.QPushButton(Form)

        self.pushButton_2.setGeometry(QtCore.QRect(140, 260, 102, 28))

        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))

        self.lineEdit = QtGui.QLineEdit(Form)

        self.lineEdit.setGeometry(QtCore.QRect(140, 40, 221, 28))

        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))

        self.label = QtGui.QLabel(Form)

        self.label.setGeometry(QtCore.QRect(20, 40, 69, 18))

        self.label.setObjectName(_fromUtf8("label"))

        self.label_2 = QtGui.QLabel(Form)

        self.label_2.setGeometry(QtCore.QRect(20, 160, 81, 18))

        self.label_2.setObjectName(_fromUtf8("label_2"))

        self.label_3 = QtGui.QLabel(Form)

        self.label_3.setGeometry(QtCore.QRect(140, 160, 221, 18))

        self.label_3.setObjectName(_fromUtf8("label_3"))

        self.retranslateUi(Form)

        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), Form.close)

        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), self.label_3.update)

        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):

        Form.setWindowTitle(QtGui.QApplication.translate("Form", "Prueba", None, QtGui.QApplication.UnicodeUTF8))

        self.pushButton.setText(QtGui.QApplication.translate("Form", "Salir", None, QtGui.QApplication.UnicodeUTF8))

        self.pushButton_2.setText(QtGui.QApplication.translate("Form", "Aplicar", None, QtGui.QApplication.UnicodeUTF8))

        self.label.setText(QtGui.QApplication.translate("Form", "Nombre:", None, QtGui.QApplication.UnicodeUTF8))

        self.label_2.setText(QtGui.QApplication.translate("Form", "Resultado:", None, QtGui.QApplication.UnicodeUTF8))

        self.label_3.setText(QtGui.QApplication.translate("Form", "Texto", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":

    import sys

    app = QtGui.QApplication(sys.argv)

    Form = QtGui.QWidget()

    ui = Ui_Form()

    ui.setupUi(Form)

    Form.show()

    sys.exit(app.exec_())
\`\`\`

Se resalta en color azul la relación de ambos botones (Salir y Aplicar) con los eventos (Form.close y label_3.update).

El cambio en el código que se tiene que hacer es crear un método en la clase creada que toma el contenido del widget lineEdit y se la pasa a label_3, se muestra en la consola por medio de print y en la etiqueta por el método set de la etiqueta.

A continuación el código modificado con las secciones en azul que muestra lo explicado antes:
\`\`\`python
#!/usr/bin/env python

# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'prueba3.ui'

#

# Created: Sun Jul 29 22:27:29 2012

#      by: PyQt4 UI code generator 4.9.1

#

# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:

    _fromUtf8 = QtCore.QString.fromUtf8

except AttributeError:

    _fromUtf8 = lambda s: s

class Ui_Form(object):

    def Actualizar(self):

        texto = self.lineEdit.text()

        print texto

        self.label_3.setText(texto)



    def setupUi(self, Form):

        Form.setObjectName(_fromUtf8("Form"))

        Form.resize(400, 300)

        self.pushButton = QtGui.QPushButton(Form)

        self.pushButton.setGeometry(QtCore.QRect(280, 260, 102, 28))

        self.pushButton.setObjectName(_fromUtf8("pushButton"))

        self.pushButton_2 = QtGui.QPushButton(Form)

        self.pushButton_2.setGeometry(QtCore.QRect(140, 260, 102, 28))

        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))

        self.lineEdit = QtGui.QLineEdit(Form)

        self.lineEdit.setGeometry(QtCore.QRect(140, 40, 221, 28))

        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))

        self.label = QtGui.QLabel(Form)

        self.label.setGeometry(QtCore.QRect(20, 40, 69, 18))

        self.label.setObjectName(_fromUtf8("label"))

        self.label_2 = QtGui.QLabel(Form)

        self.label_2.setGeometry(QtCore.QRect(20, 160, 81, 18))

        self.label_2.setObjectName(_fromUtf8("label_2"))

        self.label_3 = QtGui.QLabel(Form)

        self.label_3.setGeometry(QtCore.QRect(140, 160, 221, 18))

        self.label_3.setObjectName(_fromUtf8("label_3"))

        self.retranslateUi(Form)

        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), Form.close)

        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), self.Actualizar)

        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):

        Form.setWindowTitle(QtGui.QApplication.translate("Form", "Prueba", None, QtGui.QApplication.UnicodeUTF8))

        self.pushButton.setText(QtGui.QApplication.translate("Form", "Salir", None, QtGui.QApplication.UnicodeUTF8))

        self.pushButton_2.setText(QtGui.QApplication.translate("Form", "Aplicar", None, QtGui.QApplication.UnicodeUTF8))

        self.label.setText(QtGui.QApplication.translate("Form", "Nombre:", None, QtGui.QApplication.UnicodeUTF8))

        self.label_2.setText(QtGui.QApplication.translate("Form", "Resultado:", None, QtGui.QApplication.UnicodeUTF8))

        self.label_3.setText(QtGui.QApplication.translate("Form", "Texto", None, QtGui.QApplication.UnicodeUTF8))

if __name__ == "__main__":

    import sys

    app = QtGui.QApplication(sys.argv)

    Form = QtGui.QWidget()

    ui = Ui_Form()

    ui.setupUi(Form)

    Form.show()

    sys.exit(app.exec_())
\`\`\`

A continuación se muestra la figura de la ejecución de la aplicación luego de capturar y mostrar la información del widget \`LineEdit\`:

![](/blog/images/tutorialdepyqtdesarrolloconqtdesigner-5.png) 


##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))),r(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},r(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},r(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},r(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),r(o,{"aria-label":`Enviar un correo a ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},r(u,{"aria-hidden":`true`,size:16}),r(`span`,{},`ecrespo@gmail.com`))),r(`p`,{className:`text-sm text-gray-700`},r(`span`,{},`Hecho con `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),r(`span`,{},` · alojado en `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),r(`span`,{"aria-hidden":`true`},` · `),r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),r(`nav`,{"aria-label":`Redes sociales`,className:`flex items-center gap-4`},r(o,{"aria-label":`Medium (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),r(o,{"aria-label":`LinkedIn (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),r(o,{"aria-label":`Twitter (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),r(o,{"aria-label":`GitHub (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),r(o,{"aria-label":`GitLab (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},r(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},r(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),r(o,{"aria-label":`Blog (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},r(p,{"aria-hidden":`true`,size:18})))),r(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},r(`span`,{},`© 2026 Ernesto Crespo. Todos los derechos reservados.`),r(`span`,{},`Código fuente bajo la `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`licencia Apache 2.0`),` · `,r(o,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`Ver el código`)))))),r(`title`,{},`Blog | Tutorial de PyQt. Desarrollo con QtDesigner. Parte 11.`),r(`meta`,{content:`favicon.ico`,property:`og:image`}))}A.displayName=`Component(es/blog/tutorialdepyqtdesarrolloconqtdesigner-11)`;var j=n(A);export{j as default};