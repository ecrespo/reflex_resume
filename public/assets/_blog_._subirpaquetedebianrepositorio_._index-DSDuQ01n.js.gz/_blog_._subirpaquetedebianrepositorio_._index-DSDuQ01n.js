import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{Gt as r,Ht as i,Nt as a,et as o,tt as s}from"./createLucideIcon-B1BUtjEZ.js";import{n as c,t as l}from"./code-Bfm7iQ52.js";import{a as u,i as d,n as f,o as p,s as m,t as h}from"./rss-rOPIheM1.js";import{a as g,c as _,f as v,g as y,i as b,l as x,m as S,n as C,o as w,r as T,t as E,u as D}from"./one-dark-mSSrGAeQ.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(i);return{h1:({node:e,children:t,...n})=>a(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>a(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>a(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>a(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>a(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>a(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>a(s,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>a(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>a(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>a(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>a(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>a(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:o,...s}=n.children.props,c=String(Array.isArray(o)?o.join(`
`):o).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return a(T,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?C:E,wrapLongLines:!0,...s})}}}function A(){return a(O.Fragment,{},a(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`en`},a(O.Fragment,{},a(`div`,{className:`md:hidden`},a(y,{},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(m,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(u,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),a(r,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(u,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),a(`div`,{className:`w-full px-4`},a(S,{},`Download Resume`)),a(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},a(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`EN`)),a(r,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/subirpaquetedebianrepositorio`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`ES`)))))),a(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},a(`div`,{className:`mb-4 text-center`},a(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),a(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),a(`div`,{className:`mb-4`},a(m,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),a(u,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},a(`ul`,{className:`list-none m-0 p-0`},a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),a(`li`,{className:`flex items-start mb-1.5 last:mb-0`},a(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),a(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),a(r,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(u,{size:`sm`},a(`div`,{className:`flex items-center gap-2`},a(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),a(`div`,{className:`flex-1`},a(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),a(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),a(`div`,{className:`w-full px-4`},a(S,{},`Download Resume`)),a(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},a(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`EN`)),a(r,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/subirpaquetedebianrepositorio`},a(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),a(`span`,{className:`font-semibold`},`ES`)))))),a(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},a(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},a(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},a(`div`,{className:`md:hidden flex-shrink-0`},a(v,{},`Menu`)),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/`},`HOME`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog`},`BLOG`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/tags`},`TAGS`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/feed.xml`},`ATOM`),a(r,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/dev-dashboard-stats`},`DEV DASHBOARD STATS`))),a(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},a(`div`,{className:`container mx-auto max-w-4xl`},a(`div`,{className:`mb-6`},a(d,{href:`/blog`},`← Back to the blog`)),a(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},a(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Subir un paquete Debian (pyching) al repositorio`),a(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},a(`span`,{className:`text-gray-500`},`April 09, 2009`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(p,{size:`sm`,tone:2},`Linux,Empaquetado`),a(`span`,{className:`text-gray-400 mx-2`},` • `),a(`span`,{className:`text-gray-600`},`By `),a(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),a(`article`,{className:`post-content`,lang:`es`},a(`div`,{className:`prose prose-lg max-w-none`},a(D,{components:k(),rehypePlugins:[w,g,b],remarkPlugins:[x,_]},`Como la intención es utilizar el comando hg-buildpackage para construir un paquete
Debian, pero como en Debian muy pocos usan mercurial como repositorio. Tuve que crear
un repositorio en bitbucket.org para mis paquetes.

Para ello es necesario crear el repositorio en bitbucket.org.

Luego su equipo crear el directorio del paquete:

\`\`\`
mkdir pyching
cd pyching
\`\`\`

Bajarse las fuentes de pyching:
\`\`\`
apt-get source pyching
Leyendo lista de paquetes... Hecho
Creando árbol de dependencias
Leyendo la información de estado... Hecho
Necesito descargar 139kB de archivos fuente.
Des:1 http://debian.velug.org.ve sid/main pyching 1.2.2-5 (dsc) [1092B]
Des:2 http://debian.velug.org.ve sid/main pyching 1.2.2-5 (tar) [134kB]
Des:3 http://debian.velug.org.ve sid/main pyching 1.2.2-5 (diff) [3931B]
Descargados 139kB en 5s (27,8kB/s)
dpkg-source: extracting pyching in pyching-1.2.2
dpkg-source: info: unpacking pyching_1.2.2.orig.tar.gz
dpkg-source: info: applying pyching_1.2.2-5.diff.gz

\`\`\`

Cambiarse al directorio pyching-1.2.2:

\`\`\`
cd pyching-1.2.2
\`\`\`

Crear el repositorio:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/pyching-1.2.2$ hg init
\`\`\`

Agregar las fuentes al repositorio:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/pyching-1.2.2$ hg add
adding #smgHtmlView.py#
adding BUGS
adding CHANGES
adding COPYING
adding COPYRIGHT
adding CREDITS
adding INSTALL
adding NEWS
adding README
adding debian/changelog
adding debian/compat
adding debian/control
adding debian/copyright
adding debian/dirs
adding debian/docs
adding debian/menu
adding debian/pyching-small.xpm
adding debian/pycompat
adding debian/rules
adding debian/watch
adding icon.xbm
adding pyching.1
adding pyching.png
adding pyching.py
adding pyching.pyw
adding pyching.sh
adding pyching_cimages.py
adding pyching_engine.py
adding pyching_hlhtx_data.py
adding pyching_idimage_data.py
adding pyching_int_data.py
adding pyching_interface_tkinter.py
adding smgAbout.py
adding smgAnimate.py
adding smgDialog.py
adding smgHtmlView.py

\`\`\`

Se hace el commit:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/pyching-1.2.2$ hg commit -m"Subir el paquete pyching al repositorio"
\`\`\`

Subir al repositorio:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/pyching-1.2.2$ hg push http://bitbucket.org/ecrespo/pyching/
pushing to http://bitbucket.org/ecrespo/pyching/
searching for changes
http authorization required
realm: Bitbucket.org HTTP
user: ecrespo
password:
bb/acl: ecrespo is allowed. accepted payload.
quota: 340.8 KB in use, 150.0 MB available (0.22% used)
\`\`\`

Ya en este punto el paquete se encuentra en el servidor de repositorios mercurial.


![pyching](./imagenes/pyching.png)

Ahora se crea un directorio temporal para trabajar con los fuentes para empaquetarlo:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/temporal$ hg clone http://bitbucket.org/ecrespo/pyching/
destination directory: pyching
requesting all changes
adding changesets
adding manifests
adding file changes
added 1 changesets with 36 changes to 36 files
updating working directory
36 files updated, 0 files merged, 0 files removed, 0 files unresolved

\`\`\`

Para finalizar se ejecuta el comando para empaquetar:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/temporal/pyching-1.2.2$ hg-buildpackage -us -uc -rfakeroot
Upstream file/directory already exists; not building
dpkg-buildpackage -rfakeroot -D -us -uc -i.hg -I.hg
dpkg-buildpackage: set CFLAGS to default value: -g -O2
dpkg-buildpackage: set CPPFLAGS to default value:
dpkg-buildpackage: set LDFLAGS to default value:
dpkg-buildpackage: set FFLAGS to default value: -g -O2
dpkg-buildpackage: set CXXFLAGS to default value: -g -O2
dpkg-buildpackage: source package pyching
dpkg-buildpackage: source version 1.2.2-5
dpkg-buildpackage: source changed by Ernesto Nadir Crespo Avila
dpkg-buildpackage: host architecture i386
fakeroot debian/rules clean
dh_testdir
dh_testroot
dh_clean
dpkg-source -i.hg -I.hg -b pyching-1.2.2
dpkg-source: info: using source format \`1.0'
dpkg-source: info: building pyching using existing pyching_1.2.2.orig.tar.gz
dpkg-source: info: building pyching in pyching_1.2.2-5.diff.gz
dpkg-source: warning: ignoring deletion of file #smgHtmlView.py#
dpkg-source: info: building pyching in pyching_1.2.2-5.dsc
debian/rules build
make: No se hace nada para \`build'.
fakeroot debian/rules binary
dh_testdir
dh_testroot
dh_prep
dh_installdirs
install -m 644 pyching_cimages.py pyching_engine.py \\
pyching_hlhtx_data.py pyching_idimage_data.py \\
pyching_int_data.py pyching_interface_tkinter.py \\
smgAbout.py smgAnimate.py smgDialog.py smgHtmlView.py \\
debian/pyching/usr/share/pyching/
install -m 755 pyching.py debian/pyching/usr/share/pyching/
install -m 644 pyching.png debian/pyching-small.xpm debian/pyching/usr/share/pixmaps/
install pyching.sh debian/pyching/usr/games/pyching
ln -s ../doc/pyching/CREDITS debian/pyching/usr/share/pyching/CREDITS
dh_testdir
dh_testroot
dh_installchangelogs CHANGES
dh_installdocs
dh_installmenu
dh_installman pyching.1
dh_link
dh_compress
dh_fixperms
dh_pycentral
dh_python /usr/share/pyching
dh_python: Doing nothing since dh_pycompat exists; dh_pysupport or dh_pycentral should do the work. You can remove dh_python from your rules file.
dh_installdeb
dh_gencontrol
dh_md5sums
dh_builddeb
atención, \`debian/pyching/DEBIAN/control' contiene un campo \`Python-Version' definido por el usuario
dpkg-deb: no se tendrán en cuenta 1 avisos sobre los ficheros de control
dpkg-deb: construyendo el paquete \`pyching' en \`../pyching_1.2.2-5_all.deb'.
dpkg-genchanges >../pyching_1.2.2-5_i386.changes
dpkg-genchanges: not including original source code in upload
dpkg-buildpackage: binary and diff upload (original source NOT included)
Now running lintian...
Finished running lintian.

\`\`\`

Luego se revisa el directorio donde se creo el paquete:

\`\`\`
ecrespo@canaima:~/paquetes/pyching/temporal/pyching-1.2.2$ cd ..
ecrespo@canaima:~/paquetes/pyching/temporal$ ls
pyching-1.2.2 pyching_1.2.2-5.diff.gz pyching_1.2.2-5_i386.build pyching_1.2.2.orig.tar.gz
pyching_1.2.2-5_all.deb pyching_1.2.2-5.dsc pyching_1.2.2-5_i386.changes
\`\`\`



===

¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)
`))))),a(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},a(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},a(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},a(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),a(r,{"aria-label":`Send an e-mail to ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},a(f,{"aria-hidden":`true`,size:16}),a(`span`,{},`ecrespo@gmail.com`))),a(`p`,{className:`text-sm text-gray-700`},a(`span`,{},`Built with `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),a(`span`,{},` · hosted on `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),a(`span`,{"aria-hidden":`true`},` · `),a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),a(`nav`,{"aria-label":`Social networks`,className:`flex items-center gap-4`},a(r,{"aria-label":`Medium (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),a(r,{"aria-label":`LinkedIn (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),a(r,{"aria-label":`Twitter (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),a(r,{"aria-label":`GitHub (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),a(r,{"aria-label":`GitLab (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},a(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},a(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),a(r,{"aria-label":`Blog (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://blog.seraph.to`},a(h,{"aria-hidden":`true`,size:18})))),a(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},a(`span`,{},`© 2026 Ernesto Crespo. All rights reserved.`),a(`span`,{},`Source code under the `,a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`Apache 2.0 License`),` · `,a(r,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`View the source`)))))),a(`title`,{},`Blog | Subir un paquete Debian (pyching) al repositorio`),a(`meta`,{content:`favicon.ico`,property:`og:image`}))}A.displayName=`Component(blog/subirpaquetedebianrepositorio)`;var j=n(A);export{j as default};