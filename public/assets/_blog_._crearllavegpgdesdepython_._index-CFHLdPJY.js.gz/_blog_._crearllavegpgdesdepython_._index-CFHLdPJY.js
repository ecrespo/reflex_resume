import{r as e}from"./rolldown-runtime-hePW80VL.js";import{W as t,a as n}from"./components-DO_H3UDc.js";import{R as r,V as i,n as a,t as o}from"./link-vstu2bOu.js";import{n as s}from"./emotion-react.browser.esm-D8ztlwVE.js";import{n as c,t as l}from"./code-LbbYdDpU.js";import{a as u,d,l as f,o as p,t as m}from"./blog-DvIX7I_t.js";import{a as h,c as g,i as _,l as v,n as y,o as b,r as x,t as S,u as C}from"./one-dark-tuQvF_Ko.js";var w=e(t(),1);function T(){let{resolvedColorMode:e}=(0,w.useContext)(r);return{h1:({node:e,children:t,...n})=>s(c,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(c,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(c,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(c,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(c,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(c,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(a,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(o,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(l,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(x,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?y:S,wrapLongLines:!0,...o})}}}function E(){return s(w.Fragment,{},s(`div`,{className:`flex min-h-screen font-['Inter'] bg-[#f5f5dc]`},s(w.Fragment,{},s(w.Fragment,{},s(f,{},s(w.Fragment,{},s(d,{})),s(w.Fragment,{}))),s(m,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(i,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`))))),s(`aside`,{className:`hidden md:flex w-96 min-h-screen bg-[#7dd3c0] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-teal-600/10`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4`},s(u,{},`✕`),s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-2xl font-bold text-gray-900 mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-gray-700 text-sm font-medium tracking-wide`},`Resume`)),s(`img`,{alt:`Ernesto Crespo`,className:`w-24 h-24 rounded-xl object-cover mb-4 shadow-sm bg-gray-100 border-2 border-white/30`,src:`/ec.jpg`}),s(`div`,{className:`w-full flex flex-col mb-3`},s(`h2`,{className:`text-base font-bold text-gray-800 mb-2 self-start w-full pl-1`},`Summary`),s(`div`,{className:`bg-[#73cbb6] p-4 rounded-lg w-full shadow-sm`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-blue-700 text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(i,{className:`block w-full`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full bg-white rounded-lg p-3 mb-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-200`},s(o,{asChild:!0,className:`block w-full`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4a9bba" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                            <path d="M8 7h6"></path>
                            <path d="M8 11h8"></path>
                        </svg>
                    `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Blog`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver artículos`)))))),s(`div`,{className:`w-full px-4`},s(`p`,{className:`text-sm text-gray-700 font-medium mb-1`},`Wish to connect?`),s(o,{asChild:!0,className:`text-sm text-blue-600 hover:text-blue-800 hover:underline mb-2 inline-block`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{target:`_blank`,to:`mailto:ecrespo@gmail.com`},`📧 ecrespo@gmail.com`)),s(o,{asChild:!0,className:`inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow-sm text-sm`,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{download:`ErnestoCrespo.pdf`,target:`_blank`,to:`/Resume_Ernesto_Crespo_software.pdf`},`Download Resume`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-96`},s(`nav`,{className:`w-full h-14 bg-[#4a9bba] flex items-center shadow-sm flex-shrink-0 z-20 sticky top-0`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(p,{},s(`div`,{className:`flex flex-col`},s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white mb-1.5`}),s(`span`,{className:`block w-6 h-0.5 bg-white`}))),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/`},`HOME`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog`},`BLOG`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/archives`},`ARCHIVES`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/categories`},`CATEGORIES`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/blog/tags`},`TAGS`),s(i,{className:`text-white hover:text-white/80 text-sm font-medium hover:underline transition-all whitespace-nowrap`,to:`/feed.xml`},`ATOM`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(o,{asChild:!0,css:{"&:hover":{color:`var(--accent-8)`}}},s(i,{to:`/blog`},s(`span`,{className:`inline-flex items-center px-4 py-2 bg-[#4a9bba] text-white rounded-lg hover:bg-[#3a8baa] transition-colors font-medium mb-6`},`← Volver al Blog`))),s(`header`,{className:`mb-8 pb-6 border-b border-gray-200`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-gray-900 mb-4`},`Crear llave gpg desde Python`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-gray-500`},`March 03, 2012`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-[#4a9bba] font-medium`},`Tutorial de Python`),s(`span`,{className:`text-gray-400 mx-2`},` • `),s(`span`,{className:`text-gray-600`},`Por `),s(`span`,{className:`text-gray-800 font-medium`},`Unknown`))),s(`article`,{className:`post-content`},s(`div`,{className:`prose prose-lg max-w-none`},s(C,{components:T(),rehypePlugins:[b,h,_],remarkPlugins:[v,g]},`Existen varias herramientas para crear, manipular llaves \`gpg\`.

Quienes no conozcan de \`GPG\` pueden leer el siguiente [tutorial](http://personales.upv.es/%7Ealalbiol/pages/Mini_Tutorial_GPG.html).

El paquete para python que permite manejar  las llaves \`gpg\` es \`python-pyme\`.  

\`\`\`
#apt-get install python-pyme python-pyme-doc
\`\`\`

La documentación de la librería pyme la encuentran en el siguiente [enlace](http://pyme.sourceforge.net/doc/pyme/index.html).

En la documentación se tiene una lista de ejemplos, se copia el archivo de \`genkey.py\` al home del usuario:  

\`\`\`
cp /usr/share/doc/python-pyme-doc/examples/genkey.py ~/
\`\`\`

Se edita el archivo \`genkey.py\`, se modifica el tipo de llave a RSA, se define la longitud de la llave (1024,2048 o 4096), longitud de la subllave (el mismo valor de la lñongitud de la llave), el nombre real, comentario del nombre, correo, frase de la llave, fecha de expiración de la llave.  
\`\`\`python 
#!/usr/bin/env python
# $Id: genkey.py,v 1.6 2008/03/08 18:21:08 belyi Exp $
# Copyright (C) 2004 Igor Belyi <belyi@users.sourceforge.net>
# Copyright (C) 2002 John Goerzen <jgoerzen@complete.org>
#
#    This program is free software; you can redistribute it and/or #modify
#    it under the terms of the GNU General Public License as #published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty #of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  #See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public #License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  #02111-1307  #USA


#Importar pyme
from pyme import core, callbacks

# Initialize our context.
#Inicializa el contexto.
core.check_version(None)
c = core.Context()
#Se define algunas configuraciones
c.set_armor(1)
c.set_progress_cb(callbacks.progress_stdout, None)

# This example from the GPGME manual
#Este es un ejemplo desde el manual gpgme.

parms = """<GnupgKeyParms format="internal">
Key-Type: RSA
Key-Length: 2048
Subkey-Type: ELG-E
Subkey-Length: 2048
Name-Real: Ernesto Nadir Crespo Avila
Name-Comment: seraph1
Name-Email: ecrespo@gmail.com
Passphrase: frasedelallave
Expire-Date: 2020-08-15
</GnupgKeyParms>
"""
#Se genera la llave pasandole los parámetros.
c.op_genkey(parms, None, None)
#Se imprime en patanalla el resultado de la generación.
print c.op_genkey_result().fpr
\`\`\`	

Para crear la llave se ejecuta el archivo \`genkey.py\`:  
\`\`\`python 
$python genkey.py
......
PROGRESS UPDATE: what = primegen, type = 46, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 46, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 43, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 43, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 43, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 43, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 43, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 94, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 94, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 94, current = 0, total = 0
PROGRESS UPDATE: what = primegen, type = 94, current = 0, total = 0
FFF598686F3ADE35C52BF65E4478C8341643F0EB
\`\`\`

Al desplegar la lista de llaves se tiene lo siguiente:  
\`\`\`python 
$gpg --list-keys
...
pub   2048R/1643F0EB 2012-03-04 [caduca: 2020-08-15]
uid                  Ernesto Nadir Crespo Avila (seraph1) <ecrespo@gmail.com>
sub   2048g/9F8E9C20 2012-03-04 [caduca: 2020-08-15]
\`\`\`
Los últimos 8 números hexagecimales es el identificador de la llave \`gpg\`. Luego se exporta a un servidor de llaves y se puede compartir la llave pública para firmar o cifrar correos.


##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))))),s(`title`,{},`Blog | Crear llave gpg desde Python`),s(`meta`,{content:`favicon.ico`,property:`og:image`}))}E.displayName=`Component(blog/crearllavegpgdesdepython)`;var D=n(E);export{D as default};