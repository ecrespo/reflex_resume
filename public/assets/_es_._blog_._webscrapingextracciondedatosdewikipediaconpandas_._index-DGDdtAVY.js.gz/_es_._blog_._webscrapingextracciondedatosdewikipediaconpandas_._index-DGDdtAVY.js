import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{J as r,Z as i,o as a,s as o,z as s}from"./createLucideIcon-BKyn4FuD.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-Bi-t7m2Z.js";import{a as m,c as h,f as g,g as _,i as v,l as y,m as b,n as x,o as S,r as C,t as w,u as T}from"./one-dark-CtQwBnrQ.js";import{n as E,t as D}from"./code-CYC7Gv0B.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(r);return{h1:({node:e,children:t,...n})=>s(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(o,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(D,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?x:w,wrapLongLines:!0,...o})}}}function A(){return s(O.Fragment,{},s(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`es`},s(O.Fragment,{},s(`div`,{className:`md:hidden`},s(_,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),s(`div`,{className:`mb-4`},s(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),s(l,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),s(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(l,{size:`sm`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),s(`div`,{className:`w-full px-4`},s(b,{},`Descargar currículum`)),s(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},s(i,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/webscrapingextracciondedatosdewikipediaconpandas`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`EN`)),s(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`ES`)))))),s(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),s(`div`,{className:`mb-4`},s(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),s(l,{className:`w-full mb-3`,headingLevel:2,title:`Resumen`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero electricista.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Desarrollador Python.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de IA.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Analista de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero de datos.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Ingeniero cloud de AWS.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Científico de datos.`)))),s(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(l,{size:`sm`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`Ver el perfil de LinkedIn`))))),s(`div`,{className:`w-full px-4`},s(b,{},`Descargar currículum`)),s(`nav`,{"aria-label":`Idioma`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},s(i,{"aria-label":`Leer esta página en English`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`en`},title:`English`,to:`/blog/webscrapingextracciondedatosdewikipediaconpandas`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`EN`)),s(`span`,{"aria-current":`true`,"aria-label":`Español (idioma actual)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`Español`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`ES`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},s(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(`div`,{className:`md:hidden flex-shrink-0`},s(g,{},`Menú`)),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es`},`Inicio`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/resume`},`Currículum`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/portfolio`},`Portafolio`),s(i,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/es/blog`},`Blog`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/dev-dashboard-stats`},`Estadísticas de desarrollo`),s(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/archives`},`Archivo`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/categories`},`Categorías`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/es/blog/tags`},`Etiquetas`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/es/feed.xml`},`Atom`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(`div`,{className:`mb-6`},s(c,{href:`/es/blog`},`← Volver al blog`)),s(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`WebScraping (extracción de datos) de wikipedia con Pandas`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-[#3E6A5E]`},`19 de abril de 2018`),s(`span`,{className:`text-[#5C7B71] mx-2`},` • `),s(d,{size:`sm`,tone:2},`Tutorial Python`),s(`span`,{className:`text-[#5C7B71] mx-2`},` • `),s(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`Por`,s(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),s(`article`,{className:`post-content`,lang:`es`},s(`div`,{className:`prose prose-lg max-w-none`},s(T,{components:k(),rehypePlugins:[S,m,v],remarkPlugins:[y,h]},`Continuando con la serie de artículos sobre [Pandas](/es/blog/tags), en este artículo se muestra un proceso de extracción de datos web de la [página que contiene información sobre  los Estados de Venezuela de Wikipedia](https://es.wikipedia.org/wiki/Estados_de_Venezuela).

En los procesos anteriores de WebScraping se trabajaba practicamente a mano para indentificar  las secciones del código html donde se encuentra la información útil, para el caso con Pandas este abstrae ese proceso.

A continuación se muestra una captura de pantalla de la página donde se quiere extraer la información:

![](/blog/images/webscrapingextracciondedatosdewikipediaconpandas-1.png)

La información que maneja la página son los estados con sus capitales, densidad poblacional, superficie, año de admisión, población, densidad, región y código ISO, la parte de la bandera ni del mapa no se muestra por que son imágenes y no se obtiene información útil de ellas.

A continuación todo el proceso de extracción de información de la página:

In [1]:
\`\`\`python
#Se importa pandas como pd
import pandas as pd
#Se lee los datos de wikipedia de los estados de venezuela, este devuelve una lista
estados=   pd.read_html('https://es.wikipedia.org/wiki/Estados_de_Venezuela') 
estados
\`\`\`
Out[1]:
\`\`\`python
[    0                                                  1
 0 NaN  Este artículo o sección necesita referencias q...,
                                                    0
 0                     Estados Federales de Venezuela
 1  Bolívar Amazonas Apure Zulia Táchira Barinas M...,
           0                       1                       2           3  \\
 0   Bandera         Entidad federal                 Capital  Código ISO   
 1       NaN                Amazonas         Puerto Ayacucho        VE-Z   
 2       NaN              Anzoátegui               Barcelona        VE-B   
 3       NaN                   Apure   San Fernando de Apure        VE-C   
 4       NaN                  Aragua                 Maracay        VE-D   
 5       NaN                 Barinas                 Barinas        VE-E   
 6       NaN                 Bolívar          Ciudad Bolívar        VE-F   
 7       NaN                Carabobo                Valencia        VE-G   
 8       NaN                 Cojedes              San Carlos        VE-H   
 9       NaN           Delta Amacuro                Tucupita        VE-Y   
 10      NaN        Distrito Capital                 Caracas        VE-A   
 11      NaN                  Falcón                    Coro        VE-I   
 12      NaN                 Guárico  San Juan de Los Morros        VE-J   
 13      NaN                    Lara            Barquisimeto        VE-K   
 14      NaN                  Mérida                  Mérida        VE-L   
 15      NaN                 Miranda              Los Teques        VE-M   
 16      NaN                 Monagas                 Maturín        VE-N   
 17      NaN           Nueva Esparta             La Asunción        VE-O   
 18      NaN              Portuguesa                 Guanare        VE-P   
 19      NaN                   Sucre                  Cumaná        VE-R   
 20      NaN                 Táchira           San Cristóbal        VE-S   
 21      NaN                Trujillo                Trujillo        VE-T   
 22      NaN                  Vargas               La Guaira        VE-X   
 23      NaN                 Yaracuy              San Felipe        VE-U   
 24      NaN                   Zulia               Maracaibo        VE-V   
 25      NaN  Dependencias Federales              Gran Roque        VE-W   

                   4                                 5  \\
 0   Año de admisión              Población (2011)[2]​   
 1              1992    &&&&&&&&&0161844.&&&&&0161 844   
 2              1909  &&&&&&&&02179838.&&&&&02 179 838   
 3              1864    &&&&&&&&&0501404.&&&&&0501 404   
 4              1909  &&&&&&&&01819630.&&&&&01 819 630   
 5              1937    &&&&&&&&&0853949.&&&&&0853 949   
 6              1901  &&&&&&&&02069064.&&&&&02 069 064   
 7              1865  &&&&&&&&02342665.&&&&&02 342 665   
 8              1864    &&&&&&&&&0367020.&&&&&0367 020   
 9              1992    &&&&&&&&&0180363.&&&&&0180 363   
 10             1999  &&&&&&&&04033186.&&&&&04 033 186   
 11             1872  &&&&&&&&01064615.&&&&&01 064 615   
 12             1864    &&&&&&&&&0746174.&&&&&0746 174   
 13             1909  &&&&&&&&01892439.&&&&&01 892 439   
 14             1909    &&&&&&&&&0903955.&&&&&0903 955   
 15             1909  &&&&&&&&03112851.&&&&&03 112 851   
 16             1909    &&&&&&&&&0938185.&&&&&0938 185   
 17             1909    &&&&&&&&&0525139.&&&&&0525 139   
 18             1909    &&&&&&&&&0897104.&&&&&0897 104   
 19             1909    &&&&&&&&&0892990.&&&&&0892 990   
 20             1899  &&&&&&&&01277241.&&&&&01 277 241   
 21             1864    &&&&&&&&&0901239.&&&&&0901 239   
 22             1998    &&&&&&&&&0419928.&&&&&0419 928   
 23             1899    &&&&&&&&&0645688.&&&&&0645 688   
 24             1864  &&&&&&&&04694856.&&&&&04 694 856   
 25             1938       &&&&&&&&&&&02155.&&&&&02155   

                                  6                              7  \\
 0                 Superficie (km²)             Densidad (hab/km²)   
 1   &&&&&&&&&0177617.&&&&&0177 617    &&&&&&&&&&&&&&00.9900000,99   
 2    &&&&&&&&&&043300.&&&&&043 300    &&&&&&&&&&&&&033.90000033,9   
 3    &&&&&&&&&&076500.&&&&&076 500     &&&&&&&&&&&&&&06.&&&&&06,0   
 4      &&&&&&&&&&&07014.&&&&&07014   &&&&&&&&&&&&0235.600000235,6   
 5    &&&&&&&&&&035200.&&&&&035 200    &&&&&&&&&&&&&023.20000023,2   
 6   &&&&&&&&&0240528.&&&&&0240 528    &&&&&&&&&&&&&&07.8700007,87   
 7      &&&&&&&&&&&04650.&&&&&04650  &&&&&&&&&&&&0713.&10000713,01   
 8    &&&&&&&&&&014800.&&&&&014 800    &&&&&&&&&&&&&021.80000021,8   
 9    &&&&&&&&&&040200.&&&&&040 200    &&&&&&&&&&&&&&04.6500004,65   
 10      &&&&&&&&&&&&0433.&&&&&0433  &&&&&&&&&&&07246.4000007246,4   
 11   &&&&&&&&&&024800.&&&&&024 800    &&&&&&&&&&&&&036.40000036,4   
 12   &&&&&&&&&&064986.&&&&&064 986    &&&&&&&&&&&&&011.50000011,5   
 13   &&&&&&&&&&019800.&&&&&019 800    &&&&&&&&&&&&&089.60000089,6   
 14   &&&&&&&&&&011300.&&&&&011 300    &&&&&&&&&&&&&092.80000092,8   
 15     &&&&&&&&&&&07950.&&&&&07950   &&&&&&&&&&&&0336.500000336,5   
 16   &&&&&&&&&&028900.&&&&&028 900    &&&&&&&&&&&&&031.30000031,3   
 17     &&&&&&&&&&&01150.&&&&&01150  &&&&&&&&&&&&0480.&10000480,01   
 18   &&&&&&&&&&015200.&&&&&015 200    &&&&&&&&&&&&&057.70000057,7   
 19   &&&&&&&&&&011800.&&&&&011 800    &&&&&&&&&&&&&076.&&&&&076,0   
 20   &&&&&&&&&&011100.&&&&&011 100   &&&&&&&&&&&&0105.300000105,3   
 21     &&&&&&&&&&&07400.&&&&&07400    &&&&&&&&&&&&&092.80000092,8   
 22     &&&&&&&&&&&01497.&&&&&01497   &&&&&&&&&&&&0235.800000235,8   
 23     &&&&&&&&&&&07100.&&&&&07100    &&&&&&&&&&&&&084.60000084,6   
 24   &&&&&&&&&&063100.&&&&&063 100    &&&&&&&&&&&&&073.70000073,7   
 25      &&&&&&&&&&&&0120.&&&&&0120    &&&&&&&&&&&&&018.&&&&&018,0   

                     8     9  
 0              Región  Mapa  
 1             Guayana   NaN  
 2      Nor - Oriental   NaN  
 3              Llanos   NaN  
 4             Central   NaN  
 5              Andina   NaN  
 6             Guayana   NaN  
 7             Central   NaN  
 8             Central   NaN  
 9             Guayana   NaN  
 10            Capital   NaN  
 11  Centro-Occidental   NaN  
 12             Llanos   NaN  
 13  Centro-Occidental   NaN  
 14             Andina   NaN  
 15            Capital   NaN  
 16     Nor - Oriental   NaN  
 17            Insular   NaN  
 18  Centro-Occidental   NaN  
 19     Nor - Oriental   NaN  
 20             Andina   NaN  
 21             Andina   NaN  
 22            Capital   NaN  
 23  Centro-Occidental   NaN  
 24            Zuliana   NaN  
 25            Insular   NaN  ]
\`\`\`
In [2]:
\`\`\`python
#Tipo de los estados
type(estados)
\`\`\`
Out[2]:
\`\`\`python
list
\`\`\`
In [3]:
\`\`\`python
#Tipo del primer elemento es un dataframe
type(estados[0])
\`\`\`
Out[3]:
\`\`\`python
pandas.core.frame.DataFrame
\`\`\`
In [4]:
\`\`\`python
#Se listan del dataframe estados y capitales (elementos 1 y 2 del dataframe, y se recorre)
for i in range(1,26):
    print(estados[2][1][i],estados[2][2][i])
Amazonas Puerto Ayacucho
Anzoátegui Barcelona
Apure San Fernando de Apure
Aragua Maracay
Barinas Barinas
Bolívar Ciudad Bolívar
Carabobo Valencia
Cojedes San Carlos
Delta Amacuro Tucupita
Distrito Capital Caracas
Falcón Coro
Guárico San Juan de Los Morros
Lara Barquisimeto
Mérida Mérida
Miranda Los Teques
Monagas Maturín
Nueva Esparta La Asunción
Portuguesa Guanare
Sucre Cumaná
Táchira San Cristóbal
Trujillo Trujillo
Vargas La Guaira
Yaracuy San Felipe
Zulia Maracaibo
Dependencias Federales Gran Roque
\`\`\`
In [5]:
\`\`\`python
#Ahora se crea una lista de diccionarios donde estará la información de cada estado
lista = []
for i in range(1,26):
    lista.append({'Estado':estados[2][1][i],
                  'Capital': estados[2][2][i],
                  'codigo_iso': estados[2][3][i],
                  u'año_admision': estados[2][4][i],
                  'Poblacion': int(estados[2][5][i].split(".")[0].split("&")[-1]),
                  'Superficie': int(estados[2][6][i].split(".")[0].split("&")[-1]),
                  'Densidad': float(estados[2][7][i].split(",")[0].split("&")[-1]),
                  'Region': estados[2][8][i]
                 })

print(lista)
[{'Region': 'Guayana', 'Densidad': 0.99, 'Superficie': 177617, 'Estado': 'Amazonas', 'codigo_iso': 'VE-Z', 'Poblacion': 161844, 'Capital': 'Puerto Ayacucho', 'año_admision': '1992'}, {'Region': 'Nor - Oriental', 'Densidad': 33.90000033, 'Superficie': 43300, 'Estado': 'Anzoátegui', 'codigo_iso': 'VE-B', 'Poblacion': 2179838, 'Capital': 'Barcelona', 'año_admision': '1909'}, {'Region': 'Llanos', 'Densidad': 6.0, 'Superficie': 76500, 'Estado': 'Apure', 'codigo_iso': 'VE-C', 'Poblacion': 501404, 'Capital': 'San Fernando de Apure', 'año_admision': '1864'}, {'Region': 'Central', 'Densidad': 235.600000235, 'Superficie': 7014, 'Estado': 'Aragua', 'codigo_iso': 'VE-D', 'Poblacion': 1819630, 'Capital': 'Maracay', 'año_admision': '1909'}, {'Region': 'Andina', 'Densidad': 23.20000023, 'Superficie': 35200, 'Estado': 'Barinas', 'codigo_iso': 'VE-E', 'Poblacion': 853949, 'Capital': 'Barinas', 'año_admision': '1937'}, {'Region': 'Guayana', 'Densidad': 7.8700007, 'Superficie': 240528, 'Estado': 'Bolívar', 'codigo_iso': 'VE-F', 'Poblacion': 2069064, 'Capital': 'Ciudad Bolívar', 'año_admision': '1901'}, {'Region': 'Central', 'Densidad': 10000713.0, 'Superficie': 4650, 'Estado': 'Carabobo', 'codigo_iso': 'VE-G', 'Poblacion': 2342665, 'Capital': 'Valencia', 'año_admision': '1865'}, {'Region': 'Central', 'Densidad': 21.80000021, 'Superficie': 14800, 'Estado': 'Cojedes', 'codigo_iso': 'VE-H', 'Poblacion': 367020, 'Capital': 'San Carlos', 'año_admision': '1864'}, {'Region': 'Guayana', 'Densidad': 4.6500004, 'Superficie': 40200, 'Estado': 'Delta Amacuro', 'codigo_iso': 'VE-Y', 'Poblacion': 180363, 'Capital': 'Tucupita', 'año_admision': '1992'}, {'Region': 'Capital', 'Densidad': 7246.4000007246, 'Superficie': 433, 'Estado': 'Distrito Capital', 'codigo_iso': 'VE-A', 'Poblacion': 4033186, 'Capital': 'Caracas', 'año_admision': '1999'}, {'Region': 'Centro-Occidental', 'Densidad': 36.40000036, 'Superficie': 24800, 'Estado': 'Falcón', 'codigo_iso': 'VE-I', 'Poblacion': 1064615, 'Capital': 'Coro', 'año_admision': '1872'}, {'Region': 'Llanos', 'Densidad': 11.50000011, 'Superficie': 64986, 'Estado': 'Guárico', 'codigo_iso': 'VE-J', 'Poblacion': 746174, 'Capital': 'San Juan de Los Morros', 'año_admision': '1864'}, {'Region': 'Centro-Occidental', 'Densidad': 89.60000089, 'Superficie': 19800, 'Estado': 'Lara', 'codigo_iso': 'VE-K', 'Poblacion': 1892439, 'Capital': 'Barquisimeto', 'año_admision': '1909'}, {'Region': 'Andina', 'Densidad': 92.80000092, 'Superficie': 11300, 'Estado': 'Mérida', 'codigo_iso': 'VE-L', 'Poblacion': 903955, 'Capital': 'Mérida', 'año_admision': '1909'}, {'Region': 'Capital', 'Densidad': 336.500000336, 'Superficie': 7950, 'Estado': 'Miranda', 'codigo_iso': 'VE-M', 'Poblacion': 3112851, 'Capital': 'Los Teques', 'año_admision': '1909'}, {'Region': 'Nor - Oriental', 'Densidad': 31.30000031, 'Superficie': 28900, 'Estado': 'Monagas', 'codigo_iso': 'VE-N', 'Poblacion': 938185, 'Capital': 'Maturín', 'año_admision': '1909'}, {'Region': 'Insular', 'Densidad': 10000480.0, 'Superficie': 1150, 'Estado': 'Nueva Esparta', 'codigo_iso': 'VE-O', 'Poblacion': 525139, 'Capital': 'La Asunción', 'año_admision': '1909'}, {'Region': 'Centro-Occidental', 'Densidad': 57.70000057, 'Superficie': 15200, 'Estado': 'Portuguesa', 'codigo_iso': 'VE-P', 'Poblacion': 897104, 'Capital': 'Guanare', 'año_admision': '1909'}, {'Region': 'Nor - Oriental', 'Densidad': 76.0, 'Superficie': 11800, 'Estado': 'Sucre', 'codigo_iso': 'VE-R', 'Poblacion': 892990, 'Capital': 'Cumaná', 'año_admision': '1909'}, {'Region': 'Andina', 'Densidad': 105.300000105, 'Superficie': 11100, 'Estado': 'Táchira', 'codigo_iso': 'VE-S', 'Poblacion': 1277241, 'Capital': 'San Cristóbal', 'año_admision': '1899'}, {'Region': 'Andina', 'Densidad': 92.80000092, 'Superficie': 7400, 'Estado': 'Trujillo', 'codigo_iso': 'VE-T', 'Poblacion': 901239, 'Capital': 'Trujillo', 'año_admision': '1864'}, {'Region': 'Capital', 'Densidad': 235.800000235, 'Superficie': 1497, 'Estado': 'Vargas', 'codigo_iso': 'VE-X', 'Poblacion': 419928, 'Capital': 'La Guaira', 'año_admision': '1998'}, {'Region': 'Centro-Occidental', 'Densidad': 84.60000084, 'Superficie': 7100, 'Estado': 'Yaracuy', 'codigo_iso': 'VE-U', 'Poblacion': 645688, 'Capital': 'San Felipe', 'año_admision': '1899'}, {'Region': 'Zuliana', 'Densidad': 73.70000073, 'Superficie': 63100, 'Estado': 'Zulia', 'codigo_iso': 'VE-V', 'Poblacion': 4694856, 'Capital': 'Maracaibo', 'año_admision': '1864'}, {'Region': 'Insular', 'Densidad': 18.0, 'Superficie': 120, 'Estado': 'Dependencias Federales', 'codigo_iso': 'VE-W', 'Poblacion': 2155, 'Capital': 'Gran Roque', 'año_admision': '1938'}]
\`\`\`
In [6]:
\`\`\`python
#Luego se crea un dataframe de la lista de diccionarios
df = pd.DataFrame(lista)
df
\`\`\`
Out[6]:
| ID | Capital               | Densidad     | Estado          | Poblacion    | Region           | Superficie  | año_admision  | codigo_iso |
| :- | :----------------:    | :----------: | :-------------  | :------:     | :-------------:  | :-------    | :-----:       | :-------:  |
| 0  | Puerto Ayacucho       | 9.900000e-01 | Amazonas        | 161844       | Guayana          | 177617      | 1992          | VE-Z       |
| 1  | Barcelona             | 3.390000e+01 | Anzoátegui      | 2179838      | Nor - Oriental   | 43300       | 1909          | VE-B       |
| 2  | San Fernando de Apure | 6.000000e+00 | Apure           | 501404       | Llanos           | 76500       | 1864          | VE-C       |
| 3  | Maracay               | 2.356000e+02 | Aragua          | 1819630      | Central          | 7014        | 1909          | VE-D       |
| 4  | Barinas               | 2.320000e+01 | Barinas         | 853949       | Andina           | 35200       | 1937          | VE-E       |
| 5  | Ciudad Bolívar        | 7.870001e+00 | Bolívar         | 2069064      | Guayana          | 240528      | 1901          | VE-F       |
| 6  | Valencia              | 1.000071e+07	| Carabobo	      | 2342665      | Central          | 4650	      | 1865          | VE-G       |
| 7  | San Carlos            | 2.180000e+01 | Cojedes         | 367020       | Central          | 14800       | 1864          | VE-H       |
| 8  | Tucupita              | 4.650000e+00 | Delta Amacuro   | 180363       | Guayana          | 40200       | 1992          | VE-Y       |
| 9  | Caracas               | 7.246400e+03 | Distrito Capital| 4033186      | Capital          | 433         | 1999          | VE-A       |
| 10 | Coro                  | 3.640000e+01 | Falcón          | 1064615      |Centro-Occidental | 24800       | 1872          | VE-I       |
| 11 | San Juan de Los Morros| 1.150000e+01 | Guárico         | 746174       | Llanos           | 64986       | 1864          | VE-J       |
| 12 | Barquisimeto          | 8.960000e+01 | Lara            | 1892439      | Centro-Occidental| 19800       | 1909          | VE-K       |
| 13 | Mérida                | 9.280000e+01 | Mérida          | 903955       | Andina           | 11300       | 1909          | VE-L       |
| 14 | Los Teques            | 3.365000e+02 | Miranda         | 3112851      | Capital          | 7950        | 1909          | VE-M       |
| 15 | Maturín               | 3.130000e+01 | Monagas         | 938185       | Nor - Oriental   | 28900       | 1909          | VE-N       |
| 16 | La Asunción           | 1.000048e+07 | Nueva Esparta   | 525139       | Insular          | 1150        | 1909          | VE-O       |
| 17 | Guanare               | 5.770000e+01 | Portuguesa      | 897104       | Centro-Occidental| 15200       | 1909          | VE-P       |
| 18 | Cumaná                | 7.600000e+01 | Sucre           | 892990       | Nor - Oriental   | 11800       | 1909          | VE-R       |
| 19 | San Cristóbal         | 1.053000e+02 | Táchira         | 1277241      | Andina           | 11100       | 1899          | VE-S       |
| 20 | Trujillo              | 9.280000e+01 | Trujillo        | 901239       | Andina           | 7400        | 1864          | VE-T       |
| 21 | La Guaira             | 2.358000e+02 | Vargas          | 419928       | Capital          | 1497        | 1998          | VE-X       |
| 22 | San Felipe            | 8.460000e+01 | Yaracuy         | 645688       | Centro-Occidental| 7100        | 1899          | VE-U       |
| 23 | Maracaibo             | 7.370000e+01 | Zulia           | 4694856      | Zuliana          | 63100       | 1864          | VE-V       |
| 24 | Gran Roque            | 1.800000e+01 | D. Federales    |2155          | Insular          |  120        | 1938          | VE-W       |

In [7]:
\`\`\`python
#Si se quiere la información de Carabobo
mascara = df["Estado"] == "Carabobo"
df[mascara]
\`\`\`
Out[7]:
| ID | Capital               | Densidad     | Estado          | Poblacion    | Region           | Superficie  | año_admision  | codigo_iso |
| :- | :----------------:    | :----------: | :-------------  | :------:     | :-------------:  | :-------    | :-----:       | :-------:  |
| 6  | Valencia              | 1.000071e+07	| Carabobo	      | 2342665      | Central          | 4650	      | 1865          | VE-G       |

In [8]:
\`\`\`python
#Otra forma de traer la información de Carabobo
df.iloc[6]
Out[8]:
Capital            Valencia
Densidad        1.00007e+07
Estado             Carabobo
Poblacion           2342665
Region              Central
Superficie             4650
año_admision           1865
codigo_iso             VE-G
Name: 6, dtype: object
\`\`\`
In [9]:
\`\`\`python
#Para obtener la capital del estado
df.iloc[6]["Capital"]
\`\`\`
Out[9]:
\`\`\`python
'Valencia'
\`\`\`
In [ ]:
\`\`\`

\`\`\`
El proceso de eliminar la basura dentro del texto de algunos campos no se muestra, pero se usa en la construcción del diccionario.

##  ##
¡Haz tu donativo!
Si te gustó el artículo puedes realizar un donativo con Bitcoin (BTC)
usando la billetera digital de tu preferencia a la siguiente
dirección: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

O Escaneando el código QR desde la billetera:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)


`))))),s(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},s(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},s(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},s(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),s(i,{"aria-label":`Enviar un correo a ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},s(u,{"aria-hidden":`true`,size:16}),s(`span`,{},`ecrespo@gmail.com`))),s(`p`,{className:`text-sm text-gray-700`},s(`span`,{},`Hecho con `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),s(`span`,{},` · alojado en `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),s(`nav`,{"aria-label":`Redes sociales`,className:`flex items-center gap-4`},s(i,{"aria-label":`Medium (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),s(i,{"aria-label":`LinkedIn (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),s(i,{"aria-label":`Twitter (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),s(i,{"aria-label":`GitHub (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),s(i,{"aria-label":`GitLab (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),s(i,{"aria-label":`Blog (se abre en una pestaña nueva)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},s(p,{"aria-hidden":`true`,size:18})))),s(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},s(`span`,{},`© 2026 Ernesto Crespo. Todos los derechos reservados.`),s(`span`,{},`Código fuente bajo la `,s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`licencia Apache 2.0`),` · `,s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`Ver el código`)))))),s(`title`,{},`Blog | WebScraping (extracción de datos) de wikipedia con Pandas`),s(`meta`,{content:`https://www.seraph.to/blog/images/webscrapingextracciondedatosdewikipediaconpandas-1.png`,property:`og:image`}),s(`meta`,{content:`article`,property:`og:type`}),s(`meta`,{content:`Ernesto Crespo`,property:`og:site_name`}),s(`meta`,{content:`WebScraping (extracción de datos) de wikipedia con Pandas`,property:`og:title`}),s(`meta`,{content:`https://www.seraph.to/es/blog/webscrapingextracciondedatosdewikipediaconpandas`,property:`og:url`}),s(`meta`,{content:`summary_large_image`,name:`twitter:card`}),s(`meta`,{content:`WebScraping (extracción de datos) de wikipedia con Pandas`,name:`twitter:title`}),s(`meta`,{content:`https://www.seraph.to/blog/images/webscrapingextracciondedatosdewikipediaconpandas-1.png`,name:`twitter:image`}))}A.displayName=`Component(es/blog/webscrapingextracciondedatosdewikipediaconpandas)`;var j=n(A);export{j as default};