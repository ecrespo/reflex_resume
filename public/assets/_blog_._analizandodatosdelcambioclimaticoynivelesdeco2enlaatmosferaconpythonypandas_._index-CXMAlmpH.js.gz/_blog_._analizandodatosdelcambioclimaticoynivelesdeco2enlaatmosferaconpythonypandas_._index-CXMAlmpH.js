import{Q as e,Y as t,x as n}from"./errorBoundaries-Dt_DLUVF.js";import{J as r,Z as i,o as a,s as o,z as s}from"./createLucideIcon-BKyn4FuD.js";import{a as c,i as l,n as u,o as d,s as f,t as p}from"./rss-Bi-t7m2Z.js";import{a as m,c as h,h as g,i as _,l as v,m as y,n as b,o as x,p as S,r as C,t as w,u as T}from"./one-dark-CtQwBnrQ.js";import{n as E,t as D}from"./code-CYC7Gv0B.js";var O=e(t(),1);function k(){let{resolvedColorMode:e}=(0,O.useContext)(r);return{h1:({node:e,children:t,...n})=>s(E,{as:`h1`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`6`,...n},t),h2:({node:e,children:t,...n})=>s(E,{as:`h2`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`5`,...n},t),h3:({node:e,children:t,...n})=>s(E,{as:`h3`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`4`,...n},t),h4:({node:e,children:t,...n})=>s(E,{as:`h4`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`3`,...n},t),h5:({node:e,children:t,...n})=>s(E,{as:`h5`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`2`,...n},t),h6:({node:e,children:t,...n})=>s(E,{as:`h6`,css:{marginTop:`0.5em`,marginBottom:`0.5em`},size:`1`,...n},t),p:({node:e,children:t,...n})=>s(o,{as:`p`,css:{marginTop:`1em`,marginBottom:`1em`},...n},t),ul:({node:e,children:t,...n})=>s(`ul`,{css:{listStyleType:`disc`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),ol:({node:e,children:t,...n})=>s(`ol`,{css:{listStyleType:`decimal`,marginTop:`1em`,marginBottom:`1em`,marginLeft:`1.5rem`,direction:`column`},...n},t),li:({node:e,children:t,...n})=>s(`li`,{css:{marginTop:`0.5em`,marginBottom:`0.5em`},...n},t),a:({node:e,children:t,...n})=>s(a,{css:{"&:hover":{color:`var(--accent-8)`}},href:`#`,...n},t),code:({node:e,children:t,...n})=>s(D,{...n},t),pre:({node:t,...n})=>{let{node:r,className:i,children:a,...o}=n.children.props,c=String(Array.isArray(a)?a.join(`
`):a).replace(/\n$/,``),l=(i||``).match(/language-(?<lang>.*)/),u=l?l[1]:``;return s(C,{children:c,codeTagProps:{style:{whiteSpace:`pre-wrap`}},css:{marginTop:`1em`,marginBottom:`1em`},customStyle:{marginTop:`1em`,marginBottom:`1em`},language:u,style:e?.valueOf?.()===`light`.valueOf?.()?b:w,wrapLongLines:!0,...o})}}}function A(){return s(O.Fragment,{},s(`div`,{className:`flex min-h-screen bg-[#f5f5dc]`,lang:`en`},s(O.Fragment,{},s(`div`,{className:`md:hidden`},s(g,{},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),s(`div`,{className:`mb-4`},s(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),s(l,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),s(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(l,{size:`sm`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full px-4`},s(y,{},`Download Resume`)),s(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},s(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`EN`)),s(i,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`ES`)))))),s(`aside`,{className:`hidden md:flex w-60 min-h-screen bg-[#DFF1EC] flex-shrink-0 flex-col fixed left-0 top-0 h-full overflow-y-auto border-r border-[#5C7B71]/60`},s(`div`,{className:`flex flex-col items-center pt-6 px-4 w-full pb-4 min-h-full`},s(`div`,{className:`mb-4 text-center`},s(`h1`,{className:`text-[1.7rem] font-semibold text-[#1F3D36] mb-0.5 tracking-tight`},`Ernesto Crespo.`),s(`p`,{className:`italic text-[#3E6A5E] text-base tracking-wide`},`Seraph13`)),s(`div`,{className:`mb-4`},s(f,{name:`Ernesto Crespo`,pixelSize:96,shape:`circle`,src:`/ec_drawing.jpg`})),s(l,{className:`w-full mb-3`,headingLevel:2,title:`Summary`},s(`ul`,{className:`list-none m-0 p-0`},s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Electrical Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Python Developer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AI Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data analyst.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`AWS Cloud Engineer.`)),s(`li`,{className:`flex items-start mb-1.5 last:mb-0`},s(`span`,{className:`text-[#2C6355] text-xl leading-none mr-2 align-middle inline-block`},`•`),s(`span`,{className:`text-gray-700 font-medium text-sm`},`Data Scientist.`)))),s(i,{className:`block w-full mb-3 hover:shadow-md transition-shadow rounded-lg`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(l,{size:`sm`},s(`div`,{className:`flex items-center gap-2`},s(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#0077b5" aria-hidden="true">
                        <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                `}}),s(`div`,{className:`flex-1`},s(`p`,{className:`font-bold text-gray-900 text-sm mb-0`},`Ernesto Crespo`),s(`p`,{className:`text-xs text-gray-600 mb-0`},`View LinkedIn Profile`))))),s(`div`,{className:`w-full px-4`},s(y,{},`Download Resume`)),s(`nav`,{"aria-label":`Language`,className:`w-full flex justify-end gap-1.5 mt-auto pt-4 px-1`},s(`span`,{"aria-current":`true`,"aria-label":`English (current language)`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-[#2F6F86] bg-white/70 text-[#1F3D36]`,title:`English`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#012169"/>
            <path d="M0,0 L60,40 M60,0 L0,40" stroke="#fff" stroke-width="8"/>
            <path d="M0,0 L30,20 M60,0 L30,20 M0,40 L30,20 M60,40 L30,20" stroke="#C8102E" stroke-width="3"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#fff" stroke-width="12"/>
            <path d="M30,0 V40 M0,20 H60" stroke="#C8102E" stroke-width="7"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`EN`)),s(i,{"aria-label":`Read this page in Español`,className:`inline-flex items-center gap-1.5 px-1.5 py-1 rounded border text-xs tracking-wide transition-colors border-transparent text-[#3E6A5E] hover:border-[#5C7B71]/60 hover:text-[#1F3D36]`,css:{hreflang:`es`},title:`Español`,to:`/es/blog/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas`},s(`div`,{className:`rx-Html flex shadow-sm`,dangerouslySetInnerHTML:{__html:`
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="27" height="18" aria-hidden="true">
            <rect width="60" height="40" fill="#AA151B"/>
            <rect y="10" width="60" height="20" fill="#F1BF00"/>
        </svg>
    `}}),s(`span`,{className:`font-semibold`},`ES`)))))),s(`div`,{className:`flex-1 flex flex-col min-w-0 bg-[#f5f5dc] min-h-screen md:ml-60`},s(`nav`,{className:`w-full h-14 bg-[#DFF1EC] flex items-center flex-shrink-0 z-20 sticky top-0 border-b border-[#5C7B71]/60`},s(`div`,{className:`flex flex-row gap-6 items-center overflow-x-auto w-full px-4 md:px-8 h-full no-scrollbar`},s(`div`,{className:`md:hidden flex-shrink-0`},s(S,{},`Menu`)),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/`},`Home`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/resume`},`Resume`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/portfolio`},`Portfolio`),s(i,{"aria-current":`page`,className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap underline decoration-2 text-[#2F6F86]`,to:`/blog`},`Blog`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/dev-dashboard-stats`},`Dev Dashboard Stats`),s(`span`,{"aria-hidden":`true`,className:`h-5 w-px bg-[#5C7B71]/50 flex-shrink-0`}),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/archives`},`Archives`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/categories`},`Categories`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,to:`/blog/tags`},`Tags`),s(i,{className:`[font-variant:small-caps] text-[1.05rem] tracking-wide text-[#1F3D36] hover:text-[#2F6F86] underline-offset-4 decoration-1 decoration-[#2F6F86] hover:underline transition-colors whitespace-nowrap`,reloadDocument:!0,to:`/feed.xml`},`Atom`))),s(`main`,{className:`p-4 md:p-8 lg:p-16 w-full`},s(`div`,{className:`container mx-auto max-w-4xl`},s(`div`,{className:`mb-6`},s(c,{href:`/blog`},`← Back to the blog`)),s(`header`,{className:`mb-8 pb-6 border-b border-[#5C7B71]/40`},s(`h1`,{className:`text-3xl md:text-4xl font-bold text-[#1F3D36] leading-tight mb-4`},`Analyzing climate change data and atmospheric CO2 levels with Python and pandas.`),s(`div`,{className:`flex items-center flex-wrap text-sm mb-6`},s(`span`,{className:`text-[#3E6A5E]`},`October 14, 2018`),s(`span`,{className:`text-[#5C7B71] mx-2`},` • `),s(d,{size:`sm`,tone:2},`Python tutorial`),s(`span`,{className:`text-[#5C7B71] mx-2`},` • `),s(`span`,{className:`text-[#3E6A5E] inline-flex gap-1`},`By`,s(`span`,{className:`text-[#1F3D36] font-medium`},`Ernesto Crespo`)))),s(`article`,{className:`post-content`,lang:`en`},s(`div`,{className:`prose prose-lg max-w-none`},s(T,{components:k(),rehypePlugins:[x,m,_],remarkPlugins:[v,h]},`Continuing with the articles about data science, this time data on global and per-country climate information, as well as CO2 levels, will be analyzed.

I found this data and project on the [kaggle (broken link)](https://www.kaggle.com/) site, which is a site for publishing data science projects. You can find the data for this article at the following [link (broken link)](https://www.kaggle.com/derevirn/data-analysis-on-climate-change/data). 

The code in this article is based on the article on kaggle on the subject, in English: [Climate Change and CO2 levels in atmosphere (broken link)](https://www.kaggle.com/derevirn/data-analysis-on-climate-change/notebook).

This article explores the global changes in mean temperature and the increase in the concentration of CO2 in the atmosphere.

The data comes from the following files:  

- GlobalLandTemperaturesByCountry.csv: Contains the temperature information by country.  
- GlobalTemperatures.csv: Contains the global temperature information.  
- archive.csv: Contains the information on CO2 levels in the atmosphere.  

The notebook is shown below:

[https://www.kaggle.com/derevirn/data-analysis-on-climate-change/notebook (broken link)](https://www.kaggle.com/derevirn/data-analysis-on-climate-change/notebook)
[https://www.kaggle.com/derevirn/data-analysis-on-climate-change/data (broken link)](https://www.kaggle.com/derevirn/data-analysis-on-climate-change/data)

#### Import the pandas, matplotlib and seaborn libraries.
In [1]:
\`\`\`python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
\`\`\`
#### Create the dataframes from the csv files.
In [2]:
\`\`\`python
# Se crea el dataframe data_pais, data_vzla, data_global y co2_ppm

data_pais = pd.read_csv("./datos/GlobalLandTemperaturesByCountry.csv")
#Se crea una copia del dataframe obteniendo solo la información de Venezuela.
data_vzla = data_pais[data_pais["Country"] == "Venezuela"].copy()
data_vzla["dt"] = pd.to_datetime(data_vzla["dt"])

#Se crea una copia del dataframe obteniendo solo la información de Argentina.
data_arg = data_pais[data_pais["Country"] == "Argentina"].copy()
data_arg["dt"] = pd.to_datetime(data_arg["dt"])

#Se crea una copia del dataframe obteniendo solo la información de USA.
data_canada = data_pais[data_pais["Country"] == "Canada"].copy()
data_canada["dt"] = pd.to_datetime(data_canada["dt"])

#Se crea una copia del dataframe obteniendo solo la información de Mexico.
data_mexico = data_pais[data_pais["Country"] == "Mexico"].copy()
data_mexico["dt"] = pd.to_datetime(data_mexico["dt"])

#Se crea una copia del dataframe obteniendo solo la información de Brasil.
data_brasil = data_pais[data_pais["Country"] == "Brazil"].copy()
data_brasil["dt"] = pd.to_datetime(data_brasil["dt"])

#Se crea una copia del dataframe obteniendo solo la información de Venezuela.
data_chile = data_pais[data_pais["Country"] == "Chile"].copy()
data_chile["dt"] = pd.to_datetime(data_chile["dt"])

#Se crea el dataframe de la temperatura global. 
data_global = pd.read_csv("./datos/GlobalTemperatures.csv")
#Se modifica la fecha y hora como datetime.
data_global["dt"] = pd.to_datetime(data_global["dt"])
#Se crea el dataframe del co2.
co2_ppm = pd.read_csv("./datos/archive.csv")
\`\`\`
#### The dataframes created.
In [3]:
\`\`\`python
data_pais.head()
\`\`\`
Out[3]:

| ID | dt          | Average Temperature | Average Temperature Uncertainty | Country |
|:-- | :--------:  | :----------------:  | :-----------------------------: | :----   |
| 0	 | 1743-11-01  | 4.384          	 | 2.294						   | Åland   |
| 1	 | 1743-12-01  | NaN	 			 | NaN							   | Åland   |
| 2	 | 1744-01-01  | NaN	 			 | NaN							   | Åland   |
| 3	 | 1744-02-01  | NaN				 | NaN							   | Åland   |
| 4	 | 1744-03-01  | NaN	 			 | NaN							   | Åland   |

As can be seen, there is the date, the average temperature, the average temperature uncertainty and the country.
In [4]:
\`\`\`python
data_pais.info()
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 577462 entries, 0 to 577461
Data columns (total 4 columns):
dt                               577462 non-null object
AverageTemperature               544811 non-null float64
AverageTemperatureUncertainty    545550 non-null float64
Country                          577462 non-null object
dtypes: float64(2), object(2)
memory usage: 17.6+ MB
\`\`\`
The data types of the columns are: dt is object, average temperature and average temperature uncertainty are float64, and country is object
#### Venezuela
In [5]:
\`\`\`python
data_vzla.head()
\`\`\`
Out[5]:

| ID     |    dt      | Average Temperature | Average Temperature Uncertainty | Country   |
|:------ | :-------:  | :----------------:  | :-----------------------------: | :------   |
| 562339 | 1824-01-01 |	24.613				| 0.824							  |	Venezuela |
| 562340 | 1824-02-01 |	24.670				| 2.017							  |	Venezuela |
| 562341 | 1824-03-01 |	25.527				| 1.065							  |	Venezuela |
| 562342 | 1824-04-01 |	25.732				| 1.771							  |	Venezuela |
| 562343 | 1824-05-01 |	24.999				| 1.157							  |	Venezuela |

This is the same information as above but only for Venezuela.
In [6]:
\`\`\`python
data_vzla.describe().T
\`\`\`
Out[6]:

|	                           | count  | mean 		| std      | min    | 25% 	   | 50%     | 75%		| max    |
|:---------------------------- | :---:  | :------:  | :------: | :---   | :------- | :----:  | :-----:  | :----: | 
|AverageTemperature			   | 2086.0 | 25.025686	| 0.703189 | 22.777 | 24.52325 | 24.9825 | 25.49525	| 27.807 |
|AverageTemperatureUncertainty | 2086.0 | 0.586000	| 0.398460 | 0.084	| 0.31000  | 0.4540	 | 0.76000	| 4.120  |

There are 2086 data points, for which the average temperature is 25.025 degrees and the uncertainty is 0.586; the standard deviation of the average temperature is 0.703 and of the uncertainty is 0.398; the minimum temperature was 22.77 and the maximum 27.807.
In [7]:
\`\`\`python
data_vzla.corr()
\`\`\`
Out[7]:

|					 			| AverageTemperature | AverageTemperatureUncertainty |
|:--------------------------- - | :---------------:  | :---------------------------: | 
|AverageTemperature				| 1.000000			 | -0.319882					 |
|AverageTemperatureUncertainty	| -0.319882			 | 1.000000						 |

The two variables are, to a certain extent, inversely correlated.
Argentina
In [8]:
\`\`\`python
data_arg.head()
\`\`\`
Out[8]:

| ID     |    dt      | Average Temperature | Average Temperature Uncertainty | Country   |
|:------ | :-------:  | :----------------:  | :-----------------------------: | :------   |
| 25466	 | 1855-05-01 |	10.745				| 1.499                           |	Argentina |
| 25467	 | 1855-06-01 |	6.995				| 2.073                           |	Argentina |
| 25468	 | 1855-07-01 |	6.901				| 1.568                           |	Argentina |
| 25469	 | 1855-08-01 |	9.097				| 1.412                           |	Argentina |
| 25470	 | 1855-09-01 |	11.316	            | 1.384                           |	Argentina |

In [9]:
\`\`\`python
data_arg.describe().T
\`\`\`
Out[9]:

|	                           | count  | mean 		| std      | min    | 25% 	   | 50%     | 75%		| max    |
|:---------------------------- | :---:  | :------:  | :------: | :---   | :------- | :----:  | :-----:  | :----: | 
|AverageTemperature			   | 1900.0	| 14.621194	| 4.846885 | 4.796	| 10.13225 | 14.6305 | 19.27875 | 23.290 |
|AverageTemperatureUncertainty | 1900.0	| 0.527338	| 0.465652 | 0.083	| 0.20900  | 0.3035  | 0.74525	| 2.974  |

#### Brazil
In [10]:
\`\`\`python
data_brasil.head()
\`\`\`
Out[10]:

| ID     |    dt      | Average Temperature | Average Temperature Uncertainty | Country   |
|:------ | :-------:  | :----------------:  | :-----------------------------: | :------   |
| 77110	 | 1832-01-01 | 24.935				| 1.372							  | Brazil	  |
| 77111	 | 1832-02-01 |	24.505				| 1.953							  | Brazil	  |
| 77112	 | 1832-03-01 |	24.617				| 1.359							  | Brazil	  |
| 77113	 | 1832-04-01 |	23.990				| 2.013							  | Brazil	  |
| 77114	 | 1832-05-01 |	23.124				| 1.592							  | Brazil	  |

In [11]:
\`\`\`python
data_brasil.describe().T
\`\`\`
Out[11]:

|	                           | count  | mean 		| std      | min    | 25% 	   | 50%     | 75%		| max    |
|:---------------------------- | :---:  | :------:  | :------: | :---   | :------- | :----:  | :-----:  | :----: | 
|AverageTemperature			   | 2164.0	| 24.699256	| 0.978787 | 21.797	| 24.02250 | 24.8295 | 25.44975	| 27.151 |
|AverageTemperatureUncertainty | 2164.0 | 0.572940	| 0.411794 | 0.060	| 0.24375  | 0.4160	 | 0.84000	| 3.353  |

#### Chile
In [12]:
\`\`\`python
data_chile.head()
\`\`\`
Out[12]:

|	ID	  |		dt		| AverageTemperature | AverageTemperatureUncertainty | Country |
|:------- | :--------:  | :---------------:  | :---------------------------: | :-----  |
| 108248  |	1855-05-01	| 7.152				 | 1.296						 | Chile   |
| 108249  |	1855-06-01	| 4.257				 | 1.641						 | Chile   |
| 108250  |	1855-07-01	| 4.113				 | 1.313						 | Chile   |
| 108251  |	1855-08-01	| 5.508				 | 1.168						 | Chile   |
| 108252  |	1855-09-01	| 6.684				 | 1.153						 | Chile   |

In [13]:
\`\`\`python
data_chile.describe().T
\`\`\`
Out[13]:

|	                           | count  | mean 		| std      | min    | 25% 	   | 50%     | 75%		| max    |
|:---------------------------- | :---:  | :------:  | :------: | :---   | :------- | :----:  | :-----:  | :----: | 
|AverageTemperature			   | 1900.0	| 9.383474	| 3.179081 | 3.206	| 6.502    | 9.3815	 | 12.37775	| 15.493 |
|AverageTemperatureUncertainty | 1900.0	| 0.572654	| 0.418011 | 0.114	| 0.281	   | 0.3825	 | 0.80300	| 2.408  |

#### Mexico
In [14]:
\`\`\`python
data_mexico.head()
\`\`\`
Out[14]:

|	ID	  |		dt		| AverageTemperature | AverageTemperatureUncertainty | Country |
|:------- | :--------:  | :---------------:  | :---------------------------: | :------ |
| 338438  |	1835-01-01	| 15.810			 | 1.484						 | Mexico  |
| 338438  |	1835-01-01	| 15.810	         | 1.484						 | Mexico  |
| 338439  |	1835-02-01	| 14.911			 | 1.579						 | Mexico  |
| 338440  |	1835-03-01	| 16.826	         | 1.858						 | Mexico  |
| 338441  |	1835-04-01	| 19.925	         | 1.966						 | Mexico  |
| 338442  |	1835-05-01	| 22.037	         | 1.609						 | Mexico  |

In [15]:
\`\`\`python
data_mexico.describe().T
\`\`\`
Out[15]:

|	                           | count  | mean 		| std      | min    | 25% 	   | 50%     | 75%		| max    |
|:---------------------------- | :---:  | :------:  | :------: | :---   | :------- | :----:  | :-----:  | :----: | 
|AverageTemperature			   | 2145.0	| 20.567558	| 3.753343 | 12.064	| 17.109   | 21.050	 | 24.164	| 26.926 |
|AverageTemperatureUncertainty | 2145.0	| 0.638233	| 0.547605 | 0.091	| 0.226	   | 0.398	 | 0.970	| 3.699  |

####Canada 
In [16]:
\`\`\`python
data_canada.head()
\`\`\`
Out[16]:

|	ID	  |		dt		| AverageTemperature | AverageTemperatureUncertainty | Country |
|:------- | :--------:  | :---------------:  | :---------------------------: | :----   |
| 97255	  | 1768-09-01	| 5.257				 | 3.107	                     | Canada  |
| 97256	  | 1768-10-01	| -3.393			 | 2.981		                 | Canada  |
| 97257	  | 1768-11-01	| -12.829			 | 3.967	                     | Canada  |
| 97258	  | 1768-12-01	| -20.582	         | 4.622	                     | Canada  |
| 97259	  | 1769-01-01	| -24.756	         | 4.722	                     | Canada  |

In [17]:
\`\`\`python
data_canada.describe().T
\`\`\`
Out[17]:

|	                           | count  | mean 		| std       | min     | 25% 	 | 50%     | 75%	 | max    |
|:---------------------------- | :---:  | :------:  | :-------: | :----   | :------- | :----:  | :----:  | :----: | 
|AverageTemperature			   | 2504.0	| -5.216659	| 12.878074	| -28.736 |	-17.7025 | -4.7285 | 7.41275 | 14.796 |
|AverageTemperatureUncertainty | 2504.0	| 1.256211	| 1.046127	| 0.123	  | 0.2870   | 0.8980  | 2.12025 | 5.275  |

Note that the variations in the average temperature uncertainty are greater in Brazil, Venezuela, Mexico and Canada, in that order, compared with Chile and Argentina.

#### Annual increase in the global average temperature
In [18]:
\`\`\`python
annual_mean_global = data_global.groupby(data_global["dt"].dt.year).mean()
reference_temperature_global = annual_mean_global.loc[1951:1980].mean()["LandAndOceanAverageTemperature"]
annual_mean_global["Anomaly"] = annual_mean_global["LandAndOceanAverageTemperature"] - reference_temperature_global
\`\`\`
In [19]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_global.loc[1960:2015]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Anomalia anual de la temperatura promedio global")
plt.xlabel('')
plt.ylabel('Anomalia de la temperatura')
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-1.png)

\`\`\`
Note that the annual temperature increase shows an upward trend that has grown in recent years; this increase in 2015 was 0.75 degrees, which is consistent with climate change.

#### Venezuela.
The same calculation is done for the case of Venezuela.
In [20]:
\`\`\`python
annual_mean_vzla = data_vzla.groupby(data_vzla["dt"].dt.year).mean()
reference_temperature_vzla = annual_mean_vzla.loc[1951:1980].mean()["AverageTemperature"]
annual_mean_vzla["Anomaly"] = annual_mean_vzla["AverageTemperature"] - reference_temperature_vzla
\`\`\`
In [21]:
\`\`\`python
annual_mean_vzla.head()
\`\`\`
Out[21]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |
|:---- | :---------------:  | :--------------------------:  | :-------: |
| 1824 |	24.896545		| 1.516091						| -0.420966 |
| 1825 |	25.071583		| 1.552083						| -0.245928 |
| 1826 |	24.871900		| 1.440800						| -0.445611 |
| 1827 |	25.156273		| 1.474182						| -0.161238 |
| 1828 |	24.751818		| 1.516727						| -0.565693 |

In [22]:
\`\`\`python
annual_mean_vzla.tail()
\`\`\`
Out[22]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |	
|:---- | :---------------:  | :--------------------------:  | :-------: |	
| 2009 |	26.084917		| 0.353917						| 0.767406  |
| 2010 |	26.150250	    | 0.341333						| 0.832739  |
| 2011 |	25.677333	    | 0.336750						| 0.359822  |
| 2012 |	25.688583	    | 0.401417                   	| 0.371072  |
| 2013 |	25.912875	    | 0.484500						| 0.595364  |

The last record is from 2013, when the increase was 0.595 degrees; there was a peak in 2010 of 0.8332 degrees.
In [23]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_vzla.loc[1960:2012]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Variación promedio anual de la temperatura de Venezuela")
plt.xlabel('')
plt.ylabel('Incremento de la temperatura')
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-2.png)

\`\`\`

#### Argentina
In [24]:
\`\`\`python
annual_mean_arg = data_arg.groupby(data_arg["dt"].dt.year).mean()
reference_temperature_arg = annual_mean_arg.loc[1951:1980].mean()["AverageTemperature"]
annual_mean_arg["Anomaly"] = annual_mean_arg["AverageTemperature"] - reference_temperature_arg
\`\`\`
In [25]:
\`\`\`python
annual_mean_arg.head()
\`\`\`
Out[25]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |		
|:---- | :---------------:  | :--------------------------:  | :-------: |		
| 1855 |	11.729250		| 1.711875						| -3.090742 |
| 1856 |	13.998750		| 1.553167						| -0.821242 |
| 1857 |	14.221083		| 1.993417						| -0.598908 |
| 1858 |	14.015667		| 1.770750						| -0.804325 |
| 1859 |	14.414583		| 1.635583						| -0.405408 |

In [26]:
\`\`\`python
annual_mean_arg.tail()
\`\`\`
Out[26]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |	
|:---- | :---------------:  | :--------------------------:  | :-------: |			
| 2009 |	15.534417		| 0.215750						| 0.714425  |
| 2010 |	15.078833		| 0.218917						| 0.258842  |
| 2011 |	15.339667		| 0.219833						| 0.519675  |
| 2012 |	15.689000		| 0.265750						| 0.869008  |
| 2013 |	14.457125		| 0.276500						| -0.362867 |

In [27]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_arg.loc[1960:2012]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Variación promedio anual de la temperatura de Argentina")
plt.xlabel('')
plt.ylabel('Incremento de la temperatura')
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-3.png)

\`\`\`

In the case of Argentina, the slope of the temperature increase trend is less pronounced.

#### Brazil
In [28]:
\`\`\`python
annual_mean_brasil = data_brasil.groupby(data_brasil["dt"].dt.year).mean()
reference_temperature_brasil = annual_mean_brasil.loc[1951:1980].mean()["AverageTemperature"]
annual_mean_brasil["Anomaly"] = annual_mean_brasil["AverageTemperature"] - reference_temperature_brasil
\`\`\` 
In [29]:
\`\`\`python
annual_mean_brasil.head()
\`\`\`
Out[29]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |
|:---- | :---------------:  | :--------------------------:  | :-------: |			
| 1832 |	23.858583		| 1.734500						| -1.072247 |
| 1833 |	24.517833		| 1.450083						| -0.412997 |
| 1834 |	24.346750		| 1.498083						| -0.584081 |
| 1835 |	23.537500		| 1.298583						| -1.393331 |
| 1836 |	23.921167		| 1.426083						| -1.009664 |

In [30]:
\`\`\`python
annual_mean_brasil.tail()
\`\`\`
Out[30]:
| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |	
|:---- | :---------------:  | :--------------------------:  | :-------: |		
| 2009 |	25.600583		| 0.185667						| 0.669753  |
| 2010 |	25.812417		| 0.158000						| 0.881586  |
| 2011 |	25.428917		| 0.204833						| 0.498086  |
| 2012 |	25.717083		| 0.231000						| 0.786253  |
| 2013 |	25.348125		| 0.262250						| 0.417294  |

In [31]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_brasil.loc[1960:2012]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Variación promedio anual de la temperatura de Brasil")
plt.xlabel('')
plt.ylabel('Incremento de la temperatura')
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-4.png)

\`\`\`

In the case of Brazil, a strong increase is noticeable in the 90s with a peak of more than 1 degree, after which the trend has stabilized at 0.79 degrees.

#### Chile
In [32]:
\`\`\`python
annual_mean_chile = data_chile.groupby(data_chile["dt"].dt.year).mean()
reference_temperature_chile = annual_mean_chile.loc[1951:1980].mean()["AverageTemperature"]
annual_mean_chile["Anomaly"] = annual_mean_chile["AverageTemperature"] - reference_temperature_chile
\`\`\`
In [33]:
\`\`\`python
annual_mean_chile.head()
\`\`\`
Out[33]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |
|:---- | :---------------:  | :--------------------------:  | :-------: |			
|1855  | 7.070125			| 1.424125						| -2.510742 |
|1856  | 8.664083			| 1.319250 						| -0.916783 |
|1857  | 8.645917			| 1.439250						| -0.934950 |
|1858  | 8.810250			| 1.428333						| -0.770617 |
|1859  | 9.245583			| 1.376917						| -0.335283 |

In [34]:
\`\`\`python
annual_mean_chile.tail()
\`\`\`
Out[34]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly  |
|:---- | :---------------:  | :--------------------------:  | :------: |			
| 2009 | 9.994417			| 0.281917						| 0.413550 |
| 2010 | 9.712833			| 0.340000 						| 0.131967 |
| 2011 | 10.032250			| 0.322250						| 0.451383 |
| 2012 | 10.272583			| 0.384583						| 0.691717 |
| 2013 | 9.877375			| 0.393875						| 0.296508 |

In [35]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_chile.loc[1960:2012]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Variación promedio anual de la temperatura de Chile")
plt.xlabel('')
plt.ylabel('Incremento de la temperatura')
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-5.png)

\`\`\`

The variation does not exceed 0.8 degrees of temperature, with a strong increase between the 70s and 80s and then a peak in the 90s.

#### Mexico
In [36]:
\`\`\`python
annual_mean_mexico = data_mexico.groupby(data_mexico["dt"].dt.year).mean()
reference_temperature_mexico = annual_mean_mexico.loc[1951:1980].mean()["AverageTemperature"]
annual_mean_mexico["Anomaly"] = annual_mean_mexico["AverageTemperature"] - reference_temperature_mexico
\`\`\`
In [37]:
\`\`\`
annual_mean_mexico.head()
\`\`\`
Out[37]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |	
|:---- | :---------------:  | :--------------------------:  | :-------: |			
| 1835 |	18.993250		| 1.684083						| -1.745911 |
| 1836 |	19.587167		| 1.695333						| -1.151994 |
| 1837 |	19.671083		| 1.647667						| -1.068078 |
| 1838 |	19.337000		| 1.862417						| -1.402161 |
| 1839 |	19.785833		| 1.603000						| -0.953328 |

In [38]:
\`\`\`python
annual_mean_mexico.tail()
\`\`\`
Out[38]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly  |	
|:---- | :---------------:  | :--------------------------:  | :------: |			
| 2009 |	21.546083		| 0.205917						| 0.806922 |
| 2010 |	20.852917		| 0.217750						| 0.113756 |
| 2011 |	21.599333		| 0.245333						| 0.860172 |
| 2012 |	21.652417		| 0.324500						| 0.913256 |
| 2013 |	22.219222		| 0.365111					    | 1.480061 |

In [39]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_mexico.loc[1960:2012]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Variación promedio anual de la temperatura de Mexico")
plt.xlabel('')
plt.ylabel('Incremento de la temperatura')
plt.show()


![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-6.png)


\`\`\`

Note the upward trend of the temperature in Mexico, reaching 2013 at 1.48 degrees above the average.

####Canada
In [40]:
\`\`\`python
annual_mean_canada = data_canada.groupby(data_canada["dt"].dt.year).mean()
reference_temperature_canada = annual_mean_canada.loc[1951:1980].mean()["AverageTemperature"]
annual_mean_canada["Anomaly"] = annual_mean_canada["AverageTemperature"] - reference_temperature_canada
\`\`\`
In [41]:
\`\`\`python
annual_mean_canada.head()
\`\`\`
Out[41]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly   |
|:---- | :---------------:  | :--------------------------:  | :-------: |			
| 1768 |	-7.886750		| 3.66925						| -2.969253 |
| 1769 |	-3.427875		| 3.50550						| 1.489622  |
| 1770 |	NaN				|	NaN							| NaN       |
| 1771 |	NaN				|	NaN							| NaN       |
| 1772 |	NaN				|	NaN							| NaN       |

In [42]:
\`\`\`python
annual_mean_canada.tail()
\`\`\`
Out[42]:

| dt   | AverageTemperature | AverageTemperatureUncertainty | Anomaly  |	
|:---- | :---------------:  | :--------------------------:  | :------: |	
| 2009 | -4.135083			| 0.231833						| 0.782414 |
| 2010 | -1.887917			| 0.218583 						| 3.029581 |
| 2011 | -3.557083			| 0.232583						| 1.360414 |
| 2012 | -3.176833			| 0.300083						| 1.740664 |
| 2013 |  -1.640667			| 0.533667						| 3.276831 |

In [43]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_mean_canada.loc[1960:2012]["Anomaly"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Variación promedio anual de la temperatura de Canadá")
plt.xlabel('')
plt.ylabel('Incremento de la temperatura')
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-7.png)

\`\`\`

Note the upward trend of the temperature in Canada, and the worrying thing is that the variation exceeds 3 degrees in 2013.

#### Annual CO2 levels in the Atmosphere
In [44]:
\`\`\`python
plt.figure()
plt.style.use("fivethirtyeight")
annual_co2_ppm = co2_ppm.groupby(co2_ppm["Year"]).mean()
annual_co2_ppm.loc[1960:2015]["Carbon Dioxide (ppm)"].plot(figsize = (10,5), grid=True, legend=True)
plt.title("Nivel anual global de CO2 en la Atmosfera")
plt.ylabel("CO2 partes por millón")
plt.show()

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-8.png)

\`\`\`
Note the annual increase with an upward trend.

#### The relationship between CO2 and temperature is calculated.
In [45]:
\`\`\`python
annual_co2_temp = pd.merge(annual_mean_global.loc[1960:2015], annual_co2_ppm.loc[1960:2015], left_index=True, right_index=True)
annual_co2_temp = annual_co2_temp[["LandAndOceanAverageTemperature", "Anomaly", "Carbon Dioxide (ppm)"]].copy()
annual_co2_temp.corr()
\`\`\`
Out[45]:

|								 | LandAndOceanAverageTemperature | Anomaly	 | Carbon Dioxide (ppm) |
|:------------------------------ | :---------------------------:  | :------: | :------------------- |
| LandAndOceanAverageTemperature | 1.000000						  | 1.000000 | 0.923603				|
| Anomaly						 | 1.000000						  | 1.000000 | 0.923603             |
| Carbon Dioxide (ppm)			 | 0.923603						  |	0.923603 | 1.000000             |

In [46]:
\`\`\`python
sns.heatmap(annual_co2_temp.corr())
\`\`\`
Out[46]:
\`\`\`python
<matplotlib.axes._subplots.AxesSubplot at 0x7fcacea9cdd8>
\`\`\`
![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-9.png)

In [47]:
\`\`\`python
plt.figure(figsize=(10,8))
sns.scatterplot(x="Anomaly",y="Carbon Dioxide (ppm)", data=annual_co2_temp)
\`\`\`

![](/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-10.png)

Out[47]:
\`\`\`python
<matplotlib.axes._subplots.AxesSubplot at 0x7fcace8d6c50>
\`\`\`

With the heat map and the scatter plot, the practically linear relationship between the temperature increase and Carbon Dioxide is evident. Both are related to Climate Change.
In [ ]:
\`\`\`python

\`\`\`

The site where the data is stored has more files, for example temperature by city, to go into more detail on the situation per city. You can also keep looking for info on other countries; in the original article Greece was done, and here I tried Argentina, Brazil, Chile, Canada, Mexico and Venezuela.

##  ##
Make a donation!
If you liked the article you can make a donation with Bitcoin (BTC)
using the digital wallet of your choice to the following
address: 17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV

Or by scanning the QR code from your wallet:

![17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV](/blog/images/17MtNybhdkA9GV3UNS6BTwPcuhjXoPrSzV.png)`))))),s(`footer`,{className:`mt-auto w-full bg-[#DFF1EC] border-t border-[#5C7B71]/60`},s(`div`,{className:`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 md:px-8 lg:px-16 py-3`},s(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`},s(`span`,{className:`font-semibold text-[#1F3D36]`},`Ernesto Crespo`),s(i,{"aria-label":`Send an e-mail to ecrespo@gmail.com`,className:`flex items-center gap-1.5 text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,to:`mailto:ecrespo@gmail.com`},s(u,{"aria-hidden":`true`,size:16}),s(`span`,{},`ecrespo@gmail.com`))),s(`p`,{className:`text-sm text-gray-700`},s(`span`,{},`Built with `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://www.python.org`},`Python`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://reflex.dev`},`Reflex`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://pypi.org/project/reflex-silverpoint-react/`},`reflex-silverpoint-react`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://tailwindcss.com`},`Tailwind CSS`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://docs.astral.sh/uv/`},`uv`),s(`span`,{},` · hosted on `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://vercel.com`},`Vercel`),s(`span`,{"aria-hidden":`true`},` · `),s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://railway.com`},`Railway`)),s(`nav`,{"aria-label":`Social networks`,className:`flex items-center gap-4`},s(i,{"aria-label":`Medium (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Medium`,to:`https://seraph13.medium.com/`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z`}))),s(i,{"aria-label":`LinkedIn (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`LinkedIn`,to:`https://www.linkedin.com/in/ernestocrespo/`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`}))),s(i,{"aria-label":`Twitter (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Twitter`,to:`https://twitter.com/_seraph1`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z`}))),s(i,{"aria-label":`GitHub (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitHub`,to:`https://github.com/ecrespo`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12`}))),s(i,{"aria-label":`GitLab (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`GitLab`,to:`https://gitlab.com/ecrespo`},s(`svg`,{"aria-hidden":`true`,css:{fill:`currentColor`},height:`18`,viewBox:`0 0 24 24`,width:`18`},s(`path`,{d:`m23.6004 9.5927-.0337-.0862L20.3.9814a.851.851 0 0 0-.3362-.405.8748.8748 0 0 0-.9997.0539.8748.8748 0 0 0-.29.4399l-2.2055 6.748H7.5375l-2.2057-6.748a.8573.8573 0 0 0-.29-.4412.8748.8748 0 0 0-.9997-.0537.8585.8585 0 0 0-.3362.4049L.4332 9.5015l-.0325.0862a6.0657 6.0657 0 0 0 2.0119 7.0105l.0113.0087.03.0213 4.976 3.7264 2.462 1.8633 1.4995 1.1321a1.0085 1.0085 0 0 0 1.2197 0l1.4995-1.1321 2.4619-1.8633 5.006-3.7489.0125-.01a6.0682 6.0682 0 0 0 2.0094-7.003z`}))),s(i,{"aria-label":`Blog (opens in a new tab)`,className:`text-[#2F6F86] hover:text-[#1F3D36] transition-colors`,rel:`noopener noreferrer`,target:`_blank`,title:`Blog`,to:`https://www.seraph.to/blog`},s(p,{"aria-hidden":`true`,size:18})))),s(`div`,{className:`flex flex-col sm:flex-row sm:justify-between gap-1 text-xs text-gray-600 px-4 md:px-8 lg:px-16 py-2 border-t border-[#5C7B71]/40`},s(`span`,{},`© 2026 Ernesto Crespo. All rights reserved.`),s(`span`,{},`Source code under the `,s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume/blob/main/LICENSE`},`Apache 2.0 License`),` · `,s(i,{className:`text-[#2F6F86] hover:text-[#1F3D36] hover:underline underline-offset-4`,rel:`noopener noreferrer`,target:`_blank`,to:`https://github.com/ecrespo/reflex_resume`},`View the source`)))))),s(`title`,{},`Blog | Analyzing climate change data and atmospheric CO2 levels with Python and pandas.`),s(`meta`,{content:`https://www.seraph.to/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-1.png`,property:`og:image`}),s(`meta`,{content:`article`,property:`og:type`}),s(`meta`,{content:`Ernesto Crespo`,property:`og:site_name`}),s(`meta`,{content:`Analyzing climate change data and atmospheric CO2 levels with Python and pandas.`,property:`og:title`}),s(`meta`,{content:`https://www.seraph.to/blog/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas`,property:`og:url`}),s(`meta`,{content:`summary_large_image`,name:`twitter:card`}),s(`meta`,{content:`Analyzing climate change data and atmospheric CO2 levels with Python and pandas.`,name:`twitter:title`}),s(`meta`,{content:`https://www.seraph.to/blog/images/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas-1.png`,name:`twitter:image`}))}A.displayName=`Component(blog/analizandodatosdelcambioclimaticoynivelesdeco2enlaatmosferaconpythonypandas)`;var j=n(A);export{j as default};